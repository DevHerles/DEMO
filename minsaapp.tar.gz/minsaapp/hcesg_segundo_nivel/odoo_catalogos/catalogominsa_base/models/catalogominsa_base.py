# -*- coding: utf-8 -*-

from odoo import models


class CatalogoMinsaBase(models.AbstractModel):
    _inherit = ['mail.thread', 'ir.needaction_mixin', 'baseapi.basemodel']
    """
    Modelo Base para los Catalogos Minsa
    """

    _name = 'catalogosminsa.base'
