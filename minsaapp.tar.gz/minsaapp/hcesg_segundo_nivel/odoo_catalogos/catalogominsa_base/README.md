Catalogos Minsa - Catalogo Base
===============================

Odoo v10.0


# Dependencias Odoo

l10n_minsa (odoo-share)
baseapi (odoo-share)



Contiene clase base (abstracta), definiciones, metodos para los `Catalogos Minsa`

Remitase a la información técnica en baseapi/README.md


```python
class CatalogoBase(models.Model):
    _name = 'catalogominsa.catalogoase'


    _fields_json = [('atributo1', 'etiqueta1') , ('atributo2', 'etiqueta2'), ...]

    """
    Definir los pares `(dato, etiqueta)` que se devolvera en el metodo get_json
    ('create_uid.login', ),  # Devolverá como dato object.create_uid.login y como etiqueta object_create_uid_login
    ('create_uid.login', 'create_login'), # Devolverá como dato object.create_uid.login y como etiqueta create_login
    ('write_date', ),  # Devolverá como dato write_date y como etiqueta write_date
    """

    @api.model
    def get_json(self, domain=None):
        """
        Retorna data del catalogo, usando los "atributos" definidos en `_fields_json`

        :param domain: Dominio para filtrar el catálogo
        :rtype: dict
        """

        return {}
```



# Ejemplo de Catalogo

```python
class CatalogoEjemplo(models.Model):
    _inherit = 'catalogosminsa.base'

    _name = 'catalogominsa.cpt_grupo'
    _order = 'name'
    _rec_name = 'name'
    _description = u'Catálogo CPT - Grupo'

    # Definición de atributos del nuevo catalogo

    # atributo1 = fields....
    # atributo2 = fields....

    _sql_constraints = [
        (...),
    ]
```

# Consulta Api - Token

Remitase a la información técnica en baseapi/README.md