# -*- coding: utf-8 -*-

{
    'name': "Catalogo Base - Catalogos Minsa",

    'summary': """
        Modelo Base""",

    'description': """

    #  Modelo Base para Catálogos del Minsa

    """,

    'author': "Minsa",
    'website': "http://www.minsa.gob.pe",

    'category': 'Others',
    'version': '0.1',

    'depends': ['mail', 'l10n_minsa', 'baseapi'],

    'data': [
        'security.xml',
        'views/catalogominsa_base_views.xml',
        'views/res_users_views.xml',
    ],

    'demo': [
    ],
    'application': False,
}
