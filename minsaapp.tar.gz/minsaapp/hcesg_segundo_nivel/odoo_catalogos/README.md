# CATALOGOS MINSA

Odoo v.10

# Catalogos:

- Ciex
- Cpt
- Medicamentos

