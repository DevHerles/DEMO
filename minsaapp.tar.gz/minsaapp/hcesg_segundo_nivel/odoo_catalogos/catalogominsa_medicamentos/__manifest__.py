# -*- coding: utf-8 -*-

{
    'name': "Catálogo Minsa - Catalogo Medicamentos",

    'summary': """ """,

    'description': """

    Catálogo de Medicamentos


    Importar los archivos csv:



    """,

    'author': "Minsa",
    'website': "http://www.minsa.gob.pe",

    'category': 'Others',
    'version': '0.1',

    'depends': ['catalogominsa_base'],

    'data': [
        'ir.model.access.csv',
        'data/catalogominsa.medicina.familia.csv',
        'data/catalogominsa.medicina.csv',
        'views.xml',
    ],

    'demo': [
    ],
    'application': False,
}
