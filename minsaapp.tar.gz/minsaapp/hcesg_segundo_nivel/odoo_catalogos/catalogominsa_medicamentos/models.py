
# -*- coding: utf-8 -*-

from odoo import fields, models


class FormaFarmaceuticaSimplificada(models.Model):
    _inherit = 'catalogosminsa.base'

    _name = 'catalogominsa.medicamento.ff_s'
    _order = 'name'
    _rec_name = 'name'
    _description = u'Catálogo de Medicamentos - Forma Farmaceutica Simplificada'

    code = fields.Integer('Código', required=True, track_visibility='always')
    name = fields.Char('Descripción', size=100, required=True, track_visibility='always')

    _sql_constraints = [
        ('unique_code', 'unique(code)', 'Ya existe el código de la "Forma Farmaceutica Simplificada"'),
        ('valid_code', 'CHECK(code>0)', 'El código debe ser positivo "Forma Farmaceutica Simplificada"'),
    ]


class FormaFarmaceutica(models.Model):
    _inherit = 'catalogosminsa.base'

    _name = 'catalogominsa.medicamento.ff'
    _order = 'name'
    _rec_name = 'name'
    _description = u'Catálogo de Medicamentos - Forma Farmaceutica'

    code = fields.Integer('Código', required=True, track_visibility='always')
    name = fields.Char('Nombre', size=100, required=True, track_visibility='always')
    ff_simpl_id = fields.Many2one('catalogominsa.medicamento.ff_s', 'Form. Farm. Simplificada')

    _sql_constraints = [
        ('unique_code', 'unique(code)', 'Ya existe el código de la "Forma Farmaceutica"'),
        ('valid_code', 'CHECK(code>0)', 'El código debe ser positivo "Forma Farmaceutica Simplificada"'),
    ]


class Medicamento(models.Model):
    _inherit = 'catalogosminsa.base'

    _name = 'catalogominsa.medicamento'
    _order = 'name'
    _rec_name = 'name'
    _description = u'Catálogo de Medicamentos - Medicamento'

    code = fields.Integer('Código', required=True, track_visibility='always')
    name = fields.Char('Nombre', size=100, required=True, track_visibility='always')
    denominacion_comun = fields.Char('Denominación Común', size=100, track_visibility='always')
    concentracion = fields.Char('Concentración', size=100, track_visibility='always')

    ff_id = fields.Many2one('catalogominsa.medicamento.ff', 'Forma Farm.')
    ff_simpl_id = fields.Many2one(string='Forma Farm. Simplificada', related='ff_id.ff_simpl_id', store=True)

    _sql_constraints = [
        ('unique_code', 'unique(code)', 'Ya existe el código en el "Catálogo de Medicamentos"'),
        ('valid_code', 'CHECK(code>0)', 'El código debe ser positivo "Forma Farmaceutica Simplificada"'),
    ]


class CatalogominsaMedicinaFamilia(models.Model):
    _name = 'catalogominsa.medicina.familia'
    _description = u'Familia de Medicamentos'

    name = fields.Char(string='Nombre')
    code = fields.Char(string=u'Código')


class CatalogominsaMedicina(models.Model):
    _name = 'catalogominsa.medicina'
    _description = u'Familia de Medicamentos'

    name = fields.Char(string='Nombre')
    family = fields.Char(string=u'Familia')
