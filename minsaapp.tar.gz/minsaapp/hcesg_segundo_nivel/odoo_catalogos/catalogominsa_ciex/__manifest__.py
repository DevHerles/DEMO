# -*- coding: utf-8 -*-

{
    'name': "Catálogo Minsa Ciex",

    'summary': """ """,

    'description': """

    #  Catálogo Ciex

    """,

    'author': "Minsa",
    'website': "http://www.minsa.gob.pe",

    'category': 'Others',
    'version': '0.1',

    'depends': ['catalogominsa_base'],

    'data': [
        'security.xml',
        'ir.model.access.csv',
        'views.xml',
    ],

    'demo': [
    ],
    'application': True,
}
