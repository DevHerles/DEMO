
# -*- coding: utf-8 -*-

from odoo import fields, models


class CatalogoCiex(models.Model):
    _inherit = 'catalogosminsa.base'

    _name = 'catalogominsa.cat_ciex'

    _order = 'id_ciex, desc_ciex'
    _rec_name = 'desc_ciex'
    _description = u'Catálogo Ciex'

    id_ciex = fields.Char(size=6, required=True, track_visibility='onchange')
    desc_ciex = fields.Char(size=100, required=True, track_visibility='onchange')
    id_sexo = fields.Selection([('F', 'Femenino'), ('M', 'Masculino')], 'Sexo', size=1)
    id_tipedad_min = fields.Char(size=3)
    min_edad = fields.Char(size=3)
    id_tipedad_max = fields.Char(size=3)
    max_edad = fields.Char(size=3)
    fg_tipdiag = fields.Char(size=1)
    clase1 = fields.Char(size=1)
    lab1 = fields.Char(size=3)
    lab2 = fields.Char(size=3)
    lab3 = fields.Char(size=3)
    lab4 = fields.Char(size=3)
    lab5 = fields.Char(size=3)
    id_ciex_and = fields.Char(size=3)
    id_ciex_or = fields.Char(size=3)
    fg_ciex = fields.Char(size=3)

    _sql_constraints = [
        ('unique_id_ciex', 'unique(active, id_ciex)', 'Ya existe el id_ciex')
    ]
