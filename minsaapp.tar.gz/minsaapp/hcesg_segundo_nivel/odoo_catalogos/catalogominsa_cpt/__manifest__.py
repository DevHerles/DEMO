# -*- coding: utf-8 -*-

{
    'name': "Catálogo Minsa - Catalogo de Procedimientos",

    'summary': """ """,

    'description': """

    Catálogo de Procedimientos - CPT


    Importar los archivos csv:

    * Considerar el formato de archivos windows-1252

    - catalogominsa_cpt/data/catalogominsa.cpt_grupo.csv

    - catalogominsa_cpt/data/catalogominsa.cpt_seccion.csv

    - catalogominsa_cpt/data/catalogominsa.cpt_subseccion.csv

    - catalogominsa_cpt/data/catalogominsa.cpt_procedimiento.csv


    """,

    'author': "Minsa",
    'website': "http://www.minsa.gob.pe",

    'category': 'Others',
    'version': '0.1',

    'depends': ['catalogominsa_base'],

    'data': [
        'security.xml',
        'ir.model.access.csv',
        'views.xml',
    ],

    'demo': [
    ],
    'application': False,
}
