Catálogo CPT
============


Luego de instalar, cargar los los archivos:

Considerar el formato de archivos `windows-1252`

- catalogominsa.cpt_grupo.csv

- catalogominsa.cpt_procedimiento.csv

- catalogominsa.cpt_seccion.csv

- catalogominsa.cpt_subseccion
