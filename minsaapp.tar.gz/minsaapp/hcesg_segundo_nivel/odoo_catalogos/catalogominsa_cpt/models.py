
# -*- coding: utf-8 -*-

from odoo import fields, models


class CptGrupo(models.Model):
    _inherit = 'catalogosminsa.base'

    _name = 'catalogominsa.cpt_grupo'
    _order = 'name'
    _rec_name = 'name'
    _description = u'Catálogo CPT - Grupo'

    code = fields.Char('Código', size=3, required=True)
    name = fields.Char('Nombre del Grupo', size=100, required=True)

    seccion_ids = fields.One2many(
        'catalogominsa.cpt_seccion', 'grupo_id',
        'Secciones')

    _sql_constraints = [
        ('unique_code', 'unique(code)', 'Ya existe el código del "CPT - GRUPO"'),
        ('unique_name', 'unique(active, code, name)', 'Ya el nombre del "CPT - GRUPO"'),
    ]


class CptSeccion(models.Model):
    _inherit = 'catalogosminsa.base'

    _name = 'catalogominsa.cpt_seccion'

    code = fields.Char('Código', size=7, required=True)
    name = fields.Char('Nombre de la Sección', size=150, required=True)
    grupo_id = fields.Many2one('catalogominsa.cpt_grupo', 'Grupo', required=True,)

    subseccion_ids = fields.One2many(
        'catalogominsa.cpt_subseccion', 'seccion_id',
        'Sub-secciones')

    _order = 'name'
    _rec_name = 'name'
    _description = u'Catálogo CPT - Sección'

    _sql_constraints = [
        ('unique_code', 'unique(code)', 'Ya existe el código de la "CPT - Sección"'),
        ('unique_name', 'unique(active, grupo_id, name)', 'Ya existe el nombre dle "CPT - Sección"'),
    ]


class CptSubSeccion(models.Model):
    _inherit = 'catalogosminsa.base'

    _name = 'catalogominsa.cpt_subseccion'
    _order = 'name'
    _rec_name = 'name'
    _description = u'Catálogo CPT - Subsección'

    code = fields.Char('Código', size=11, required=True)
    name = fields.Char('Nombre de la SubSección', size=150, required=True)
    seccion_id = fields.Many2one('catalogominsa.cpt_seccion', 'Sección', required=True)

    cpt_ids = fields.One2many(
        'catalogominsa.cpt_procedimiento', 'subseccion_id',
        'Cps')

    _sql_constraints = [
        ('unique_code', 'unique(code)', 'Ya existe el código de la "CPT - SubSección"'),
        ('unique_name', 'unique(active, seccion_id, name)', 'Ya existe el CPT - Sección'),
    ]


class CptProcedimiento(models.Model):
    _inherit = 'catalogosminsa.base'

    _name = 'catalogominsa.cpt_procedimiento'
    _order = 'name'
    _rec_name = 'name'
    _description = u'Catálogo CPT - Procedimientos'

    code = fields.Char('Código', size=11, required=True)
    name = fields.Char('Nombre del Cpt', size=300, required=True)
    name_short = fields.Char('Nombre corto', size=100)
    subseccion_id = fields.Many2one('catalogominsa.cpt_subseccion', 'Sub-sección')
    flag = field_name = fields.Char('Flag', size=20)

    # Atributos relativos store

    _fields_json = [
        ('subseccion_id.seccion_id.grupo_id.code', 'grupo_codigo'),
        ('subseccion_id.seccion_id.grupo_id.name', 'grupo_nombre'),
        ('subseccion_id.seccion_id.code', 'seccion_codigo'),
        ('subseccion_id.seccion_id.name', 'seccion_nombre'),
        ('subseccion_id.code', 'subseccion_codigo'),
        ('subseccion_id.name', 'subseccion_nombre'),
        ('code', 'procedimiento_codigo'),
        ('name', 'procedimiento_nombre'),
        ('name_short', 'procedimiento_nombrecorto'),
        ('flag', 'flag'),
    ]

    _sql_constraints = [
        ('unique_code', 'unique(code)', 'Ya existe el código del "CPT"'),
        ('unique_name', 'unique(active, code, name)', 'Ya existe del "CPT"'),
    ]
