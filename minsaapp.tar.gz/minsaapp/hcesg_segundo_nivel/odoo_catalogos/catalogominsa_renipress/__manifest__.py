# -*- coding: utf-8 -*-

{
    'name': "Catálogo Minsa - Renipress",

    'summary': """ """,

    'description': """

    Catálogo de Establecimientos de Salud


    Importar los archivos csv:

    * Considerar el formato de archivos windows-1252

    - catalogominsa_renipress/data/catalogominsa.renipress.diresa.csv

    - catalogominsa_renipress/data/catalogominsa.renipress.red.csv

    - catalogominsa_renipress/data/catalogominsa.renipress.microred.csv

    - catalogominsa_renipress/data/catalogominsa.renipress.eess.csv


    """,

    'author': "Minsa",
    'website': "http://www.minsa.gob.pe",

    'category': 'Others',
    'version': '0.1',

    'depends': ['catalogominsa_base', 'toponimos_peru'],

    'data': [
        'data/querys.sql',
        'security.xml',
        'ir.model.access.csv',
        'views.xml',
    ],

    'demo': [
    ],
    'application': False,
}
