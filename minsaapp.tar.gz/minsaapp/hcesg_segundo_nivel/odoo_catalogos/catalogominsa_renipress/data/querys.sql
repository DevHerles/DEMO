/*
    catalogominsa_diresa_departamento_rel debe ser una vista, sino se elimina
 */
DO
$do$
BEGIN
    IF (SELECT COUNT(*) FROM pg_catalog.pg_tables WHERE tablename='renaes_diresa_departamento_rel' LIMIT 1) >0
    THEN
        DROP TABLE IF EXISTS catalogominsa_diresa_departamento_rel ;
    END IF;
END
$do$;


/*
-- RELACION DIRESA - DEPARTAMENTO
CREATE or REPLACE VIEW catalogominsa_diresa_departamento_rel AS
(
    SELECT diresa_id, departamento_id FROM RENAES_EESS 
    GROUP BY diresa_id, departamento_id
    ORDER BY diresa_id
);
*/
