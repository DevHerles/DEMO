# -*- coding: utf-8 -*-

from odoo import fields, models


class InstitucionBase(models.AbstractModel):
    _inherit = ['res.country.lugar', 'catalogosminsa.base']

    _name = 'catalogominsa.renipress.institucion_base'
    _description = u'Institución Base'

    name = fields.Char('Nombre', size=100, required=True)
    active = fields.Boolean('Activo/Inactivo', default=True)


class Diresa(models.Model):
    _inherit = 'catalogominsa.renipress.institucion_base'
    _name = 'catalogominsa.renipress.diresa'

    _description = u'Catalogo - Diresa'

    name = fields.Char('Diresa')
    codigo_diresa = fields.Char('Código', size=2, required=True, oldname='codigo')
    departamento_ids = fields.Many2many(
        'res.country.state',
        'catalogominsa_diresa_departamento_rel',
        'diresa_id', 'departamento_id',
        'Departamentos', readonly=True)

    red_ids = fields.One2many('catalogominsa.renipress.red', 'diresa_id', 'Redes')

    _fields_json = [
        ('name', 'nombre'),
        ('codigo_diresa', 'codigo'),
    ]

    _sql_constraints = [
        ('codigo_unique', 'unique(codigo_diresa)', 'El código de la Diresa ser único!'),
        ('codigo_name', 'unique(active, name)',
         'El nombre de la Diresa ser único!'),
    ]


class Red(models.Model):
    _inherit = 'catalogominsa.renipress.institucion_base'
    _name = 'catalogominsa.renipress.red'

    _description = u'Catalogo - Red de Salud'

    name = fields.Char('Red')
    codigo_red = fields.Char('Código', size=2, required=True, oldname='codigo')

    diresa_id = fields.Many2one('catalogominsa.renipress.diresa', 'Diresa', required=True)
    departamento_id = fields.Many2one(
        related='diresa_id.departamento_id', store=True)

    microred_ids = fields.One2many('catalogominsa.renipress.microred', 'red_id', 'Microredes')

    _sql_constraints = [
        ('codigo_unique', 'unique(diresa_id, codigo_red)',
         'El código de la Red de Salud ser único!'),
        ('codigo_name', 'unique(diresa_id, codigo_red, name)',
         'El Codigo y Red deben ser únicos!'),
    ]

    def name_get(self):
        res = []
        for record in self:
            name = record.name
            if record.diresa_id:
                name = '%s|%s' % (record.diresa_id.name, name)
            res.append((record.id, name))
        return res


class Microred(models.Model):
    _inherit = 'catalogominsa.renipress.institucion_base'
    _name = 'catalogominsa.renipress.microred'

    _description = u'Catalogo - Micro Red de Salud'

    name = fields.Char('Microred')
    codigo_microred = fields.Char('Código', size=2, required=True, oldname='codigo')

    red_id = fields.Many2one('catalogominsa.renipress.red', 'Red', required=True)
    diresa_id = fields.Many2one('catalogominsa.renipress.diresa', 'Diresa', related='red_id.diresa_id', store=True, readonly=True)

    eess_ids = fields.One2many('catalogominsa.renipress.eess', 'microred_id', 'Establecimientos de Salud')

    def name_get(self):
        res = []
        for record in self:
            name = record.name
            if record.diresa_id and record.red_id:

                name = '%s|%s|%s' % (record.diresa_id.name, record.red_id.name, name)
            res.append((record.id, name))
        return res

    _sql_constraints = [
        ('codigo_unique', 'unique(red_id, codigo_microred)',
         'El código de la MicroRed debe ser único!'),
        ('codigo_name', 'unique(red_id, active, name)',
         'El nombre de la MicroRed debe ser único!'),
    ]


class EeSs(models.Model):
    _inherit = 'catalogominsa.renipress.institucion_base'
    _name = 'catalogominsa.renipress.eess'

    _description = u'Catalogo - Establecimiento de Salud'

    name = fields.Char('Establecimiento de Salud')
    codigo_eess = fields.Char('Código', size=8, required=True)

    direccion = fields.Char('Dirección')

    microred_id = fields.Many2one('catalogominsa.renipress.microred', 'Microred', required=True)
    red_id = fields.Many2one('catalogominsa.renipress.red', 'Red', related='microred_id.red_id', store=True, readonly=True)
    diresa_id = fields.Many2one('catalogominsa.renipress.diresa', 'Diresa', related='red_id.diresa_id', store=True, readonly=True)

    flag = field_name = fields.Char('Flag', size=20)

    institucion_id = fields.Many2one('catalogominsa.renipress.catalogo', 'Institución', domain=[('tipo', '=', 'institucion')])
    clasificacion_id = fields.Many2one('catalogominsa.renipress.catalogo', 'Clasificación', domain=[('tipo', '=', 'clasificacion')])
    tipo_id = fields.Many2one('catalogominsa.renipress.catalogo', 'Tipo', domain=[('tipo', '=', 'tipo')])

    _fields_json = [
        ('id', 'id'),
        ('codigo_eess', 'codigo_ipress'),
        ('name', 'nombre'),
        ('diresa_id.codigo_diresa', 'diresa_codigo'),
        ('red_id.codigo_red', 'red_codigo'),
        ('microred_id.name', 'microred_nombre'),
        ('ubigeo', 'ubigeo'),
        ('direccion', 'direccion'),
        ('diresa_id.name', 'diresa_nombre'),
        ('red_id.name', 'red_nombre'),
        ('flag', 'flag'),
    ]

    _sql_constraints = [
        ('codigo_unique', 'unique(codigo_eess)',
         'El código del Establecimiento de Salud ser único!'),
    ]


class Catalogo(models.Model):
    _inherit = 'catalogosminsa.base'

    _name = 'catalogominsa.renipress.catalogo'
    _description = u'Catalogo'

    tipo = fields.Selection(
        [('institucion', 'Institución'),
         ('clasificacion', 'Clasificación'),
         ('tipo', 'Tipo')],
        'Tipo',
        required=True,
    )
    name = fields.Char('Nombre', size=100, required=True)
    active = fields.Boolean('Activo/Inactivo', default=True)
