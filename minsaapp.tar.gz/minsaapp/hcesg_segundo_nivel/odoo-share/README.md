# odoo_share

Addons comunes para Proyectos en Odoo v10.
-----|----
Módulo | Version
-----|----
consultadatos | 10.0.