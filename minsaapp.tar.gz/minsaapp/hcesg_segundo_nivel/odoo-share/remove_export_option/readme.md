# Remove Export Option
- Oculta la opción de Exportar en las vistas Tree, Form
- Permite habilitar esta opción a usuarios que esten en el grupo "Export Visible"

## Fuente
https://www.odoo.com/apps/modules/8.0/remove_export_option/
Probado en la v.10.0

