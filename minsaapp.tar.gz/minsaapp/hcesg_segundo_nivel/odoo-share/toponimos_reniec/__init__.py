# flake8: noqa
import res_partner
import res_country
