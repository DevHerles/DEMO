# -*- coding: utf-8 -*-

import logging
import json

from odoo import http, fields
from odoo.http import request, Response
from odoo.exceptions import AccessError
from odoo.tools.safe_eval import test_python_expr

_logger = logging.getLogger(__name__)


class Controller(http.Controller):
    """
    Clase en desarrollo para consulta de los catalogos
    """

    @http.route(['/api/auth/get_tokens'],
                type='http', methods=['GET'], auth='public', website=False)
    def get_tokens(self, *kargs, **kwargs):
        # Por implementar
        return json.dumps([{'hellow': 'mundo'}])

    @http.route(['/api/<string:model_name>/'],
                type='http', methods=['get'], auth='public', website=False, cors="*")
    def get_records(self, model_name, **params):
        if isinstance(self.user, Response):
            return self.user

        if not self.user:
            return Response(json.dumps({'error': 'No se encontró el usuario'}), status=404, headers={})

        try:
            model = request.env[model_name]
        except KeyError:
            return Response(json.dumps({'error': 'No se encontró el modelo'}), status=404)

        if not hasattr(model, '_alias_fields'):
            return Response(json.dumps({'error': 'El modelo no esta preparado para el servicio'}), status=404)

        _alias_fields = model._alias_fields

        # Calculo de dominio
        domain = []
        _limit = limit = 100
        order = None
        page = 1
        only_count = False
        only_fields = None
        # Calculo de parametros
        for param_alias, param_value in params.iteritems():
            item_domain = False
            if param_alias in _alias_fields:
                item_domain = [param_alias, '=', param_value]
            elif param_alias.endswith('__like'):
                item_domain = [param_alias[:-6], 'ilike', param_value]
            elif param_alias.endswith('__lte'):
                item_domain = [param_alias[:-5], '<=', param_value]
            elif param_alias.endswith('__lt'):
                item_domain = [param_alias[:-4], '<', param_value]
            elif param_alias.endswith('__lge'):
                item_domain = [param_alias[:-5], '>=', param_value]
            elif param_alias.endswith('__lg'):
                item_domain = [param_alias[:-4], '>', param_value]
            elif param_alias.endswith('__in'):
                error_expr = test_python_expr(expr=param_value, mode="eval")
                if error_expr:
                    return Response(json.dumps({'error': 'Error en la expresión del parámetro'}), status=500)
                try:
                    param_value = eval(param_value)
                except Exception:
                    return Response(json.dumps({'error': 'Error en el valor del parámetro'}), status=500)

                item_domain = [param_alias[:-4], 'in', param_value]
            elif param_alias == 'pagination':
                # Numero de elementos por pagina
                limit = int(param_value)
                limit = limit > 0 and min(limit, _limit) or _limit
            elif param_alias == 'order':
                order = param_value
            elif param_alias == 'page':
                page = int(param_value)
                page = page > 0 and page or 1
            elif param_alias == 'only_count' and param_value.isdigit() and int(param_value) > 0:
                only_count = True
            elif param_alias == 'only_fields':
                only_fields = param_value
            else:
                _logger.info('parametro no reconocido `{}`'.format(param_alias))
                return Response(json.dumps({'error': 'Parámetro no reconocido {}'.format(param_alias)}), status=404)
            if item_domain:
                if item_domain[0] not in _alias_fields:
                    return Response(json.dumps({'error': 'Parámetro "{}" no encontrado'.format(item_domain[0])}), status=404)
                item_domain[0] = _alias_fields[item_domain[0]]
                domain.append(tuple(item_domain))

        offset = (page - 1) * limit
        offset = offset > 0 and offset or None

        res = {}

        model = request.env[model_name].sudo(self.user.id)
        try:
            pass
            count = model.search_count(domain)
        except AccessError:
            return Response(json.dumps({'error': 'No tiene permisos para acceder a la información'}), status=404)
        except Exception as e:
            return Response(json.dumps({'error': 'Error desconocido: {}'.format(e.message)}), status=404)

        if only_count:
            res = {'count': count}
        else:
            data = model.get_json(domain=domain, order=order, limit=limit, offset=offset, only_fields=only_fields)
            res.update({'data': data,
                        'meta': {'pages': count / limit + (count % limit != 0),
                                 'count': count,
                                 'pagination': limit}})

        return Response(json.dumps(res), mimetype='application/json', status=200)

    @property
    def token(self):
        authorization = self.headers.get('Authorization', False)
        return authorization and \
            (authorization.startswith('Bearer') and authorization[7:] or authorization)

    @property
    def headers(self):
        return request.httprequest.headers

    @property
    def user(self):
        if not self.token:
            # Acceso a usuario logeado
            if request.env.user:
                return request.env.user
            return False
        domain = [('token', '=', self.token),
                  ('is_active', '=', True),
                  ('valid_until', '>=', fields.Datetime.now())]

        usertoken = request.env['res.users.token'].sudo().search(domain, limit=1)
        if usertoken and not usertoken.user_id.has_group('baseapi.group_api_token'):
            return Response(json.dumps({'error': 'Unicamente los Usuarios Token pueden acceder a esta función'}), status=404)

        return usertoken.user_id
