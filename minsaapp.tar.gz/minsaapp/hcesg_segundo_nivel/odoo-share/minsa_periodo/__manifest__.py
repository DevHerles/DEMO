# -*- coding: utf-8 -*-
{
    "name": "Minsa - Periodo",
    "version": "1.1",
    "author": "",
    "website": "http://www.minsa.gob.pe",
    "category": "otros",
    "description": """
    """,
    "depends": [
        "account",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/trees.xml",
        "views/forms.xml",
        "views/actions.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "active": False,
}
