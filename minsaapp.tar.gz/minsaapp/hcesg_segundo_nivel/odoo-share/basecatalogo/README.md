Catalogo de Uso General
=======================

Agregar en los views

```xml
    <menuitem
        id="menu_catalogo"
        action="basecatalogo.view_catalogo_action"/>
```