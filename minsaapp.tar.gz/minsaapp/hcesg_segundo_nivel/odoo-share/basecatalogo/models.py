# -*- coding: utf-8 -*-

import logging
from odoo import api, fields, models

_logger = logging.getLogger(__name__)


class Catalogo(models.Model):
    _name = 'basecatalogo.catalogo'

    _order = 'parent_id, sequence, name'
    _description = u'Catálogo General para Aplicaciones'

    def _default_parent_id(self):
        root = self.search([('code', '=', 'root'), ('parent_id', '=', False)], limit=1)
        return self.env.context.get('default_parent_id') or root.id

    parent_id = fields.Many2one(_name, 'Padre', default=_default_parent_id)
    code = fields.Char('Código', size=50, required=True)
    name = fields.Char('Descripción', size=100, required=True)
    alias = fields.Char('Abreviatura', size=30)
    value1 = fields.Char('Valor1')
    value2 = fields.Char('Valor2')
    value3 = fields.Char('Valor3')

    active = fields.Boolean('Activo/Inactivo', default=True)
    sequence = fields.Integer(default=10)

    child_ids = fields.One2many(_name, 'parent_id', 'Items')

    _sql_constraints = [
        ('parent_id_code',
         'UNIQUE(parent_id, code)',
         "Ya existe el código"),
        ('parent_id_name',
         'UNIQUE(parent_id, name)',
         "Ya existe el cátalogo"),
    ]

    @api.model
    def get_catalogo(self, parent_code, key='code'):
        domain = [('parent_id.code', '=', parent_code)]
        return [(getattr(obj, key), obj.name) for obj in self.search(domain)]
