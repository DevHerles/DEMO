# -*- coding: utf-8 -*-

{
    'name': "MINSA - Catálogo de uso General para Aplicaciones",

    'summary': """Catálogo""",

    'description': """
    Luego de instalar, cargar el archivo basecatalogo.catalogo.csv
    """,

    'author': "",
    'website': "http://www.minsa.gob.pe",

    'category': 'Others',
    'version': '0.1',

    'depends': ['base'],

    'data': [
        'basecatalogo.catalogo.csv',
        'ir.model.access.csv',
        'views.xml',
    ],

    'demo': [
    ],
    'application': False,
}
