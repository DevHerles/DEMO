# -*- coding: utf-8 -*-

from odoo import fields, models


class InstitucionBase(models.AbstractModel):
    _inherit = 'res.country.lugar'

    _name = 'renaes.institucion_base'
    _description = u'Institución Base'

    name = fields.Char('Nombre', size=100, required=True)
    active = fields.Boolean('Activo/Inactivo', default=True)


class Diresa(models.Model):
    _inherit = 'renaes.institucion_base'
    _name = 'renaes.diresa'

    _description = u'Diresa'

    name = fields.Char('Diresa')
    codigo_diresa = fields.Char(u'Código', size=2, required=True, oldname='codigo')
    departamento_ids = fields.Many2many(
        'res.country.state',
        'renaes_diresa_departamento_rel',
        'diresa_id', 'departamento_id',
        'Departamentos', readonly=True)

    red_ids = fields.One2many('renaes.red', 'diresa_id', 'Redes')

    _sql_constraints = [
        ('codigo_unique', 'unique(codigo_diresa)', 'El código de la Diresa ser único!'),
        ('codigo_name', 'unique(active, name)',
         u'El nombre de la Diresa ser único!'),
    ]


class Red(models.Model):
    _inherit = 'renaes.institucion_base'
    _name = 'renaes.red'

    _description = u'Red de Salud'

    name = fields.Char('Red')
    codigo_red = fields.Char('Código', size=2, required=True, oldname='codigo')

    diresa_id = fields.Many2one('renaes.diresa', 'Diresa', required=True)
    departamento_id = fields.Many2one(
        related='diresa_id.departamento_id', store=True)

    _sql_constraints = [
        ('codigo_unique', 'unique(diresa_id, codigo_red)',
         u'El código de la Red de Salud ser único!'),
        ('codigo_name', 'unique(diresa_id, codigo_red, name)',
         u'El Codigo y Red deben ser únicos!'),
    ]

    def name_get(self):
        res = []
        for record in self:
            name = record.name
            if record.diresa_id:
                name = u'%s|%s' % (record.diresa_id.name or '', name)
            res.append((record.id, name))
        return res


class Microred(models.Model):
    _inherit = 'renaes.institucion_base'
    _name = 'renaes.microred'

    _description = u'Micro Red de Salud'

    name = fields.Char('Microred')
    codigo_microred = fields.Char('Código', size=2, required=True, oldname='codigo')

    red_id = fields.Many2one('renaes.red', 'Red', required=True)
    diresa_id = fields.Many2one('renaes.diresa', 'Diresa', related='red_id.diresa_id', store=True, readonly=True)

    _sql_constraints = [
        ('codigo_unique', 'unique(red_id, codigo_microred)',
         u'El código de la MicroRed debe ser único!'),
        ('codigo_name', 'unique(red_id, active, name)',
         u'El nombre de la MicroRed debe ser único!'),
    ]

    def name_get(self):
        res = []
        for record in self:
            name = record.name
            if record.diresa_id and record.red_id:
                name = u'%s|%s|%s' % (record.diresa_id.name or '', record.red_id.name or '', name)
            res.append((record.id, name))
        return res


SELECTION_INSTITUCION = [
    ('1', 'ESSALUD'),
    ('2', 'GOBIERNO REGIONAL'),
    ('3', 'INPE'),
    ('4', 'MINSA'),
    ('5', 'MUNICIPALIDAD DISTRITAL'),
    ('6', 'MUNICIPALIDAD PROVINCIAL'),
    ('7', 'OTRO'),
    ('8', 'PRIVADO'),
    ('9', 'SANIDAD DE LA FUERZA AEREA DEL PERU'),
    ('10', 'SANIDAD DE LA MARINA DE GUERRA DEL PERU'),
    ('11', 'SANIDAD DE LA POLICIA NACIONAL DEL PERU'),
    ('12', 'SANIDAD DEL EJERCITO DEL PERU'),
]

SELECTION_CLASIFICACION = [
    ('1', 'ATENCION PRE HOSPITALARIA'),
    ('2', 'CENTROS DE ATENCION PARA DEPENDIENTES A SUSTANCIAS PSICOACTIVAS Y OTRAS DEPENDENCIAS'),
    ('3', 'CENTROS DE SALUD CON CAMAS DE INTERNAMIENTO'),
    ('4', 'CENTROS DE SALUD CON CAMAS DE INTERNAMIENTO,CENTROS DE SALUD CON CAMAS DE INTERNAMIENTO'),
    ('5', 'CENTROS DE SALUD O CENTROS MEDICOS'),
    ('6', 'CENTROS DE SALUD O CENTROS MEDICOS,CENTROS DE SALUD O CENTROS MEDICOS'),
    ('7', 'CENTROS DE VACUNACION'),
    ('8', 'CENTROS MEDICOS ESPECIALIZADOS'),
    ('9', 'CONSULTORIOS MEDICOS Y DE OTROS PROFESIONALES DE LA SALUD'),
    ('10', 'ESTABLECIMIENTOS DE RECUPERACION O REPOSO'),
    ('11', 'HOSPITALES O CLINICAS DE ATENCION ESPECIALIZADA'),
    ('12', 'HOSPITALES O CLINICAS DE ATENCION GENERAL'),
    ('13', 'INSTITUTOS DE SALUD ESPECIALIZADOS'),
    ('14', 'PATOLOGIA CLINICA'),
    ('15', 'PATOLOGIA CLINICA,ANATOMIA PATOLOGICA'),
    ('16', 'PATOLOGIA CLINICA,DIAGNOSTICO POR IMAGENES'),
    ('17', 'PUESTOS DE SALUD O POSTAS DE SALUD'),
    ('18', 'PUESTOS DE SALUD O POSTAS DE SALUD,PUESTOS DE SALUD O POSTAS DE SALUD'),
    ('19', 'SERVICIO DE TRASLADO DE PACIENTES'),
    ('20', 'SERVICIO DE TRASLADO DE PACIENTES,ATENCION DOMICILIARIA'),
    ('21', 'SERVICIO DE TRASLADO DE PACIENTES,ATENCION DOMICILIARIA,ATENCION PRE HOSPITALARIA'),
    ('22', 'SERVICIO DE TRASLADO DE PACIENTES,ATENCION PRE HOSPITALARIA'),
]

SELECTION_TIPO = [
    ('0', 'ESTABLECIMIENTO DE SALUD CON INTERNAMIENTO'),
    ('1', 'ESTABLECIMIENTO DE SALUD SIN INTERNAMIENTO'),
    ('2', 'SERVICIO MÉDICO DE APOYO'),
]


class EeSs(models.Model):
    _inherit = 'renaes.institucion_base'
    _name = 'renaes.eess'

    _description = u'Establecimiento de Salud'

    name = fields.Char('Establecimiento de Salud')
    codigo_eess = fields.Char('Código', size=8, required=True, oldname='codigo')

    direccion = fields.Char('Dirección')
    institucion = fields.Selection(SELECTION_INSTITUCION, u'Institución')
    clasificacion = fields.Selection(SELECTION_CLASIFICACION, u'Clasificación')
    tipo = fields.Selection(SELECTION_TIPO, 'Tipo')

    microred_id = fields.Many2one('renaes.microred', 'Microred', required=True)
    red_id = fields.Many2one('renaes.red', 'Red', related='microred_id.red_id', store=True, readonly=True)
    diresa_id = fields.Many2one('renaes.diresa', 'Diresa', related='red_id.diresa_id', store=True, readonly=True)

    coor_norte = fields.Float('Coor. Norte', size=(11, 6))
    coor_este = fields.Float('Coor. Este', size=(11, 6))

    _sql_constraints = [
        ('codigo_unique', 'unique(codigo_eess)',
         u'El código del Establecimiento de Salud ser único!'),
    ]
