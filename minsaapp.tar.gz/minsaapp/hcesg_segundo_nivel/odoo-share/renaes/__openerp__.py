
# -*- coding: utf-8 -*-
{
    'name': "MINSA - Renaes - Establecimientos de Salud",

    'summary': """
        Establecimientos de Salud, Diresa, Red, Microredes""",

    'description': """
    Información de los Establecientos de Salud
    """,

    'author': "",
    'website': "http://www.minsa.gob.pe",

    'category': 'Others',
    'version': '0.1',

    'depends': ['toponimos_peru'],

    'data': [
        'data/querys.sql',
        'data/renaes.diresa.csv',
        'data/renaes.red.csv',
        'data/renaes.microred.csv',
        'data/renaes.eess.csv',
        'ir.model.access.csv',
        'renaes_views.xml'],
    'demo': [],
    'application': False,
}
