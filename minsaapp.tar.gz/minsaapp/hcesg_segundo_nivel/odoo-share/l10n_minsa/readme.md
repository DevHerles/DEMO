# Módulo base para el odoo - Minsa

Cambios:
- Establece los datos de compañia y logo como "Ministerio de Salud"
- Activa moneda SOLES "PEN"
- Zona horaria: "America/Lima" por defecto para la creación de usuarios


TODO:
- Cambio de idioma para el administrador
- Guardar por defecto el logo de la compañia principal en cada nueva compañia que se cree.


