
# -*- coding: utf-8 -*-
{
    'name': "MINSA - Base",

    'summary': """
        Localización Base para Odoo - Minsa""",

    'description': """
    Modifica los parametros de la Compañia, moneda
    """,

    'author': "",
    'website': "http://www.minsa.gob.pe",

    'category': 'Others',
    'version': '0.1',

    'depends': ['base'],

    'data': [
        'data/base.xml',
    ],
    'demo': [
    ],
    'application': False,
}
