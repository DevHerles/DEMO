# -*- coding: utf-8 -*-
##############################################################################
#    Copyright (C) 2017 oeHealth (<http://oehealth.in>). All Rights Reserved
#    oeHealth, Hospital Management Solutions
##############################################################################

import oeh_medical_domiciliary_unit
import oeh_medical_ntd_chagas
import oeh_medical_ntd_dengue