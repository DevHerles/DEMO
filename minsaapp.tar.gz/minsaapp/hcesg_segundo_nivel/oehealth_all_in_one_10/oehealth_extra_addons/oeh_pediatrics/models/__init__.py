##############################################################################
#    Copyright (C) 2017 oeHealth (<http://oehealth.in>). All Rights Reserved
#    oeHealth, Hospital Management Solutions
##############################################################################

# -*- coding: utf-8 -*-
import res_partner
import oeh_medical_pediatrics_newborn
import oeh_medical_pediatrics_psc
import oeh_medical_pediatrics_growth_chart_who