##############################################################################
#    Copyright (C) 2017 oeHealth (<http://oehealth.in>). All Rights Reserved
#    oeHealth, Hospital Management Solutions
##############################################################################

{
    'name': 'oeHealth Spanish Translation',
    'version': '1.0',
    'author': "Braincrew Apps",
    'category': 'Generic Modules/Medical',
    'summary': 'Translate the complete oeHealth module in Spanish Language',
    'depends': ['base'],
    'price': 50.00,
    'currency': 'EUR',
    'description': """

oeHealth Spanish Traslation

""",
    "images": ['images/main_screenshot.png'],
    "website": "http://oehealth.in",
    "data": [
    ],
    "demo": [

    ],
    'test':[
    ],
    'css': [

    ],
    'js': [

    ],
    'qweb': [

    ],
    "active": False
}