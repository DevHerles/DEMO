# -*- coding: utf-8 -*-

from odoo import fields, models


class ProductCategory(models.Model):
    _inherit = 'product.category'

    appointment_only_category = fields.Boolean('Cita Única/Categoria', default=True)
