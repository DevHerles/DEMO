# -*- coding: utf-8 -*-
import datetime
import pytz

from odoo import api, fields, models
from odoo.exceptions import ValidationError

TYPE_DOC_EQUIVALENCE = {'01': 'DNI', '03': 'CARNETEXT', '06': 'PASAPORTE'}
SEX_EQUIVALENT = {'1': 'Hombre', '2': 'Mujer'}
ACTIVO = 'ACTIVO'


class WizardAppointment(models.TransientModel):
    '''
    Búsqueda de pacientes
    '''

    _name = 'wizard.appointment'
    _description = 'Wizard appointment'
    _rec_name = "q"

    q = fields.Char()
    line_ids = fields.One2many(
        'wizard.appointment.line', 'wizard_appointment_id')
    q2 = fields.Char()
    line_2_ids = fields.One2many(
        'wizard.appointment.line2', 'wizard_appointment_id')

    def search_patients(self):
        # Antes de cargar los nuevos item los limpia
        self.line_ids.unlink()
        if not self.q:
            self.line_ids = []
        else:
            patients = self.env['oeh.medical.patient'].search([
                '|', '|', '|', '|', ('document_number', 'ilike', self.q),
                ('name', 'ilike', self.q),
                ('first_name', 'ilike', self.q),
                ('last_name', 'ilike', self.q),
                ('last_name_2', 'ilike', self.q)])

            # Actualiza el estado del seguro/sis

            list_patients = []
            if patients:
                patients.validate_sis()
                for p in patients:
                    list_patients.append([0, False, {
                        'patient_id': p.id,
                        'type_number': p.type_number,
                        'document_number': p.document_number,
                        'complete_name': u'{} {} {}'.format(
                            p.first_name or p.name, p.last_name or "",
                            p.last_name_2 or ""),
                        'age': p.age,
                        'sex': p.sex,
                        'filiation_sis': p.affiliation_file_number,
                        'sis_estado': p.sis_estado}])
                self.line_ids = list_patients
            else:
                if len(self.q) == 8 and self.q.isdigit():
                    res = self.env["consultadatos.mpi"].ver(self.q, '01')
                    if "errors" in res:
                        msg = len(res['errors']) and res['errors'][0].get('detail', 'Error Desconocido')
                        raise ValidationError(msg)
                    filiation = '****'
                    sis_estado = '****'
                    fecha_caducidad = False
                    # Si tiene seguro tipo 2 consulta SIS
                    if res.get('tipo_seguro') == '2':
                        datos_sis = self.env["consultadatos.mpi"].ver_datos_sis(
                            self.q, '01')
                        filiation = datos_sis.get("contrato")
                        fecha_caducidad = datos_sis.get("fecha_caducidad")
                        sis_estado = datos_sis.get("estado")

                    d = {
                        'patient_id': False,
                        'type_number': TYPE_DOC_EQUIVALENCE.get(
                            res.get('tipo_documento')),
                        'document_number': res.get('numero_documento'),
                        'complete_name': u'{} {} {}'.format(
                            res.get('nombres'), res.get('apellido_paterno'),
                            res.get('apellido_materno')),
                        'age': res.get('edad_str'),
                        'sex': res.get('sexo'),
                        'sis_estado': sis_estado,
                        'filiation_sis': filiation,
                        'filiation_sis_expiration': fecha_caducidad}
                    self.line_ids = [[0, False, d]]

    def search_childs(self):
        # Antes de cargar los nuevos item los limpia
        self.line_2_ids.unlink()
        if not self.q2:
            self.line_2_ids = []
        else:
            patients = self.env['oeh.medical.patient'].search([
                ('document_number', '=', self.q2)])
            list_patients = []
            if patients:
                for p in patients:
                    list_patients.append([0, False, {
                        'patient_id': p.id,
                        'type_number': p.type_number,
                        'document_number': p.document_number,
                        'complete_name': u'{} {} {}'.format(
                            p.first_name or p.name, p.last_name or "",
                            p.last_name_2 or ""),
                        'age': p.age,
                        'sex': p.sex,
                        'filiation_sis': p.affiliation_file_number,
                        'filiation_sis_expiration': p.affiliation_expiration}])

                self.line_2_ids = list_patients
            else:
                if len(self.q2) == 8 and self.q2.isdigit():
                    res = self.env["consultadatos.mpi"].ver(self.q2, '01')
                    if "error" in res:
                        raise ValidationError("\n".join(res.values()))
                    # Si tiene seguro tipo 2 consulta SIS
                    if res.get('tipo_seguro') == '2':
                        datos_sis = self.env["consultadatos.mpi"].ver_datos_sis(
                            self.q2, '01')
                        filiation_contrato = datos_sis.get("contrato")
                        filiation_expiracion = datos_sis.get("filiation_expiracion")
                    d = {
                        'patient_id': False,
                        'type_number': TYPE_DOC_EQUIVALENCE.get(
                            res.get('tipo_documento')),
                        'document_number': res.get('numero_documento'),
                        'complete_name': u'{} {} {}'.format(
                            res.get('nombres'), res.get('apellido_paterno'),
                            res.get('apellido_materno')),
                        'age': res.get('edad_str'),
                        'sex': SEX_EQUIVALENT.get(res.get('sexo')),
                        'filiation_sis': filiation_contrato,
                        'filiation_sis_expiration': filiation_expiracion}
                    self.line_2_ids = [[0, False, d]]


class WizardAppointmentLine(models.TransientModel):

    _name = 'wizard.appointment.line'
    _rec_name = "wizard_appointment_id"

    SEX = [
        ('1', 'Hombre'),
        ('2', 'Mujer'),
    ]

    wizard_appointment_id = fields.Many2one('wizard.appointment')
    patient_id = fields.Many2one(comodel_name='oeh.medical.patient')
    type_number = fields.Char(string='Tipo Doc.')
    document_number = fields.Char(string='Nro. Documento')
    complete_name = fields.Char(string='Nombres y Apellidos')
    age = fields.Char(string='Edad')
    sex = fields.Selection(SEX, u'Género')
    filiation_sis = fields.Char(u'Filiación SIS')
    filiation_sis_expiration = fields.Date(u'Filiación Expiración')
    sis_estado = fields.Char('SIS Estado')

    @api.multi
    def update_history(self):
        self.ensure_one()
        return {
            'name': u"Actualizar historial",
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'oeh.medical.patient',
            'view_id': self.env.ref('oehealth.oeh_medical_patient_view').id,
            'context': {},
            'res_id': self.patient_id.id
        }

    @api.multi
    def request_appointment(self):
        self.ensure_one()
        return {
            'name': u"Solicitar cita",
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'target': 'self',
            'res_model': 'oeh.medical.appointment.assign.wizard',
            'context': {
                'default_patient_id': self.patient_id.id,
            },
        }

    @api.multi
    def patient_file(self):
        self.ensure_one()

        sis_activo = False
        if self.sis_estado == ACTIVO:
            sis_activo = True

        return {
            'name': u"Crear paciente",
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'oeh.medical.patient',
            'target': 'self',
            'view_id': self.env.ref(
                'oehealth.oeh_medical_patient_view').id,
            'context': {
                'default_type_number': self.type_number,
                'default_document_number': self.document_number,
                'default_affiliation_file_number': self.filiation_sis,
                'default_affiliation_expiration': self.filiation_sis_expiration,
                'default_sis_activo': sis_activo,
                # 'default_sis_last_update': date.today().isoformat()
            },
        }


class WizardAppointmentLine2(models.TransientModel):

    _name = 'wizard.appointment.line2'
    _rec_name = "wizard_appointment_id"

    wizard_appointment_id = fields.Many2one('wizard.appointment')
    patient_id = fields.Many2one(comodel_name='oeh.medical.patient')
    type_number = fields.Char(string='Tipo Doc.')
    document_number = fields.Char(string='Nro. Documento')
    complete_name = fields.Char(string='Nombres y Apellidos')
    age = fields.Char(string='Edad')
    sex = fields.Char(string=u'Género')
    filiation_sis = fields.Char(string=u'Filiación SIS')

    @api.multi
    def update_history(self):
        self.ensure_one()
        return {
            'name': u"Actualizar histotial",
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'oeh.medical.patient',
            'view_id': self.env.ref('oehealth.oeh_medical_patient_view').id,
            'context': {},
            'res_id': self.patient_id.id
        }

    @api.multi
    def request_appointment(self):
        self.ensure_one()
        return {
            'name': u"Solicitar cita",
            'type': 'ir.actions.act_window',
            'view_mode': 'calendar',
            'res_model': 'oeh.medical.appointment',
            'view_id': self.env.ref(
                'oehealth.view_oeh_medical_event_calendar').id,
            'context': {
                'search_default_patient': self.patient_id.id,
                'default_patient': self.patient_id.id},
            'res_id': self.patient_id.id
        }

    @api.multi
    def patient_file(self):
        self.ensure_one()
        return {
            'name': u"Crear paciente",
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'oeh.medical.patient',
            'target': 'self',
            'view_id': self.env.ref(
                'oehealth.oeh_medical_patient_view').id,
            'context': {
                'default_document_number': self.document_number,
                # 'default_sis_last_update': date.today(),
                'default_sis_activo': self.sis_estado},
        }


class MinsaHealthAppointmentAssignWizard(models.TransientModel):
    _name = 'oeh.medical.appointment.assign.wizard'
    _rec_name = 'patient_id'

    _description = u'Wizard Asign appointments'

    days = 7

    def _default_date_end(self):
        return datetime.datetime.now() + datetime.timedelta(days=self.days)

    medicalcenter_id = fields.Many2one(
        'oeh.medical.health.center', u'Centro Médico/Hospital',
        default=lambda self: self.env['oeh.medical.health.center'].search([], limit=1), required=True,)
    patient_id = fields.Many2one('oeh.medical.patient', 'Paciente', required=True, ondelete='restrict')
    category_id = fields.Many2one('product.category', 'Servicio', required=True, domain=[('is_portfolio_service', '=', True)])
    line_ids = fields.One2many('oeh.medical.appointment.assign.wizard.bed', 'wizard_id', readonly=True)
    state = fields.Selection([('draft', 'Draft'), ('done', 'Done')], 'Estado')

    date_begin = fields.Datetime('Desde', default=fields.Datetime.now)
    date_end = fields.Datetime('Hasta')

    appointment_id = fields.Many2one('oeh.medical.appointment', 'Cita', readonly=True)
    # datos de la cita
    appointment_date = fields.Datetime(related='appointment_id.appointment_date', string='Fecha de Inicio', readonly=True)
    programming_bed_id = fields.Many2one(related='appointment_id.programmind_bed_id', string=u'Programación', readonly=True)
    doctor = fields.Many2one(related='appointment_id.doctor', string='Medico/Especialista', readonly=True)

    @api.constrains('date_begin', 'date_end')
    def _check_date(self):
        from_string = fields.Datetime.from_string
        if from_string(self.date_begin).date() < datetime.datetime.now().date():
            raise ValidationError('No se puede buscar en una fecha pasada')

        if from_string(self.date_begin) > from_string(self.date_end):
            raise ValidationError('Error en las fechas')

    @api.onchange('date_begin')
    def _onchange_date_begin(self):
        if self.date_begin:
            date_end = fields.Datetime.to_string(fields.Datetime.from_string(self.date_begin) + datetime.timedelta(days=self.days))
            return {'value': {'date_end': date_end}}

    @api.multi
    def action_search(self):
        tz = pytz.timezone(self.env.user.tz) if self.env.user.tz else pytz.timezone('America/Lima')
        offset = datetime.datetime.now(tz)
        offset = offset.utcoffset().total_seconds() / 3600

        self.line_ids.unlink()
        date_begin = fields.Datetime.from_string(self.date_begin)
        if date_begin < datetime.datetime.now():
            date_begin = datetime.datetime.now()
        date_end = fields.Datetime.from_string(self.date_end)

        hour_begin = date_begin.hour + (date_begin.minute / 60.0) + offset

        str_date_begin = fields.Datetime.to_string(date_begin.date())
        str_date_end = fields.Datetime.to_string(date_end.date())

        # Busca citas del paciente
        """
        Agrega restriccion en la busqueda de consultorio/Cama,  Turno en donde
        el paciente no pueda solicitar una cita en el mismo
        centro medico, Servicio, y dentro del intervalo
        """
        domain = [
            ('patient', '=', self.patient_id.id),
            ('programmind_bed_id.turn_id.medicalcenter_id', '=', self.medicalcenter_id.id),
            ('programmind_bed_id.bed_id.product_id.categ_id', '=', self.category_id.id),
            ('appointment_date', '>=', str_date_begin),
            ('appointment_date', '<=', str_date_end),
        ]

        programmind_bed_ids = []
        for appointment in self.env['oeh.medical.appointment'].search(domain):
            domain = [
                ('turn_id', '=', appointment.programmind_bed_id.turn_id.id),
                ('bed_id.product_id.categ_id', '=', self.category_id.id),
                ('date_day', '=', appointment.programmind_bed_id.date_day),
            ]
            if not self.category_id.appointment_only_category:
                domain.append(('bed_id.ward', '=', appointment.programmind_bed_id.bed_id.ward.id))

            programmind_bed_ids.extend(self.env['minsa.programming.bed'].search(domain).ids)
        programmind_bed_ids = list(set(programmind_bed_ids))
        # --

        model_programming_bed = self.env['minsa.programming.bed']
        domain = [('programming_id.medicalcenter_id', '=', self.medicalcenter_id.id),
                  ('bed_id.product_id.categ_id', '=', self.category_id.id),
                  ('date_day', '>=', str_date_begin),
                  ('date_day', '<=', str_date_end),
                  ('quotas', '>', 0),
                  ('state', '=', 'done')]

        if programmind_bed_ids:
            domain.extend([('id', 'not in', programmind_bed_ids)])

        programming_bed_ids = model_programming_bed.search(domain).ids

        domain = ['&',
                  ('id', 'in', programming_bed_ids),
                  '|',

                  # Cita para hoy
                  '&',
                  ('date_day', '=', str_date_begin),
                  '&',
                  ('turn_id.hour_begin', '<=', hour_begin),
                  ('turn_id.hour_end', '>=', hour_begin),

                  '|',
                  '&',
                  ('date_day', '=', str_date_begin),
                  ('turn_id.hour_begin', '>', hour_begin),

                  # Cita mas proxima
                  ('date_day', '>', str_date_begin)]

        for programming_bed in model_programming_bed.search(domain):
            values = {'wizard_id': self.id, 'programming_bed_id': programming_bed.id}
            self.line_ids.create(values)

        return {
            'flags': {'initial_mode': 'edit'},
        }

    @api.multi
    def action_view_calendar(self):
        self.ensure_one()
        return {
            'name': 'Ver en Calendario',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'calendar,form',
            'res_model': 'oeh.medical.appointment.assign.wizard.bed',
            'domain': [('wizard_id', '=', self.id)],
            'target': 'self',
        }


class MinsaHealthAppointmentAssignWizardBed(models.TransientModel):
    _name = 'oeh.medical.appointment.assign.wizard.bed'
    _rec_name = 'programming_bed_id'

    _description = u'Wizard Asign appointments - Bed'

    wizard_id = fields.Many2one('oeh.medical.appointment.assign.wizard')

    programming_bed_id = fields.Many2one('minsa.programming.bed', readonly=True)
    turn_id = fields.Many2one(related='programming_bed_id.turn_id', readonly=True)
    bed_id = fields.Many2one(related='programming_bed_id.bed_id', readonly=True)
    employee_id = fields.Many2one(related='programming_bed_id.employee_id', readonly=True)
    date_day = fields.Date(related='programming_bed_id.date_day')
    date_start = fields.Datetime(related='programming_bed_id.date_start', readonly=True, store=True)
    date_end = fields.Datetime(related='programming_bed_id.date_end', readonly=True, store=True)
    quotas = fields.Integer(related='programming_bed_id.quotas_enable', readonly=True)
    patient_id = fields.Many2one(related='wizard_id.patient_id', readonly=True)

    @api.multi
    def action_appointment_assign(self):
        """
        - Asignación del paciente en la cita
        - Si es paciente no asegurado, se crea factura borrador o pagada(paciente sis)
        """
        self.ensure_one()

        if not self.patient_id:
            return True

        if self.wizard_id.state == 'done':
            raise ValidationError('Ya cita ya fué asignada.')

        # Busca si el paciente ya tiene cita en el mismo dia
        domain = [
            ('programmind_bed_id', '=', self.programming_bed_id.id),
            ('patient', '=', False),
            ('appointment_date', '>=', self.wizard_id.date_begin),
            ('state', '=', 'Scheduled'),
        ]
        appointment = self.env['oeh.medical.appointment'].search(domain, limit=1, order='appointment_date')

        if not appointment:
            raise ValidationError('No se encontraron Citas disponibles para este horario')

        # Asignación del Paciente a la Cita
        appointment.patient = self.wizard_id.patient_id

        # Crear Invoice
        appointment.set_to_reserved()

        self.wizard_id.write(dict(appointment_id=appointment.id,
                                  state='done'))

        return {
            'name': u"Appointments",
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'oeh.medical.appointment',
            'view_id': self.env.ref('oehealth.oeh_medical_appointment_view').id,
            'context': {},
            'res_id': appointment.id
        }
