# -*- coding: utf-8 -*-

import datetime as dt
import json
import logging

import pytz
import requests

from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

datetime = dt.datetime
timedelta = dt.timedelta

ACTIVO = 'ACTIVO'

_logger = logging.getLogger(__name__)


TYPE_DOCUMENTO = [
    ('DNI', 'DNI'),
    ('PASAPORTE', 'PASAPORTE'),
    ('CARNETEXT', 'CARNET EXTRANGERIA'),
    ('NOTIENE', 'NO TIENE'),
]

TYPE_PACIENT = [
    ('new_patient', 'Paciente nuevo'),
    ('continuing_patient', 'Paciente continuador'),
]


class OehMedicalAppointment(models.Model):
    _inherit = 'oeh.medical.appointment'

    SEX = [
        ('Male', 'Hombre'),
        ('Female', 'Mujer'),
    ]

    APPOINTMENT_STATUS = [
        ('Scheduled', 'Programada'),
        ('Reserved', 'Reservada'),
        ('Invoiced', 'Pagada'),
        ('Triaded', 'Triada'),
        ('Completed', 'Atendida'),
    ]

    state = fields.Selection(APPOINTMENT_STATUS, string='State', readonly=True, default=lambda *a: 'Scheduled')

    patient = fields.Many2one('oeh.medical.patient', track_visibility='onchange')
    patient_mobile = fields.Char('Celular', related='patient.mobile', states={'Completed': [('readonly', True)]})

    # Variables para referencia
    is_reference = fields.Boolean(string='Es referencia', readonly=True, states={'Scheduled': [('readonly', False)]})
    ref_cod_eess_origen = fields.Char(string='Código Establecimiento Origen',)
    ref_id_eess_origen = fields.Char(string='Id Establecimiento Origen',)
    is_reference = fields.Boolean(string='Es referencia', readonly=True, states={'Scheduled': [('readonly', False)]})
    ref_service_origin = fields.Many2one('product.category', string="Servicio Origen")
    ref_date_atention = fields.Datetime(string='Hora de atencion')
    ref_ubigeo_referencia = fields.Char(string='Ubigeo de Residencia')
    ref_direccion_actual_paciente = fields.Char(string='Residencia Actual')
    ref_id = fields.Integer(string='Código de Referencia')
    ref_abstract_anam = fields.Text(string='Anamnesis')
    ref_exam_physical = fields.Text(string='Examen Fisico')
    ref_exam_aux = fields.Text(string='Examen Auxiliar')
    ref_coordination_reference = fields.Char(string="Coordinacion de Rerencia")
    ref_institution_destination = fields.Char(string='Institucion Destino')
    ref_type_coordination_reference = fields.Selection(
        string='Tipo de Referencia',
        selection=[
            ('emergency', 'Emergencia'),
            ('consultant', 'Consulta Externa'),
            ('support', 'Apoyo al diagnostico')
        ])
    ref_codition_patient_begin = fields.Selection(
        string='Condiciones al inicio del traslado',
        selection=[('stable', 'Estable'), ('wrong', 'Mal Estado'), ('serius', 'Grave')]
    )
    ref_codition_patient_reception = fields.Selection(
        string='Condicion a la llegada del EESS destino',
        selection=[('stable', 'Estable'), ('wrong', 'Mal Estado'), ('serius', 'Grave')]
    )
    ref_type_transport = fields.Selection(
        string='Tipo de Transporte',
        selection=[('none', 'Ninguno'),
                   ('air', 'Aereo'),
                   ('fluvial', 'Fluvial'),
                   ('maritime', 'Maritimo'),
                   ('terra', 'Terrestre')])
    ref_motive_reference = fields.Selection(
        string='Motivo de la Referencia',
        selection=[('none', 'No Capacidad resolutiva (por el nivel del EESS)'),
                   ('specialty', 'No capacidad resolutiva por carecer de determinado especialista'),
                   ('insumo', 'No capacidad resolutiva por carecer de determinado insumo'),
                   ('operative', 'No capacidad resolutiva por no contar con determinado servicio operativo'),
                   ('reparation', 'No capacidad resolutiva por servicio en reparación'),
                   ('saturated', 'No capacidad resolutiva por servicio saturado'),
                   ('essalud', 'Por ser titular de ESSALUD'),
                   ('team', 'No capacidad resolutiva por carecer de determinado equipo'),
                   ('infraestructure', 'No capacidad resolutiva por carecer de determinada infraestructura')])

    ref_observacion_reference = fields.Char()
    invoice_id = fields.Many2one('account.invoice', 'Factura', readonly=True)
    evalution_id = fields.Many2one('oeh.medical.evaluation', 'Evaluacion')
    check_appointment_date = fields.Boolean('Check Date', compute='_compute_appointment_date')

    sms_sent_date = fields.Datetime('Envio sms', track_visibility='onchange')
    sms_text = fields.Char('Sms', track_visibility='onchange')
    sms_ids = fields.One2many(
        'oehealth.appointment.sms', 'res_id',
        domain=lambda self: [('res_model', '=', self._name)],
        string='Mensajes SMS', readonly=True)
    admition_user_id = fields.Many2one(
        comodel_name='res.users',
        string=u'Admisionista',
    )

    # Atributos para Reporte FUA(JASPER)
    code_eess_print = fields.Char(related='institution.code_renipress', store=True)
    name_eess_print = fields.Char(related='institution.name', store=True)
    type_number_print = fields.Selection(TYPE_DOCUMENTO, related='patient.type_number', store=True)
    document_number_print = fields.Char(related='patient.document_number', store=True)
    affiliation_file_number_print = fields.Char(related='patient.affiliation_file_number', store=True)
    last_name_print = fields.Char(related='patient.last_name', store=True)
    last_name_2_print = fields.Char(related='patient.last_name_2', store=True)
    first_name_print = fields.Char(related='patient.first_name', store=True)
    sex_patient = fields.Selection(SEX, related='patient.sex', readonly=True, store=True)
    dob_print = fields.Date(related='patient.dob', store=True)
    dni_print = fields.Char(related='doctor.identification_id')
    name_print = fields.Char(related='doctor.name', store=True)
    type_pacient = fields.Selection(
        selection=TYPE_PACIENT, compute='_compute_type_pacient', string='Tipo de paciente')
    triage_id = fields.Many2one('oeh.medical.evaluation.triage', string='Triaje')
    sis_activo = fields.Boolean('¿Cuenta con SIS activo?', compute='valida_sis_activo', store=True)
    doc_date = fields.Date('Fecha de documento')

    @api.one
    def valida_sis_activo(self):
        return self.patient.sis_ok

    @api.one
    @api.depends('patient', 'institution')
    def _compute_type_pacient(self):
        appointment_model = self.search([
            ('patient', '=', self.patient.id), ('institution', '=', self.institution.id)], limit=1)
        if not self.patient or not self.institution:
            self.type_pacient = False
        elif appointment_model.exists():
            self.type_pacient = 'continuing_patient'
        else:
            self.type_pacient = 'new_patient'

    @api.constrains('patient')
    def _check_only_appointment(self):
        """
        Restriccion el paciente no puede tener otra cita en el mismo:
        centro medico, servicio, fecha, turno
        """
        if not self.id or not (self.patient and self.programmind_bed_id, self.appointment_date):
            return True

        domain = [
            ('patient', '=', self.patient.id),
            ('programmind_bed_id.turn_id.medicalcenter_id', '=', self.programmind_bed_id.turn_id.medicalcenter_id.id),
            ('programmind_bed_id.bed_id.product_id.categ_id', '=', self.programmind_bed_id.bed_id.product_id.categ_id.id),
            ('programmind_bed_id.turn_id', '=', self.programmind_bed_id.turn_id.id),
            ('appointment_date', '>=', self.programmind_bed_id.date_start),
            ('appointment_date', '<=', self.programmind_bed_id.date_end),
            ('id', '!=', self.id)
        ]

        if not self.programmind_bed_id.bed_id.product_id.categ_id.appointment_only_category:
                domain.append(('programmind_bed_id.bed_id.ward', '=', self.programmind_bed_id.bed_id.ward.id))

        if self.search(domain, limit=1):
            raise ValidationError('El Paciente ya tiene Cita en el mismo Dia/Servicio/Turno')

    @api.multi
    def _compute_appointment_date(self):
        for record in self:
            appointment_date = record.appointment_date and fields.Datetime.from_string(record.appointment_date)
            now = fields.Datetime.from_string(fields.Datetime.now())
            record.check_appointment_date = appointment_date and (now < appointment_date)

    @api.multi
    def generated_evolucion(self):

        return {
            'string': 'Citas',
            'name': 'Citas',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': False,
            'res_model': 'oeh.medical.evaluation',
            'domain': [],
            'context': {
                'evaluation_start_date': self.appointment_date,
                'default_doctor': self.doctor.id,
                'default_patient': self.patient.id,
                'default_appointment': self.id,
                # Si tiene asociado triaje precarga los datos
                'default_sv_temperatura': self.triage_id.sv_temperatura,
                'default_sv_presionarterial': self.triage_id.sv_presionarterial,
                'default_sv_freccardiaca': self.triage_id.sv_freccardiaca,
                'default_sv_frecrespiratoria': self.triage_id.sv_frecrespiratoria,
                'default_sv_saturacion': self.triage_id.sv_saturacion,
                'default_da_peso_g': self.triage_id.da_peso_g,
                'default_da_talla_cm': self.triage_id.da_talla_cm,
                'default_da_peso_kg': self.triage_id.da_peso_kg,
                'default_da_talla_m': self.triage_id.da_talla_m,
                'default_da_estado_imc': self.triage_id.da_estado_imc
            },
            'target': 'online',
            'type': 'ir.actions.act_window',
            'res_id': self.evalution_id.id
        }

    @api.multi
    def set_to_reserved(self, is_additional=False):
        for record in self:
            if not record.patient:
                raise ValidationError('No se asigno el Paciente')

            record.write({
                'state': 'Reserved',
                'admition_user_id': self.env.user.id
            })
            record.action_appointment_invoice_create(is_additional)

        return True

    def action_appointment_invoice_create(self, is_additional=False):
        invoice_model = self.env["account.invoice"]
        invoice_line_model = self.env["account.invoice.line"]
        invoice_ids = []

        for acc in self:
            # Valida si tiene historia clínica
            if not acc.patient.identification_code:
                raise ValidationError(u'Paciente no tiene historia clínica. Por favor valide e intente nuevamente.')
            # Busca si tiene habilitado el seguro sis y aplica descuento al 100%
            discount = acc.patient.sis_estado == ACTIVO and 100 or 0

            price_unit = acc.programmind_bed_id.bed_id.product_id.list_price
            # Create Invoice
            if acc.patient:
                curr_invoice = {
                    'partner_id': acc.patient.partner_id.id,
                    'account_id': acc.patient.partner_id.property_account_receivable_id.id,
                    'patient': acc.patient.id,
                    'state': 'draft',
                    'type': 'out_invoice',
                    'date_invoice': acc.appointment_date,
                    'origin': "Appointment # : " + acc.name,
                }

                invoice = invoice_model.create(curr_invoice)
                t = (invoice.number or '#', acc.name or 'AP#')
                _logger.info('Se crea la factura {} para la cita {}'.format(*t))

                acc.invoice_id = invoice
                invoice_ids.append(invoice.id)
                prd_account_id = self._default_account()
                # Create Invoice line
                curr_invoice_line = {
                    'name': "Consultancy invoice for " + acc.name,
                    'price_unit': price_unit,
                    'discount': discount,
                    'quantity': 1,
                    'account_id': prd_account_id,
                    'invoice_id': invoice.id,
                }
                invoice_line_model.create(curr_invoice_line)

                if acc.patient.sis_estado == ACTIVO and acc.doc_date == datetime.today().date().strftime('%Y-%m-%d'):
                    _logger.info('El paciente tiene sis activo, La factura {} '
                                 'de la cita {} es cubierta por el seguro'.format(*t))
                    invoice.action_invoice_open()
                else:
                    _logger.info('El paciente NO tiene sis')

        if not invoice_ids:
            return {}

        if not is_additional:
            return {'domain': "[('id', 'in', " + str(tuple(invoice_ids)) + ")]",
                    'name': _('Appointment Invoice'),
                    'view_type': 'form',
                    'view_mode': 'tree,form',
                    'res_model': 'account.invoice',
                    'type': 'ir.actions.act_window'}

    @api.multi
    def set_to_invoiced(self):
        for record in self:
            if record.state not in ('Scheduled', 'Reserved') and record.state != 'Invoiced':
                raise ValidationError(u'La cita debe estar en Programada o Reservada')
            record.state = 'Invoiced'
            record.send_sms()
        return True

    @api.multi
    def set_to_completed(self):
        for record in self:
            if record.state == 'Completed':
                raise ValidationError(u'La cita ya fué atendida')
        return super(OehMedicalAppointment, self).set_to_completed()

    @api.model
    def _cron_auto_payment(self):
        today = datetime.today().date()

        domain = [('state', '=', 'Reserved'), ('doc_date', '=', today)]

        appointmentments = self.search(domain)

        for appointment in appointmentments:
            appointment.invoice_id.action_invoice_open()

    @api.multi
    def send_sms(self):
        """
        Envia mensaje de texto cuando el estado de la cita ha sido "Completed"
        """
        tz = pytz.timezone(self.env.user.tz) if self.env.user.tz else pytz.timezone('America/Lima')
        offset = datetime.now(tz)
        offset = offset.utcoffset().total_seconds() / 3600
        from_form = self._context.get('from_form', False)
        for record in self:
            if not record.patient:
                message = 'La cita {} no tiene paciente establecido'.format(record.name or '#')
                if from_form:
                    raise ValidationError(message)
                _logger.info(message)
                continue

            if not record.appointment_date:
                message = 'La cita {} no tiene fecha'.format(record.name or '#')
                if from_form:
                    raise ValidationError(message)
                _logger.info(message)
                continue

            if fields.Datetime.from_string(record.appointment_date) < datetime.now():
                message = 'La cita {} tiene fecha pasada'.format(record.name or '#')
                if from_form:
                    raise ValidationError(message)
                _logger.info(message)
                continue

            if record.patient.mobile:
                appointment_date = fields.Datetime.from_string(record.appointment_date) + timedelta(hours=offset)
                appointment_date = appointment_date.strftime('%d-%m-%Y %I:%M %p')
                vals = (record.institution.name,
                        appointment_date,
                        record.doctor.name,
                        record.programmind_bed_id.bed_id.name,)
                msg = u'Ud. tiene una cita programada en {} para el {} con el Dr. {} en el consultorio {}'.format(*vals)
                record.sms_text = msg

                self.env['oehealth.appointment.sms'].create({
                    'msg': msg,
                    'number': '51' + str(self.patient.mobile),
                    'partner_id': self.patient.partner_id.id,
                    'res_model': self._name,
                    'res_id': record.id,
                })
                t = (record.id, record.name, appointment_date)
                _logger.info('Id. {} | Se envio  en cola el sms para la cita: {} para el : {}'.format(*t))
            else:
                t = (record.id, record.name)
                if from_form:
                    raise ValidationError('El paciente no tiene #celular')
                _logger.info('Id. {} No se envio la sms de la cita {}, el paciente no tiene #celular'.format(*t))

    def show_triage(self):
        return {
            'name': "Triaje",
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'oeh.medical.evaluation.triage',
            'view_id': self.env.ref(
                'oehealth_evaluation_minsa.oeh_medical_evaluation_triage_view_form').id,
            'context': {
                'default_appointment_id': self.id,
                'default_patient_id': self.patient.id},
            'res_id': self.triage_id.id,
        }

    @api.multi
    def goto_attendance_form(self):
        self.ensure_one()
        return {
            'string': 'Consulta externa (Evaluaciones)',
            'name': 'Consulta externa (Evaluaciones)',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': False,
            'res_model': 'oeh.medical.evaluation',
            'domain': [],
            'context': {
                'evaluation_start_date': self.appointment_date,
                'default_doctor': self.doctor.id,
                'default_patient': self.patient.id,
                'default_appointment': self.id,
                # Si tiene asociado triaje precarga los datos
                'default_sv_temperatura': self.triage_id.sv_temperatura,
                'default_sv_presionarterial': self.triage_id.sv_presionarterial,
                'default_sv_freccardiaca': self.triage_id.sv_freccardiaca,
                'default_sv_frecrespiratoria': self.triage_id.sv_frecrespiratoria,
                'default_sv_saturacion': self.triage_id.sv_saturacion,
                'default_da_peso_g': self.triage_id.da_peso_g,
                'default_da_talla_cm': self.triage_id.da_talla_cm,
                'default_da_peso_kg': self.triage_id.da_peso_kg,
                'default_da_talla_m': self.triage_id.da_talla_m,
                'default_da_estado_imc': self.triage_id.da_estado_imc
            },
            'target': 'online',
            'type': 'ir.actions.act_window',
            'res_id': self.evalution_id.id
        }

    @api.multi
    def goto_triage_form(self):
        self.ensure_one()
        return {
            'string': 'Triaje',
            'name': 'Triaje',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': False,
            'res_model': 'oeh.medical.evaluation.triage',
            'domain': [],
            'context': {
                'default_patient_id': self.patient.id,
                'default_appointment_id': self.id,
                # Si tiene asociado triaje precarga los datos
                'default_sv_temperatura': self.triage_id.sv_temperatura,
                'default_sv_presionarterial': self.triage_id.sv_presionarterial,
                'default_sv_freccardiaca': self.triage_id.sv_freccardiaca,
                'default_sv_frecrespiratoria': self.triage_id.sv_frecrespiratoria,
                'default_sv_saturacion': self.triage_id.sv_saturacion,
                'default_da_peso_g': self.triage_id.da_peso_g,
                'default_da_talla_cm': self.triage_id.da_talla_cm,
                'default_da_peso_kg': self.triage_id.da_peso_kg,
                'default_da_talla_m': self.triage_id.da_talla_m,
                'default_da_estado_imc': self.triage_id.da_estado_imc
            },
            'target': 'online',
            'type': 'ir.actions.act_window',
            'res_id': self.evalution_id.id
        }

    @api.multi
    def goto_triage_view_form(self):
        self.ensure_one()
        return {
            'string': 'Triaje',
            'name': 'Triaje',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': False,
            'res_model': 'oeh.medical.evaluation.triage',
            'domain': [],
            'context': {
                'default_patient_id': self.patient.id,
                'default_appointment_id': self.id,
            },
            'target': 'online',
            'type': 'ir.actions.act_window',
            'res_id': self.triage_id.id
        }

    @api.multi
    def goto_attended_detail(self):
        self.ensure_one()
        return {
            'string': 'Consulta externa (Evaluaciones)',
            'name': 'Consulta externa (Evaluaciones)',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': False,
            'res_model': 'oeh.medical.evaluation',
            'domain': [],
            'context': {
                'evaluation_start_date': self.appointment_date,
                'default_doctor': self.doctor.id,
                'default_patient': self.patient.id,
                'default_appointment': self.id,
                # Si tiene asociado triaje precarga los datos
                'default_sv_temperatura': self.triage_id.sv_temperatura,
                'default_sv_presionarterial': self.triage_id.sv_presionarterial,
                'default_sv_freccardiaca': self.triage_id.sv_freccardiaca,
                'default_sv_frecrespiratoria': self.triage_id.sv_frecrespiratoria,
                'default_sv_saturacion': self.triage_id.sv_saturacion,
                'default_da_peso_g': self.triage_id.da_peso_g,
                'default_da_talla_cm': self.triage_id.da_talla_cm,
                'default_da_peso_kg': self.triage_id.da_peso_kg,
                'default_da_talla_m': self.triage_id.da_talla_m,
                'default_da_estado_imc': self.triage_id.da_estado_imc
            },
            'target': 'online',
            'type': 'ir.actions.act_window',
            'res_id': self.evalution_id.id
        }


class OeHealthAppointmentSMS(models.Model):
    _name = 'oehealth.appointment.sms'
    _order = 'res_model,res_id,create_date desc'

    STATE_SEND = 'send'
    STATE_PENDING = 'pending'
    STATE_ERROR_NOEXIST = 'error_noexist'
    STATE_ERROR_LENGTH = 'error_length'
    STATE_OUTDATE = 'error_outdate'
    STATE_CANCEL = 'cancel'
    MAX_LENGTH = 153

    STATUS = [
        (STATE_SEND, 'Enviado'),
        (STATE_PENDING, 'Pendiente'),
        (STATE_ERROR_NOEXIST, 'Recurso no existe'),
        (STATE_ERROR_LENGTH, 'Exceso longitud'),
        (STATE_OUTDATE, 'Fuera de Fecha'),
        (STATE_CANCEL, 'Cancelado'),
    ]

    msg = fields.Text(string='Mensaje', size=140, required=True)
    state = fields.Selection(STATUS, string='Estado', default='pending')
    number = fields.Char(string='Numero', size=15, required=True)
    partner_id = fields.Many2one('res.partner', 'Partner')

    res_model = fields.Char('Modelo del Recurso', size=100)
    res_id = fields.Integer('Id del Recurso')

    @api.model
    def _cron_send_sms(self, limit=100):
        get_param = self.env['ir.config_parameter'].sudo().get_param
        api_host = get_param('sms_api_host')
        api_token = get_param('sms_api_token')
        sms_sender = get_param('sms_sender')

        if not api_host:
            _logger.error('Error en parametro odoo sms_api_token')
            return

        if not api_token:
            _logger.error('Error en parametro odoo api_token')
            return

        if not sms_sender:
            _logger.error('Error en parametro odoo sms_sender')
            return

        # Mensajes con exceso de longitud
        sql = '''UPDATE {table}
                 SET state='{state_error_length}'
                 WHERE
                    LENGTH(msg) > {max_length} and
                    state='{state_pending}'
        '''.format(
            table=self._table,
            max_length=self.MAX_LENGTH,
            state_pending=self.STATE_PENDING,
            state_error_length=self.STATE_ERROR_LENGTH)
        self._cr.execute(sql)

        records = self.search([('state', '=', self.STATE_PENDING)], limit=limit)

        model_appointment = 'oeh.medical.appointment'

        # Verifica que aun existan los registros
        '''
        res_model_vals =  {res_model: {res_id: record.id, ...}}
        '''
        record_ids = records.ids
        active_ids = list()
        res_model_vals = dict()
        for record in records:
            if record.res_model not in res_model_vals:
                res_model_vals[record.res_model] = dict()
            res_model_vals[record.res_model][record.res_id] = record.id

        for res_model, vals in res_model_vals.iteritems():
            model = self.env.get(record.res_model)
            if model is None:
                model_active_ids = []
            else:
                model_res_ids = [res_id for res_id, record_id in vals.iteritems()]
                domain = [('id', 'in', model_res_ids)]
                model_res_exists_ids = model.search(domain).ids
                model_active_ids = [vals[res_id] for res_id in model_res_exists_ids]
            active_ids.extend(model_active_ids)

        noexiste_ids = list(set(record_ids) - set(active_ids))

        self.browse(noexiste_ids).write({'state': self.STATE_ERROR_NOEXIST})
        records = self.browse(active_ids)

        for record in records:
            if record.res_model == model_appointment:
                appointment = self.env[model_appointment].browse(record.res_id)

                if not appointment.check_appointment_date:
                    record.state = self.STATE_OUTDATE
                    continue

            res = requests.post(api_host, {
                'recipient': record.number,
                'sender': sms_sender,
                'body': record.msg
            }, headers={
                'X-Api-Token': api_token
            })

            # Verifica envio sms
            res_json = res.status_code == 201 and res.text and json.loads(res.text) or {}
            if res_json:
                record.state = self.STATE_SEND
                if record.res_model == model_appointment and record.res_id:
                    self.env[record.res_model].browse(record.res_id).sms_sent_date = fields.Datetime.now()
            else:
                _logger.info(res.text)

        return True
