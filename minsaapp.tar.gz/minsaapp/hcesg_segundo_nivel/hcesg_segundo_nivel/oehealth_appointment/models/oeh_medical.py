# -*- coding: utf-8 -*-

from odoo import api, fields, models


class OehMedicalPatient(models.Model):
    _inherit = 'oeh.medical.patient'

    oeh_parent_id = fields.Many2one(
        'oeh.medical.patient', string='Parent')
    oeh_child_ids = fields.One2many(
        'oeh.medical.patient', 'oeh_parent_id', string='Childs')

    @api.multi
    def request_appointment(self):
        self.ensure_one()
        return {
            'name': u'Solicitar cita',
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'target': 'self',
            'res_model': 'oeh.medical.appointment.assign.wizard',
            'context': {
                'default_patient_id': self.id,
            },
        }


TYPE_DOCUMENTO = [
    ('DNI', 'DNI'),
    ('PASAPORTE', 'PASAPORTE'),
    ('CARNETEXT', 'CARNET EXTRANGERIA'),
    ('NOTIENE', 'NO TIENE'),
]


class OeHealthPatientEvaluation(models.Model):
    _inherit = 'oeh.medical.evaluation'

    eess = fields.Many2one(
        comodel_name='oeh.medical.health.center',
        string=u'EESS',
        default=lambda self: self.env.user.partner_id.company_id.center_id.id
    )
    code_eess_print = fields.Char(related='eess.code_renipress', store=True)
    name_eess_print = fields.Char(related='eess.name', store=True)
    type_number_print = fields.Selection(TYPE_DOCUMENTO, related='patient.type_number', store=True)
    document_number_print = fields.Char(related='patient.document_number', store=True)
    affiliation_file_number_print = fields.Char(related='patient.affiliation_file_number', store=True)
    last_name_print = fields.Char(related='patient.last_name', store=True)
    last_name_2_print = fields.Char(related='patient.last_name_2', store=True)
    first_name_print = fields.Char(related='patient.first_name', store=True)
    dob_print = fields.Date(related='patient.dob', store=True)
    dni_print = fields.Char(related='doctor.identification_id', store=True)
    name_print = fields.Char(related='doctor.name', store=True)

    bed_id = fields.Many2one(related='appointment.programmind_bed_id', store=True)
    doc_especialidad_codigo = fields.Char(related='doctor.speciality.code', store=True)
    doc_especialidad_nombre = fields.Char(related='doctor.speciality.name', store=True)
