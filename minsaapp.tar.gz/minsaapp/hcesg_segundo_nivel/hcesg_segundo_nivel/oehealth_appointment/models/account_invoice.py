# -*- coding: utf-8 -*-

import datetime
import dateutil
import logging

from odoo import api, fields, models
from odoo.exceptions import ValidationError
from odoo.exceptions import Warning as UserError
from odoo.tools.translate import _

_logger = logging.getLogger(__name__)


ACTIVO = 'ACTIVO'


class AccountInvoice(models.Model):
    _inherit = 'account.invoice'

    appointment_id = fields.Many2one(
        'oeh.medical.appointment', compute='_compute_appointment_id')

    @api.one
    def _compute_appointment_id(self):
        appointment_model = self.env['oeh.medical.appointment']
        appointment = appointment_model.search([
            ('invoice_id', '=', self.id)], limit=1)
        self.appointment_id = appointment.id

    @api.multi
    def action_invoice_open(self):
        # lots of duplicate calls to action_invoice_open, so we remove those already open
        sis_activo = self.appointment_id.patient.sis_estado == ACTIVO
        if sis_activo:
            # día de la cita
            if dateutil.parser.parse(self.appointment_id.appointment_date).date() == datetime.datetime.now().date():
                self.invoice_line_ids.write({'discount': 100})
            else:
                raise ValidationError('No se puede generar la factura. NO corresonponde a su fecha de cita.')
        else:
            self.invoice_line_ids.write({'discount': 0})

        self.appointment_id.write({'sis_activo': sis_activo})

        to_open_invoices = self.filtered(lambda inv: inv.state != 'open')
        if to_open_invoices.filtered(lambda inv: inv.state not in ['proforma2', 'draft']):
            raise UserError(_("Invoice must be in draft or Pro-forma state in order to validate it."))
        to_open_invoices.action_date_assign()
        to_open_invoices.action_move_create()
        return to_open_invoices.invoice_validate()

    @api.multi
    def write(self, vals):
        """
        Si el estado de la factura es `Pagado(paid)`, y existe una cita que invoice_id es igual al id de la factura,
        la cita pasa a `Pagado(invoiced)`.
        """
        if vals.get('state') == 'paid':
            appointment_model = self.env['oeh.medical.appointment']
            for record in self:
                domain = [
                    ('state', 'not in', ('Completed', 'Invoiced')),
                    ('invoice_id', '=', record.id),
                    ('invoice_id.state', '!=', 'paid'),
                ]
                appointment = appointment_model.search(domain, limit=1)
                if appointment:
                    t = (record.number, appointment.name)
                    _logger.info('Factura `{}` de la Cita`{}` fue pagada'.format(*t))
                    appointment.set_to_invoiced()

        return super(AccountInvoice, self).write(vals)

    @api.multi
    def invoice_print_appointment(self):
        self.ensure_one()
        return self.env['report'].get_action(self.appointment_id, 'oehealth.report_appointment_receipt')
