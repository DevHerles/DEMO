openerp.oehealth_appointment = function (instance,local) {
    var qWeb = instance.web.qweb;
    var _t = instance.web._t;

    var PACIENT = 'oeh.medical.patient'
    var APPOINTMENT = 'oeh.medical.appointment'
    var UNDEFINED = 'Módulo indefinido'
    var ACTIVO = 'ACTIVO'

    instance.alert = {};

    instance.alert.alertConsolidate = instance.web.form.FormWidget.extend({
        init: function () {
            this._super.apply(this, arguments);
            this.eess = '';
            this.message = '';
            this.class = 'no-tiene';
        },
        start: function () {
            var self = this;
            this.field_manager.on("load_record", this, function() { this._render(); });
            $.when.apply($, this.promises).then(function () {
                self._render();
            });
        },
        _render: function () {
            if (this.view.model == PACIENT) {
                this.sis_estado = this.view.datarecord.sis_estado;
                if(this.sis_estado == ACTIVO) {
                    this.class = 'si-tiene';
                    this.message = 'SIS ACTIVO';
                    this.eess = 'EESS: ' + this.view.datarecord.sis_eess_nombre + ' - ' + this.view.datarecord.sis_nro_contrato;
                } else {
                  if(this.view.datarecord.sis_activo) {
                    this.class = 'pendiente';
                    this.message = 'SIS ACTIVO, por favor guarde los datos de paciente.'
                    this.eess = '';
                  }else{
                    this.class = 'no-tiene';
                    this.message = 'PACIENTE NO CUENTA CON SIS ACTIVO'
                    this.eess = '';
                  }
                }
            }else if (this.view.model == APPOINTMENT) {
                this.message = 'PONG PONG';
            }else {
                this.message = UNDEFINED
            }
            this.$el.html(qWeb.render('alert.alertConsolidate', {widget: this}));
            if(this.notification_manager) {
                this.notification_manager.notify('e.data.title', 'e.data.message', 20);
            }
        },
    });
    instance.web.form.custom_widgets.add('alert_consolidate', 'instance.alert.alertConsolidate');
};
