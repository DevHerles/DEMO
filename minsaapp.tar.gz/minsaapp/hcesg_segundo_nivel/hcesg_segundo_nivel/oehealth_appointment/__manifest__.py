# -*- coding: utf-8 -*-

{
    'name': u'Extendiendo el modulo de citas oehealth_appointment ',
    'version': '1.0',
    'author': 'MINSA',
    'website': 'www.minsa.gob.pe',
    'category': 'Medical',
    'description': """
Depends:
===========================
- oehealth
""",
    'depends': [
        'consultadatos',
        'oehealth',
        'oehealth_extra_addons',
        'oehealth_medical_patient_minsa',
        'minsa_programming',
    ],

    'external_dependencies': {
        'python': []
    },

    'data': [
        'views/oeh_appointment_assets.xml',
        'views/product_views.xml',
        'views/oeh_appointment_views.xml',
        'views/oeh_medical_views.xml',
        'views/oeh_appointment_reports.xml',
        'views/oeh_appointment_trees.xml',
        'views/oeh_appointment_actions.xml',
        'views/oeh_appointment_menus.xml',
        'views/oeh_appointment_wizard_views.xml',
        'data/appointment_sendsms_data.xml',
        'security/ir.model.access.csv',
    ],
    'qweb': [
        'static/src/xml/*.xml',
    ],
    'active': False,
    'installable': True
}
