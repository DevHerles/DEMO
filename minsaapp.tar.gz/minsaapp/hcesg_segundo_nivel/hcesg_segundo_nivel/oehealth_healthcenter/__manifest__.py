# -*- coding: utf-8 -*-
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl.html).

{
    'name': 'Ficha de EESS',
    'version': '10.0.1.0.2',
    'category': 'Medical',
    'depends': [
        'product',
        'oehealth',
        'renaes',
    ],
    'author': 'MINSA',
    'website': 'http://www.minsa.gob.pe/',
    'license': 'LGPL-3',
    'data': [
        'views/product_views.xml',
        'views/oehealth_medical_views.xml',
        'security/ir.model.access.csv',
    ],
    'demo': [
    ],
    'installable': True,
    'application': True,
}
