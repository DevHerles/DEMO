# -*- coding: utf-8 -*-

from odoo import fields, models


class InstitucionBase(models.AbstractModel):
    _inherit = 'renaes.institucion_base'

    name = fields.Char('Nombre', size=100, required=True)

    state = fields.Selection([
        ('active', 'Activo'),
        ('inactive', 'Inactivo'),
    ], 'Estado', default='active')
