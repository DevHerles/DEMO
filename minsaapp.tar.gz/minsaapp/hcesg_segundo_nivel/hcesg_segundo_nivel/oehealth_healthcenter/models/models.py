# -*- coding: utf-8 -*-


from odoo import api, fields, models

SELECTION_TYPE = [
    ('TO', 'Todos'),
    ('CE', 'Consultorio'),
    ('EM', 'Emergencia'),
    ('QX', 'Cirujia'),
    ('HO', 'Hospitalizacion'),
]


class CompanyTurn(models.Model):
    _name = 'minsa.company.turn'
    _inherit = ['ir.needaction_mixin']

    @api.multi
    def name_get(self):
        return [(obj.id, u'{} - ({} - {})'.format(
            obj.type or '', obj.hour_begin or '', obj.hour_end or ''
        )) for obj in self]

    medicalcenter_id = fields.Many2one(
        'oeh.medical.health.center',
        'Centro de Salud',
        required=True,
    )
    hour_begin = fields.Float('Hora Inicio', required=True)
    hour_end = fields.Float('Hora Fin', required=True)
    hours = fields.Integer('Horas', compute='_compute_hours')
    programming = fields.Boolean(
        u'Programacion Automatica',
    )
    type = fields.Selection(
        [
            ('Manana', u'Mañana'),
            ('Tarde', u'Tarde'),
            ('Guardia_Diurna', u'Guardia Diurna'),
            ('Guardia_Nocturna', u'Guardia Nocturna'),
            ('Guardia_Comunitaria', u'Guardia Comunitaria'),
        ],
        'Turno',
        default='Manana')

    apply_for = fields.Selection(SELECTION_TYPE, 'Aplica para', default='TO')

    @api.model
    def _needaction_domain_get(self):
        return [(1, '=', 1)]

    def _compute_hours(self):
        for record in self:
            delta = record.hour_end - record.hour_begin
            record.update({'hours': delta})


class EESSInstitution(models.Model):
    _name = 'minsa.company.institution'

    codigo = fields.Char('Codigo Renaes/Renipress')
    name = fields.Char('Categoria', required=True)
    _sql_constraints = [
        ('field_unique_name',
         'unique(name)',
         'El nombre debe de ser UNICO!')
    ]


class EESSCategory(models.Model):
    _name = 'minsa.company.category'

    name = fields.Char('Categoria', required=True)
    _sql_constraints = [
        ('field_unique_name',
         'unique(name)',
         'El nombre debe de ser UNICO!')
    ]


class EESSUnitExecutor(models.Model):
    _name = 'minsa.company.unitexecutor'

    name = fields.Char('Unidad Ejecutora', required=True)
    _sql_constraints = [
        ('field_unique_name',
         'unique(name)',
         'El nombre debe de ser UNICO!')
    ]
