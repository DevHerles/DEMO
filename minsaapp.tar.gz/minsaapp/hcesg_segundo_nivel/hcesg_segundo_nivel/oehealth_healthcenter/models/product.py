# -*- coding: utf-8 -*-


from odoo import api, fields, models


class CategoryProductSpeciality(models.Model):
    _name = 'product.category.speciality'

    categ_id = fields.Many2one('product.category', string="Categoria")
    speciality_id = fields.Many2one('oeh.medical.speciality', string="Especialidades")


class ProductCategory(models.Model):
    _inherit = 'product.category'

    is_portfolio_service = fields.Boolean('Portafolio Asistencial')
    speciality_ids = fields.One2many(
        'product.category.speciality',
        'categ_id',
        string="Especialidades"
    )


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    # Portafolio Servicio
    is_portfolio_service = fields.Boolean('Portafolio Servicio')
    number_atention_default = fields.Integer(
        string='# Atenciones',
        default=20
    )
    number_atention_extra_default = fields.Integer(
        string='# Adicionales Atenciones',
        default=3
    )

    is_sis = fields.Boolean('Cubre SIS')
    sync = fields.Boolean('Sincronizado')

    # Consultar sobre atributo tipo_producto si existe
    @api.onchange('tipo_producto')
    def _onchange_tipo_producto(self):
        if self.tipo_producto == 'medicamento':
            self.type = 'product'
            self.sale_ok = True
            self.purchase_ok = True
        if self.tipo_producto in ['cpt', 'cartera']:
            self.type = 'service'
            self.sale_ok = True
            self.purchase_ok = False
