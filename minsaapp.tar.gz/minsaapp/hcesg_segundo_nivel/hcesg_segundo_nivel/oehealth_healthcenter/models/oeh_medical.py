# -*- coding: utf-8 -*-

import logging

from models import SELECTION_TYPE
from odoo import api, fields, models

_logger = logging.getLogger(__name__)


class OeHealthCenter(models.Model):
    _inherit = 'oeh.medical.health.center'

    code_renipress = fields.Char(u'Código RENIPRESS')

    state_id = fields.Many2one('res.country.state', u'Region')
    province_id = fields.Many2one('res.country.state', u'Provincia')
    district_id = fields.Many2one('res.country.state', u'Distrito')
    latitude = fields.Float('Latitud', digits=(16, 8))
    length = fields.Float('Longitud', digits=(16, 8))

    # Datos administrativos
    institution_id = fields.Many2one(
        'minsa.company.institution',
        string='Propiedad'
    )
    category_id = fields.Many2one(
        'minsa.company.category',
        string='Categoria'
    )
    unit_executor_id = fields.Many2one(
        'minsa.company.unitexecutor',
        string='Unidad Ejecutora'
    )
    resolution = fields.Char('Resolución')
    is_class = fields.Boolean('Es Class')
    director_id = fields.Many2one(
        'hr.employee',
        string='Director General'
    )

    # Agrupacion
    diresa_id = fields.Many2one(
        'renaes.diresa',
        string='DIRESA/DISA'
    )
    red_id = fields.Many2one(
        'renaes.red',
        string='Red'
    )
    microred_id = fields.Many2one(
        'renaes.microred',
        string='Microred'
    )
    turn_ids = fields.One2many(
        'minsa.company.turn',
        'medicalcenter_id',
        string='Turnos'
    )

    director_gral_apellidos = fields.Char('Director Gral. - Apellidos')
    director_gral_nombres = fields.Char('Director Gral. - Nombres')
    director_gral_celular = fields.Char('Director Gral. - Celular')

    @api.multi
    def action_sync_renipress(self):
        mpi = self.env['consultadatos.mpi']
        parametros_mpi = mpi.get_parametros_mpi()
        if not parametros_mpi:
            return {}
        mpiclient, mpi_api_host, mpi_api_token = parametros_mpi

        establecimientoclient = mpiclient.EstablecimientoClient(mpi_api_token)
        diresa_model_search = self.env['renaes.diresa'].search
        red_model_search = self.env['renaes.red'].search
        microred_model_search = self.env['renaes.microred'].search

        for record in self:
            if not record.code_renipress:
                continue

            try:
                data = establecimientoclient.ver(record.code_renipress)
            except Exception:
                continue

            if data:
                diresa_codigo = data.get('diresa_codigo', False)
                red_codigo = data.get('red_codigo', False)
                microred_codigo = data.get('microred_codigo', False)

                record.diresa_id = diresa_codigo and \
                    diresa_model_search([('codigo_diresa', '=', diresa_codigo)], limit=1).id

                record.red_id = red_codigo and \
                    red_model_search([('diresa_id', '=', record.diresa_id.id),
                                      ('codigo_red', '=', red_codigo)], limit=1).id

                record.microred_id = microred_codigo and \
                    microred_model_search([('red_id', '=', record.red_id.id),
                                           ('codigo_microred', '=', microred_codigo)], limit=1).id

    @api.multi
    def _compute_number_ups(self):
        for item in self:
            item.number_ups = len(item.ups_ids)


class CenterBeds(models.Model):
    _inherit = 'oeh.medical.health.center.beds'

    is_assistence = fields.Boolean('Permite Citas')
    type_room = fields.Selection(SELECTION_TYPE, 'Tipo', default='CE')
    quotas = fields.Integer(
        'Cupos',
        default=20
    )
    quotas_additional = fields.Integer(
        'Adicionales',
        default=2
    )
    department_id = fields.Many2one('hr.department', 'Departamento')
    tiempo_atencion = fields.Integer(u'Tiempo de atención (minutos)')


class CenterWard(models.Model):
    _inherit = 'oeh.medical.health.center.ward'

    department_id = fields.Many2one(
        'hr.department',
        'Departamento',
    )
