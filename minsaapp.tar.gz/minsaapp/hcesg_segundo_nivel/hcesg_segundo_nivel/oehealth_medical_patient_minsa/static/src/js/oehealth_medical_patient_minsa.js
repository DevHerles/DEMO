openerp.oehealth_medicalPatientMinsa = function (instance,local) {
    var qWeb = instance.web.qweb;
    var _t = instance.web._t;
    instance.alert = {};
    /*Funcion que es usada en la programacion mensual del colaborador*/
    instance.alert.alertConsolidate = instance.web.form.FormWidget.extend({
        init: function () {
            this._super.apply(this, arguments);
            this.class = 'sis-inactico';
            this.eess = ''
            this.message = '';
        },

        start: function () {
            var self = this;
            this.sis_activo = this.view.datarecord.sis_activo;
            this.eess = 'EESS****'; // this.view.datarecord.eess;
            this.message = "Hey, this is a new message, zzzzzzzzzzzz";
            this.class = 'si-tiene'

            if(this.sis_activo) {
                this.message = 'SIS ACTIVO ' +  this.eess;
            }

            $.when.apply($, this.promises).then(function () {
                self._render();
            });
        },
        _render: function () {
            this.$el.html(qWeb.render('alert.alertConsolidate', {widget: this}));
        },
    });
    instance.web.form.custom_widgets.add('alert_consolidate', 'instance.alert.alertConsolidate');
};
