# oehealth_medical_patient_minsa



# Parametros del Sistema

Definir los siguientes parámetros en `ir.config_parameter`

- mpi_api_token
- mpi_api_host