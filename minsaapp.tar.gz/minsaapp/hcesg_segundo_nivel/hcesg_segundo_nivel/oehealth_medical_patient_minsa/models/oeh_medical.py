# -*- coding: utf-8 -*-

import datetime
import dateutil

from datetime import date, timedelta
from PIL import ImageFile

from odoo import api, fields, models, tools
from odoo.addons.oehealth.oeh_medical.oeh_medical import OeHealthFamily as OHF  # noqa
from odoo.exceptions import ValidationError

from res_partner import (FLAG_STRING_NOTIENESEGURO, TYPE_DOC_DNI,
                         TYPE_DOC_NOTIENE)

ImageFile.LOAD_TRUNCATED_IMAGES = True

ACTIVO = 'ACTIVO'


class OeHealthFamily(models.Model):
    _inherit = 'oeh.medical.patient.family'

    name = fields.Many2one(
        'oeh.medical.patient', 'Paciente',
        required=True, help='Family Member Name')
    age = fields.Char(related='name.age', readonly=True)
    deceased = fields.Boolean(related='name.deceased', readonly=True)
    # Datos adicionales
    document_number = fields.Char(
        related='name.document_number', readonly=True)
    cnv = fields.Char(related='name.cnv', readonly=True)
    sex = fields.Selection(related='name.sex', readonly=True)
    representative = fields.Boolean(string='Apoderado')


class OehMedicalInsurance(models.Model):
    _inherit = 'oeh.medical.insurance'

    medical_center = fields.Char('Establecimento')
    medical_center_address = fields.Char(u'Dirección')
    regime = fields.Selection([(1, 'SUBSIDIADO'), (2, 'REGULAR')], u'Régimen')
    owner_type = fields.Selection([(1, 'TITULAR'), (2, 'FAMILIAR')], 'Tipo de asegurado')
    exp_date = fields.Date(string='Fin de contrato', required=False)


class OehMedicalPatient(models.Model):
    _inherit = 'oeh.medical.patient'

    age = fields.Char(compute='_compute_patient_age')
    seguro_id = fields.One2many('oeh.medical.insurance', 'patient', string='Seguros')

    # Los siguientes campos se consultan en linea
    sis_mensaje = fields.Char('SIS mensaje')
    sis_nro_contrato = fields.Char('SIS número de contrato')
    sis_tipo_seguro_descripcion = fields.Char('SIS tipo de seguro')
    sis_fecha_afiliacion = fields.Date(u'SIS fecha de afiliación')
    sis_fecha_caducidad = fields.Date('SIS fecha caducidad')
    sis_estado = fields.Char('SIS estado')
    sis_eess_codigo = fields.Char(u'SIS código de establecimiento de salud')
    sis_eess_nombre = fields.Char('SIS establecimiento de salud')
    sis_eess_direccion = fields.Char(u'SIS dirección de establecimiento de salud')
    sis_activo = fields.Boolean('¿SIS activo?')
    sis_last_update = fields.Datetime(u'Última fecha de actualización')
    edad = fields.Char(compute='_compute_edad')
    # Personales diagnosticados
    personal_diagnosis_ids = fields.One2many(
        'minsa.personal.clinical.diagnosis',
        string=u'Personales diagnosticados',
        compute='_compute_personal_diagnosis_ids')
    # Clinicos familiares diagnostico
    family_diagnosis_ids = fields.One2many(
        'minsa.family.clinical.diagnosis',
        string=u'Clínicos familiares diagnóstico',
        compute='_compute_family_diagnosis_ids')
    patient_family_id = fields.Many2one(
        'oeh.medical.patient.family', string='Apoderado')
    sex_patient_family = fields.Selection(
        related='patient_family_id.name.sex', readonly=True, store=True)

    @api.multi
    def _compute_patient_age(self):
        for record in self:
            try:
                super(OehMedicalPatient, record)._patient_age()
            except TypeError:
                record.age = False

    def _compute_family_diagnosis_ids(self):
        for record in self:
            record.family_diagnosis_ids = self.env['minsa.family.clinical.diagnosis'].search([
                ('patient_id', '=', record.id)])

    def _compute_personal_diagnosis_ids(self):
        for record in self:
            record.personal_diagnosis_ids = self.env['minsa.personal.clinical.diagnosis'].search([
                ('patient_id', '=', record.id)])

    @api.multi
    def _compute_edad(self):
        def compute_age_from_dates(patient_dob, patient_deceased, patient_dod):
            now = datetime.datetime.now()
            if patient_dob:
                dob = fields.Date.from_string(patient_dob)
                if patient_deceased and patient_dod:
                    dod = fields.Date.from_string(patient_dod)
                    age = dateutil.relativedelta.relativedelta(dod, dob)
                    years_months_days = u'{} años {} meses {} días (fallecido)'.format(age.years, age.months, age.days)
                else:
                    age = dateutil.relativedelta.relativedelta(now, dob)
                    years_months_days = u'{} años {} meses {} días'.format(age.years, age.months, age.days)
            else:
                years_months_days = 'No tiene fecha de nacimiento.'

            return years_months_days
        for patient_data in self:
            patient_data.edad = compute_age_from_dates(patient_data.dob, patient_data.deceased, patient_data.dod)
        return True

    @property
    def sis_ok(self):
        """
        Verifica si la persona tiene el sis activo
        ret: True or False
        """
        return self.partner_id.sis_ok

    @api.depends('type_number', 'document_number')
    def _compute_sis_info(self, datos_sis):
        if datos_sis:
            for record in self:
                record.sis_mensaje = datos_sis.get('estado', '').upper() != ACTIVO and FLAG_STRING_NOTIENESEGURO
                record.sis_nro_contrato = datos_sis.get('nro_contrato', False)
                record.sis_tipo_seguro_descripcion = datos_sis.get('tipo_seguro_descripcion', False)
                record.sis_fecha_afiliacion = datos_sis.get('fecha_afiliacion', False)
                record.sis_fecha_caducidad = datos_sis.get('fecha_caducidad', False)
                record.sis_estado = datos_sis.get('estado', False)
                record.sis_eess_codigo = datos_sis.get('codigo_eess', False)

                if not datos_sis.sis_eess_codigo:
                    continue
                domain = [('codigo_eess', '=', datos_sis.sis_eess_codigo)]
                eess = self.env['renaes.eess'].search(domain, limit=1)
                if eess:
                    record.sis_eess_nombre = eess.name

                if fields.Datetime.from_string(record.sis_last_update).date() != date.today():
                    sis_estado = datos_sis.get('estado', '').upper()
                    record.sis_activo = sis_estado == ACTIVO

    @api.onchange('type_number', 'document_number')
    def _onchange_document_number(self):
        if self.type_number and self.type_number == TYPE_DOC_NOTIENE:
            return {
                'value': {'document_number': '/'}
            }
        elif self.type_number and self.type_number == TYPE_DOC_DNI and self.document_number:
            if len(self.document_number) != 8 or not self.document_number.isdigit():
                return {
                    'warning': {
                        'title': 'Error en el DNI',
                        'message': 'El DNI debe tener 8 números',
                    },
                }

            values = {}
            code = self.document_number
            data = self.env['consultadatos.mpi'].ver(self.document_number, '01')
            if "error" in data:
                raise ValidationError(data['error'])

            pb_distrito_id = self.env['res.country.state']
            if data.get("nacimiento_ubigeo", False):
                domain = [
                    ('country_id', '=', self.country_id.id),
                    ('code_reniec', '=', data.get('nacimiento_ubigeo', 'no_ubigeo'))
                ]
                pb_distrito_id = self.env['res.country.state'].search(domain, limit=1)
            distrito_id = self.env['res.country.state'].search([
                ('country_id', '=', self.country_id.id),
                ('code_reniec', '=', data.get(
                    "get_distrito_domicilio_ubigeo_reniec", 'no_ubigeo'))])

            values = {
                'name': '%s %s %s' % (data.get('nombres', ''),
                                      data.get('apellido_paterno', ''),
                                      data.get('apellido_materno', '')),
                'first_name': data.get('nombres', False),
                'last_name': data.get('apellido_paterno', False),
                'last_name_2': data.get('apellido_materno', False),
                'sex': data.get('sexo', False),
                'ethnicity': data.get('etnia_descripcion', False),
                'mobile': data.get('celular', False),
                'street': data.get('domicilio_direccion', False),
                'dob': data.get('fecha_nacimiento', False),
                'zip': data.get('get_distrito_domicilio_ubigeo_reniec', False),
                'website': False,
                'is_reniec': True,
                'clinical_history_number': code,
                # Datos de nacimiento
                'state_id': pb_distrito_id.state_id.id or False,
                'province_id': pb_distrito_id.province_id.id or False,
                'district_id': pb_distrito_id.id or False,
                'marital_status': data.get("estado_civil", False),
                # Datos de domicilio RENIEC
                'entity_department_id': distrito_id.state_id.id or False,
                'entity_province_id': distrito_id.province_id.id or False,
                'entity_district_id': distrito_id.id or False,
                'entity_address': data.get("domicilio_direccion", False),
                # Datos de domicilio Actual
                'a_state_id': distrito_id.state_id.id or False,
                'a_province_id': distrito_id.province_id.id or False,
                'a_district_id': distrito_id.id or False,
                'current_address': data.get("domicilio_direccion", False),
                'current_reference': data.get("domicilio_direccion", False),
                # Datos de Fallecimiento
                'deceased': not data.get("es_persona_viva", False),
                'image': data.get("foto", False),
            }

            # sis
            t = self.document_number, self.parent_id.get_mpi_document_type(self.type_number)

            datos_sis = self.env['consultadatos.mpi'].ver_datos_sis(*t)
            if datos_sis:
                domain = [('codigo_eess', '=', datos_sis.get('codigo_eess', False))]
                eess = self.env['renaes.eess'].search(domain, limit=1)
                eess_nombre = eess and eess.name
                eess_direccion = eess and eess.direccion

                vals = dict(
                    sis_nro_contrato=datos_sis.get("contrato", ""),
                    sis_fecha_afiliacion=datos_sis.get("fecha_afiliacion", ""),
                    sis_fecha_caducidad=datos_sis.get("fecha_caducidad", ""),
                    sis_eess_codigo=datos_sis.get("codigo_eess", ""),
                    sis_eess_nombre=eess_nombre,
                    sis_eess_direccion=eess_direccion,
                    sis_tipo_seguro_descripcion=datos_sis.get("tipo_seguro_descripcion", ""),
                    sis_estado=datos_sis.get("estado", FLAG_STRING_NOTIENESEGURO),
                    sis_activo=True if datos_sis.get("estado") == ACTIVO else False,
                    sis_last_update=fields.Datetime.now(),
                )
                values.update(vals)

            if datos_sis.get("contrato", False):
                values.update({'affiliation_file_number': datos_sis.get("contrato", False),
                               'affiliation_expiration': datos_sis.get("fecha_caducidad", False)})
            return {'value': values}

    @api.onchange('first_name', 'last_name', 'last_name_2')
    def _onchange_last_name(self):
        full_name = (self.first_name and (self.first_name + ' ') or '') + \
            (self.last_name and (self.last_name + ' ') or '') + \
            (self.last_name_2 and (self.last_name_2 + ' ') or '')
        self.name = full_name

    @api.multi
    def update_sis(self, datos_sis):
        for record in self:
            if record.sis_activo:
                record.seguro_id.write({
                    'name': 'SIS',
                    'ins_no': datos_sis.get('contrato', False),
                    'start_date': datos_sis.get('fecha_afiliacion', False),
                    'patient': record.id,
                    'regime': 1,
                    'exp_date': datos_sis.get('fecha_caducidad'),
                    'ins_type': 1,
                    'state': 'Active',
                })

    @api.multi
    def validate_sis(self):
        for record in self:
            last_update = record.sis_last_update and fields.Datetime.from_string(record.sis_last_update)

            if not last_update or last_update and last_update + timedelta(minutes=1) < datetime.datetime.now():
                datos_sis = record.get_datos_sis()
                if datos_sis:
                    sis_estado = datos_sis.get('estado', False)
                    if sis_estado == ACTIVO:
                        sis_activo = True
                        sis_estado = 'Active'
                    else:
                        sis_activo = False
                        sis_estado = ''

                    for seguro in record.seguro_id:
                        if seguro.ins_no == record.affiliation_file_number:
                            seguro.unlink()

                    domain = [('partner_id', '!=', False), ('partner_id', '=', record.id)]
                    patient = self.env['oeh.medical.patient'].search(domain, limit=1)

                    sis_info = {'name': 'SIS',
                                'ins_no': datos_sis.get('contrato', ''),
                                'start_date': datos_sis.get('fecha_afiliacion', False),
                                'partner_id': record.id,
                                'patient': patient.id,
                                'regime': 1,
                                'exp_date': datos_sis.get('fecha_caducidad', False),
                                'ins_type': 1,
                                'state': sis_estado,
                                }

                    domain = [('codigo_eess', '=', datos_sis.get('codigo_eess', False))]
                    eess = self.env['renaes.eess'].search(domain, limit=1)

                    vals = dict(
                        sis_nro_contrato=datos_sis.get('contrato', FLAG_STRING_NOTIENESEGURO),
                        sis_fecha_afiliacion=datos_sis.get('fecha_afiliacion', False),
                        sis_fecha_caducidad=datos_sis.get('fecha_caducidad', False),
                        sis_eess_codigo=datos_sis.get('codigo_eess', False),
                        sis_eess_nombre=eess and eess.name,
                        sis_eess_direccion=eess and eess.direccion,
                        sis_tipo_seguro_descripcion=datos_sis.get('tipo_seguro_descripcion', False),
                        sis_estado=datos_sis.get('estado', FLAG_STRING_NOTIENESEGURO),
                        sis_activo=sis_activo,
                        sis_last_update=fields.Datetime.now(),
                        seguro_id=[[0, False, sis_info]]
                    )

                    if datos_sis.get('contrato'):
                        vals.update(
                            {
                                'affiliation_file_number': datos_sis.get('contrato', False),
                                'affiliation_expiration': datos_sis.get('fecha_caducidad', False)
                            })

                else:
                    vals = dict(
                        sis_nro_contrato=False,
                        sis_fecha_afiliacion=False,
                        sis_fecha_caducidad=False,
                        sis_eess_codigo=False,
                        sis_eess_nombre=False,
                        sis_eess_direccion=False,
                        sis_tipo_seguro_descripcion=False,
                        sis_estado=False,
                        sis_activo=False,
                        sis_last_update=False,
                        seguro_id=[]
                    )
                record.write(vals)

    def get_datos_sis(self):
        return self.partner_id.get_datos_sis()

    @api.model
    def _create_from_mpi_document_number(self, type_number, document_number):

        if type_number and document_number:
            data = self.env["consultadatos.mpi"].ver(document_number, '01')
            if "error" in data:
                raise ValidationError(data['error'])

            pb_distrito_id = self.env['res.country.state']
            country_id = self.env.ref('base.pe').id
            if data.get("nacimiento_ubigeo", False):
                domain = [
                    ('country_id', '=', country_id),
                    ('code_reniec', '=', data.get('nacimiento_ubigeo', 'no_ubigeo'))
                ]
                pb_distrito_id = self.env['res.country.state'].search(domain, limit=1)

            partner_values = {
                'name': '{} {} {}'.format(
                    data.get('nombres', ''),
                    data.get('apellido_paterno', ''),
                    data.get('apellido_materno', '')),
                'display_name': '[{}] {} {} {}'.format(
                    document_number, data.get('nombres', ''),
                    data.get('apellido_paterno', ''),
                    data.get('apellido_materno', '')),
                'last_name': data.get('apellido_materno', ''),
                'last_name_2': data.get('apellido_materno', ''),
                'first_name': data.get('nombres', ''),
                'document_number': document_number,
                'clinical_history_number': document_number,
                'type_number': TYPE_DOC_DNI,
                'company_id': self.env.user.partner_id.company_id.id,
                'street': data.get('domicilio_direccion', False),
                'zip': data.get('get_distrito_domicilio_ubigeo_reniec', False),
                'employee': False,
                'is_company': False,
                'lang': 'es_PE',
                'customer': True,
                'is_doctor': False,
                'is_institution': False,
                'is_person': False,
                'is_patient': True,
                'ubigeo': data.get('get_distrito_domicilio_ubigeo_reniec', False),
                'country_id': country_id,
                'state_id': pb_distrito_id.state_id.id or False,
                'province_id': pb_distrito_id.province_id.id or False,
                'district_id': pb_distrito_id.id or False,
                'entity_country_id': country_id,
                'entity_address': data.get('domicilio_direccion', False),
                'entity_department_id': pb_distrito_id.state_id.id or False,
                'entity_province_id': pb_distrito_id.province_id.id or False,
                'entity_district_id': pb_distrito_id.id or False,
                'current_address': data.get('domicilio_direccion', False),
                'image': data.get('foto', False),
                'email': '',
                'is_reniec': True
            }

            person = self.env['res.partner'].create(partner_values)
            patient = self.env['oeh.medical.patient'].create({
                'partner_id': person.id,
                'sex': data.get('sexo', False),
                'dob': data.get("fecha_nacimiento", False),
            })
            return patient

    @api.model
    def create(self, vals):
        if 'first_name' in vals and 'last_name' in vals and 'last_name_2' in vals:
            t_name = (vals['last_name'] or '', vals['last_name_2'] or '', vals['first_name'] or '')
            vals.update({'name': u' '.join(t_name)})

        # Secuencia Paciente sin documento
        if vals.get('type_number') == TYPE_DOC_NOTIENE:
            sequence = self.env['ir.sequence'].next_by_code('oeh.medical.patient.sindocumento')
            vals.update(dict(document_number=sequence))

        person = super(OehMedicalPatient, self).create(vals)

        #  Obtiene información del SIS
        if person.sis_nro_contrato:
            sis_info = {
                'name': 'SIS',
                'ins_no': person.sis_nro_contrato,
                'start_date': fields.Datetime.from_string(person.sis_fecha_afiliacion),
                'patient': person.id,
                'regime': 1,
                'ins_type': 1,
                'state': 'Active' if person.sis_estado == ACTIVO else '',
                'medical_center': person.sis_eess_nombre,
                'medical_center_address': person.sis_eess_direccion,
                'owner_type': 1,
            }
            person.write({'seguro_id': [[0, False, sis_info]]})

        return person

    @api.multi
    def write(self, vals):
        if not ('first_name' in vals or 'last_name' in vals or 'last_name_2' in vals):
            return super(OehMedicalPatient, self).write(vals)

        for record in self:
            values = vals.copy()
            t_name = (values.get('last_name') or record.last_name or '',
                      values.get('last_name_2') or record.last_name_2 or '',
                      values.get('first_name') or record.first_name) or ''
            values.update({'name': u' '.join(t_name)})

            super(OehMedicalPatient, record).write(values)


class MinsaPersonalClinicalDiagnosis(models.Model):
    _name = 'minsa.personal.clinical.diagnosis'
    _description = u'Personal diagnóstico'
    _auto = False

    pathology_id = fields.Many2one(
        'oeh.medical.pathology', string=u'Diagnóstico Definitivo')
    date = fields.Date(string=u'Fecha de diagnóstico')
    patient_id = fields.Many2one('oeh.medical.patient')
    type_diagnosis = fields.Char('Tipo')

    @api.model_cr
    def init(self):
        tools.drop_view_if_exists(self._cr, 'minsa_personal_clinical_diagnosis')
        self._cr.execute("""
            CREATE OR REPLACE VIEW minsa_personal_clinical_diagnosis AS (
                SELECT
                    med.id,
                    med.pathology_id,
                    med.date,
                    ome.patient AS patient_id,
                    med.evaluation_id,
                    med.type_diagnosis
                FROM oeh_medical_evaluation ome
                INNER JOIN minsa_evaluation_diagnosis med ON
                    (med.evaluation_id=ome.id AND med.type_diagnosis = 'Definitivo')
            )""")


class MinsaFamilyClinicalDiagnosis(models.Model):
    _name = 'minsa.family.clinical.diagnosis'
    _description = u'Clínicos familiares diagnóstico'
    _auto = False

    relation = fields.Selection(OHF.FAMILY_RELATION, string='Parentesco')
    pathology_id = fields.Many2one(
        'oeh.medical.pathology', string=u'Diagnóstico Definitivo')
    date = fields.Date(string=u'Fecha diagnosticó')
    patient_id = fields.Many2one('oeh.medical.patient')

    @api.model_cr
    def init(self):
        tools.drop_view_if_exists(self._cr, 'minsa_family_clinical_diagnosis')
        self._cr.execute("""
            CREATE OR REPLACE VIEW minsa_family_clinical_diagnosis AS (
                SELECT
                    med.id AS id,
                    med.pathology_id,
                    ompf.relation,
                    med.date,
                    ompf.patient_id
                FROM oeh_medical_patient_family ompf
                INNER JOIN oeh_medical_evaluation ome ON
                    (ome.patient=ompf.name)
                INNER JOIN minsa_evaluation_diagnosis med ON
                    (med.evaluation_id=ome.id AND med.type_diagnosis= 'Definitivo')
        )""")
