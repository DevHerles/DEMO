# -*- coding: utf-8 -*-

import logging

from odoo import api, fields, models
from odoo.exceptions import ValidationError

FLAG_STRING_NOTIENESEGURO = "NO TIENE SEGURO"

TYPE_DOC_NOSECONOCE = 'NOSECONOCE'
TYPE_DOC_DNI = 'DNI'
TYPE_DOC_LIBRETAMILITAR = 'LIBRETAMILITAR'
TYPE_DOC_CARNETEXT = 'CARNETEXT'
TYPE_DOC_ACTANACIMIENTO = 'ACTANACIMIENTO'
TYPE_DOC_PASAPORTE = 'PASAPORTE'
TYPE_DOC_DOCEXTRANJERO = 'DOCEXTRANJERO'
TYPE_DOC_NOTIENE = 'NOTIENE'
TYPE_DOC_SINDOCUMENTO = 'TYPE_DOC_SINDOCUMENTO'

TYPE_DOCUMENTO = [
    (TYPE_DOC_NOSECONOCE, 'NO SE CONOCE'),
    (TYPE_DOC_DNI, 'DNI'),
    (TYPE_DOC_LIBRETAMILITAR, 'LIBRETA MILITAR'),
    (TYPE_DOC_CARNETEXT, 'CARNET EXTRANJERIA'),
    (TYPE_DOC_ACTANACIMIENTO, 'ACTA DE NACIMIENTO'),
    (TYPE_DOC_PASAPORTE, 'PASAPORTE'),
    (TYPE_DOC_DOCEXTRANJERO, 'DOCUMENTO DE IDENTIFICACION DEL EXTRANJERO'),
    (TYPE_DOC_NOTIENE, 'NO TIENE'),
    (TYPE_DOC_SINDOCUMENTO, 'SIN DOCUMENTO')
]


_logger = logging.getLogger(__name__)


class ResPartner(models.Model):
    _inherit = 'res.partner'

    first_name = fields.Char('Nombres(s)', size=250)
    last_name = fields.Char('Apellido Paterno', size=250)
    last_name_2 = fields.Char('Apellido Materno', size=250)
    type_number = fields.Selection(
        TYPE_DOCUMENTO, string="Tipo Documento", default='DNI')
    document_number = fields.Char('Número de Documento', size=15)
    is_reniec = fields.Boolean('RENIEC', default=False)
    phone_2 = fields.Char(string=u'Teléfono 2')
    mobile_2 = fields.Char(string=u'Celular 2')
    cnv = fields.Char(string=u'Cert. Nacido Vivo (CNV)')
    clinical_history_number = fields.Char(string=u'N. de Archivo Clínica')
    affiliation_file_number = fields.Char(string=u'N. Archivo de Afiliación')
    affiliation_expiration = fields.Date(string=u'Expiración de la Afilición')
    sis_estado = fields.Char('Estado del SIS')
    ethnicity = fields.Char(string=u'Etnia')
    occupation_id = fields.Many2one(
        'oeh.medical.occupation', string=u'Ocupación')
    # Datos RENiEC
    entity_country_id = fields.Many2one(
        'res.country', string=u'País',
        default=lambda self: self.env['ir.model.data'].xmlid_to_res_id('base.pe'))  # NOQA
    entity_department_id = fields.Many2one(
        'res.country.state', string=u'Departamento')
    entity_province_id = fields.Many2one(
        'res.country.state', string=u'Provincia')
    entity_district_id = fields.Many2one(
        'res.country.state', string=u'Distrito')
    entity_address = fields.Char(string=u'Dirección')
    # Datos de domicilio actual
    a_country_id = fields.Many2one(
        'res.country', string=u'País',
        default=lambda self: self.env['ir.model.data'].xmlid_to_res_id('base.pe'))  # NOQA
    a_state_id = fields.Many2one('res.country.state', 'Region')
    a_province_id = fields.Many2one('res.country.state', 'Provincia')
    a_district_id = fields.Many2one('res.country.state', 'Distrito')
    current_address_location = fields.Char(string=u'Localidad')
    current_address = fields.Char(string=u'Dirección Actual')
    current_reference = fields.Char(string=u'Referencia Actual')
    # Mapa
    indicate_reference = fields.Char(string=u'Indique una referencia')
    latitude = fields.Float(string=u'Latitud')
    longitude = fields.Float(string=u'longitud')

    @api.constrains('type_number', 'document_number')
    def _check_unique_patient(self):
        model_patient = self.env['oeh.medical.patient']
        for record in self:
            domain = [
                ('partner_id', '!=', record.id),
                ('type_number', '=', record.type_number),
                ('document_number', '=', record.document_number),
            ]
            if model_patient.search(domain, limit=1):
                raise ValidationError('Ya existe el paciente')

    def get_datos_sis(self):
        if not (self.type_number in (TYPE_DOC_DNI, TYPE_DOC_DNI.lower()) and
                self.document_number and len(self.document_number) == 8):
            return {}
        t = self.document_number, self.get_mpi_document_type(self.type_number)
        return self.env['consultadatos.mpi'].ver_datos_sis(*t)

    @property
    def sis_ok(self):
        """
        Verifica si la persona tiene el sis activo
        ret: True or False
        """

        affiliation_expiration = self.affiliation_expiration and \
            fields.Datetime.from_string(self.affiliation_expiration)
        now = fields.Datetime.from_string(fields.Datetime.now())

        sis_ok = self.affiliation_file_number and self.affiliation_file_number != FLAG_STRING_NOTIENESEGURO and \
            (affiliation_expiration and affiliation_expiration >= now or not affiliation_expiration)

        return sis_ok

    def get_mpi_document_type(self, doc_type):
        if doc_type == TYPE_DOC_DNI:
            return '01'
        elif doc_type == TYPE_DOC_LIBRETAMILITAR:
            return '02'
        elif doc_type == TYPE_DOC_CARNETEXT:
            return '03'
        elif doc_type == TYPE_DOC_ACTANACIMIENTO:
            return '04'
        elif doc_type == TYPE_DOC_PASAPORTE:
            return '06'
        elif doc_type == TYPE_DOC_DOCEXTRANJERO:
            return '07'
        elif doc_type == TYPE_DOC_SINDOCUMENTO:
            return '00'
        else:
            raise ValidationError(u'El tipo de documento {} no es válido'.format(doc_type))
