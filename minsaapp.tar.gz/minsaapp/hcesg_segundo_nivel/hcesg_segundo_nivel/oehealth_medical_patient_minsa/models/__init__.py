import oeh_medical  # noqa
import res_partner  # noqa
