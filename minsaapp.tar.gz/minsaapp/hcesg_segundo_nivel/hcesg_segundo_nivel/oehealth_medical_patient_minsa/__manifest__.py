# -*- coding: utf-8 -*-

{
    'name': 'Extendiendo paciente',
    'version': '1.0',
    'author': 'MINSA',
    'website': 'www.minsa.gob.pe',
    'category': 'Medical',
    'depends': [
        'oehealth',
        'oehealth_minsa',
        'toponimos_peru',
        'consultadatos'
    ],
    'description': """

    Dependencias Odoo:

    - oehealth

    - oehealth_minsa

    - toponimos_peru (Repositorio odoo-share)

    - consultadatos (Repositorio odoo-share)

    """,
    'data': [
        'views/res_partner_views.xml',
        'views/oehealth_patient_assets.xml',
        'views/oehealth_patient_view.xml',
        'views/report_patient_label.xml',
        'sequence/oeh_sequence.xml',
        'security/ir.model.access.csv',
    ],
    'qweb': [
        'static/src/xml/oehealth_medical_patient_minsa_template.xml',
    ],
    'active': False,
    'installable': True
}
