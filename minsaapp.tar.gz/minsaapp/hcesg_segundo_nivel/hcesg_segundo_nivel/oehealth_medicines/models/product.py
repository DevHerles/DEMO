# -*- coding: utf-8 -*-

from odoo import api, fields, models


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    MEDICAMENT_TYPE = [
        ('Medicine', 'Medicine'),
        ('Vaccine', 'Vaccine'),
    ]
    familia = fields.Many2one(
        comodel_name='catalogominsa.medicina.familia', string=u'Familia de medicamento',
        required=False)
    presentacion = fields.Char(string='Presentación')
    concentracion = fields.Char(string='Concentración')
    codigo_sismed = fields.Char(string='Código SISMED')
    codigo_siaf = fields.Char(string='Código SIAF')
    registro_sanitario = fields.Char(string='Registro sanitario')
    fecha_sync = fields.Date('Fecha de sincronización')
    sync = fields.Boolean('Sincronizado')
    is_sis = fields.Boolean(string=u'¿Pertenece al SIS?')
    # forma_farmaceutica = fields.Char(string=u'Forma farmacéutica')
    forma_farmaceutica = fields.Many2one('oeh.medical.drug.form', u'Forma farmacéutica', help="Drug form, such as tablet or gel")
    es_medicacion_habitual = fields.Boolean('¿Es medicación habitual?')
    therapeutic_action = fields.Char(string='Therapeutic effect', size=128, help="Therapeutic action")
    composition = fields.Text(string='Composition', help="Components")
    indications = fields.Text(string='Indication', help="Indications")
    dosage = fields.Text(string='Dosage Instructions', help="Dosage / Indications")
    overdosage = fields.Text(string='Overdosage', help="Overdosage")
    pregnancy_warning = fields.Boolean(string='Pregnancy Warning',
                                       help="Check when the drug can not be taken during pregnancy or lactancy")
    pregnancy = fields.Text(string='Pregnancy and Lactancy', help="Warnings for Pregnant Women")
    adverse_reaction = fields.Text(string='Adverse Reactions')
    storage = fields.Text(string='Storage Conditions')
    info = fields.Text(string='Extra Info')
    medicament_type = fields.Selection(MEDICAMENT_TYPE, string='Medicament Type')

    # Se agrega temporalmente atributo product_id y metodo _compute_product_id
    product_id = fields.Many2one('product.product', compute='_compute_product_id')

    @api.multi
    def _compute_product_id(self):
        for record in self:
            domain = [('product_tmpl_id', '=', record.id)]
            product = self.product_id.search(domain, limit=2)
            if len(product.ids) == 1:
                record.product_id = product
