# -*- coding: utf-8 -*-

from odoo import api, fields, models


class OehMedicalMedicines(models.Model):
    _inherit = 'oeh.medical.medicines'

    @api.onchange('medicament_type')
    def _onchange_medicament_type(self):
        if self.is_sis:
            self.type = 'product'
            self.sale_ok = True
            self.purchase_ok = True


class OehMedicalPrescription(models.Model):
    _inherit = 'oeh.medical.prescription'

    evaluation_id = fields.Many2one('oeh.medical.evaluation')
    lab_1 = fields.Char('LAB 1', size=3)
    lab_2 = fields.Char('LAB 2', size=3)

    @api.onchange('lab_1')
    def onchange_lab_1(self):
        if self.lab_1:
            self.lab_1 = self.lab_1.upper()

    @api.onchange('lab_2')
    def onchange_lab_2(self):
        if self.lab_2:
            self.lab_2 = self.lab_2.upper()


class OehMedicalPrescriptionLine(models.Model):
    _inherit = 'oeh.medical.prescription.line'

    forma_farmaceutica = fields.Char(u'Forma Farmacéutica')
    presentacion = fields.Char(string='Presentación')
    concentracion = fields.Char(string='Concentración')

    name = fields.Many2one(
        'product.template', 'Medicines', help="Prescribed Medicines",
        domain=[('medicament_type', '=', 'Medicine')], required=True)
    evaluation_id = fields.Many2one('oeh.medical.evaluation')
    diagnosis_id = fields.Many2one('minsa.evaluation.diagnosis')
    cubierto_x_sis = fields.Boolean('¿Es cubierto por SIS?')
    stock = fields.Char('Stock')

    # Autopopulate selected medicine values
    @api.multi
    def onchange_medicine_id(self, medicine_id=False):
        value = {}
        if medicine_id:
            product_template = self.env['product.template'].search([('id', '=', medicine_id)], limit=1)
            if product_template:
                value = {
                    'composition': product_template.composition,
                    'concentracion': product_template.concentracion,
                    'presentacion': product_template.presentacion,
                    'forma_farmaceutica': product_template.forma_farmaceutica,
                    'cubierto_x_sis': product_template.is_sis,
                }
        return {'value': value}
