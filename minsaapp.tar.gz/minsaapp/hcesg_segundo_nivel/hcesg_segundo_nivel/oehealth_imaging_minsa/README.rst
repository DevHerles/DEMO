Modulo de Imagenes- HCESG Segundo Nivel
=========================================

Extiende el modulo de laboratirio  ( oehealth )

# Requerimientos Odoo

https://git.minsa.gob.pe/oidt/odoo_catalogos

