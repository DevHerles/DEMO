# -*- coding: utf-8 -*-

{
    'name': 'Gestion de Imagenes MINSA',
    'version': '1.0',
    'website': 'www.minsa.gob.pe',
    'category': 'oehealth',
    'author': 'MINSA',
    'depends': ['oehealth_extra_addons', 'catalogominsa_cpt'],
    'description': 'Hereando el modelo de imagenes para el MINSA',
    'data': [
        'views/oeh_medical_imaging_view.xml',
        'security/ir.model.access.csv',
    ],
    'active': False,
    'installable': True,
}
