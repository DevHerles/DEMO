# -*- coding: utf-8 -*-

from odoo import fields, models


class OeHealthImaging(models.Model):
    _inherit = 'oeh.medical.imaging'

    appointment_id = fields.Many2one('oeh.medical.appointment', 'Cita')
    cpt_id = fields.Many2one(
        'catalogominsa.cpt_procedimiento', u'Denominación',
        required=True
    )
    test_type = fields.Many2one(
        'oeh.medical.imaging.test.type', 'Test Type', help='Imaging Test type',
        readonly=True, states={'Draft': [('readonly', False)]},
        required=False,
    )
    lab_1 = fields.Char('LAB 1', size=3)
    lab_2 = fields.Char('LAB 2', size=3)
