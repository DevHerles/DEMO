# -*- coding: utf-8 -*-

from openerp import api, models


class ResUsers(models.Model):
    _inherit = 'res.users'

    @api.model
    def create(self, values):
        if not values.get('password'):
            values.update({'password': values.get('login')})
        return super(ResUsers, self).create(values)

    @api.onchange('email')
    def _onchange_email(self):
        if self.email and '@' in self.email:
            self.login = self.email[:self.email.index('@')]
