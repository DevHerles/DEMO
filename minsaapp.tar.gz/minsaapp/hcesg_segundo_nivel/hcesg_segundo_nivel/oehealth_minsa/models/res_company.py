# -*- coding: utf-8 -*-

from odoo import api, fields, models


class ResCompany(models.Model):
    _inherit = 'res.company'

    center_id = fields.Many2one(
        comodel_name='oeh.medical.health.center',
        string=u'Centro Medico',
        compute='_compute_center_id'
    )

    @api.multi
    def _compute_center_id(self):
        for record in self:
            domain = [('partner_id', '=', record.partner_id.id)]
            record.center_id = self.env['oeh.medical.health.center'].search(domain, limit=1)
