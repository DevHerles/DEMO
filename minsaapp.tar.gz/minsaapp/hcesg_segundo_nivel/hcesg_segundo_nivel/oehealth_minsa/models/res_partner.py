# -*- coding: utf-8 -*-

import logging

from odoo import api, models

_logger = logging.getLogger(__name__)


class ResPartner(models.Model):
    _inherit = 'res.partner'

    @api.constrains('type_number', 'document_number')
    def _check_minsa_patient(self):
        if self._context.get('oeh_res_model', '') != 'oeh.medical.patient':
            return True

        # Verifica que solo exista el par `type_number` y `document_number` dentro del res.parter
        # cuando se guarde via el modelo `oeh.medical.patient`

        # if self.id:
        #     domain = [('type_number', '=', self.type_number),
        #               ('document_number', '=', self.document_number),
        #               ('id', '!=', self.id)]
        # else:
        #     domain = [('type_number', '=', self.type_number),
        #               ('document_number', '=', self.document_number)]

        # if self.search(domain, limit=1):
        #     raise ValueError('Ya existe el Tipo y Número de Documento')

    @api.multi
    def name_get(self):
        names = []
        for record in self:
            if record.is_company:
                if record.vat:
                    if record.parent_id:
                        name = u'[{}] {}, {}'.format(
                            record.vat,
                            record.parent_id.name,
                            record.name
                        )
                    else:
                        name = u'[{}] {}'.format(record.vat, record.name)
                else:
                    name = u'{}'.format(record.name)
            else:
                if record.document_number:
                    if record.parent_id:
                        name = u'[{}] {}, {}'.format(
                            record.document_number,
                            record.parent_id.name,
                            record.name
                        )
                    else:
                        name = u'[{}] {}'.format(record.document_number, record.name)
                else:
                    name = u'{}'.format(record.name)

            names.append((record.id, name))
        return names
