# -*- coding: utf-8 -*-


from odoo import fields, models


class HrDepartament(models.Model):
    _inherit = 'hr.department'

    is_programming = fields.Boolean(
        'Permite Programacion',
        default=False
    )
