# -*- coding: utf-8 -*-

import datetime
import dateutil
import logging

from odoo import api, fields, models

_logger = logging.getLogger(__name__)


class OeHealthCenters(models.Model):
    _inherit = 'oeh.medical.health.center'

    @api.model
    def create(self, vals):
        vals.update(dict(company_type='company'))
        center = super(OeHealthCenters, self).create(vals)
        main_partner = self.env.ref('base.main_partner')
        if main_partner and center.partner_id != main_partner:
            partner = center.partner_id
            vals = dict(
                partner_id=partner.id,
                name=partner.name,
                street=partner.street,
                street2=partner.street2,
                city=partner.city,
                state_id=partner.state_id.id,
                zip=partner.zip,
                country_id=partner.country_id.id,
                website=partner.website,
                phone=partner.phone,
                fax=partner.fax,
                email=partner.email,
            )
            self.env['res.company'].create(vals)

        return center


class OeHealthPatient(models.Model):
    _inherit = 'oeh.medical.patient'

    # Equivalencia con MPI
    MARITAL_STATUS = [
        ('1', 'Single'),
        ('2', 'Married'),
        ('3', 'Widowed'),
        ('4', 'Divorced'),
        ('5', 'Separated'),
    ]

    SEX = [
        ('1', 'Hombre'),
        ('2', 'Mujer'),
    ]

    @api.multi
    def name_get(self):
        names = []
        for record in self:
            if record.is_company:
                if record.vat:
                    if record.parent_id:
                        name = u'[{}] {}, {}'.format(
                            record.vat,
                            record.parent_id.name,
                            record.name
                        )
                    else:
                        name = u'[{}] {}'.format(record.vat, record.name)
                else:
                    name = u'{}'.format(record.name)
            else:
                if record.document_number:
                    if record.parent_id:
                        name = u'[{}] {}, {}'.format(
                            record.document_number,
                            record.parent_id.name,
                            record.name
                        )
                    else:
                        name = u'[{}] {}'.format(record.document_number, record.name)
                else:
                    name = u'{}'.format(record.name)

            names.append((record.id, name))
        return names

    marital_status = fields.Selection(MARITAL_STATUS)
    sex = fields.Selection(SEX)

    age_years_int = fields.Integer(compute='compute_age_years_int', string='Patient age years int')
    age_months_int = fields.Integer(compute='compute_age_months_int', string='Patient age months int')

    def calcular_edad(self, dob, months=False):
        edad = 0
        try:
            if dob:
                dob = dateutil.parser.parse(dob)
                now = datetime.datetime.utcnow()
                now = now.date()

                if dob.date() > now:
                    raise ValueError('La fecha de nacimiento no puede ser posterior al día de hoy.')

                edad = dateutil.relativedelta.relativedelta(now, dob)

                if months:
                    edad = edad.years * 12 + edad.months
                else:
                    edad = edad.years

            return edad
        except ValueError:
            raise ValueError('Formato de fecha incorrecto.')

    @api.one
    def compute_age_years_int(self):
        self.age_years_int = self.calcular_edad(self.dob)

    @api.one
    def compute_age_months_int(self):
        self.age_months_int = self.calcular_edad(self.dob, True)

    @api.multi
    def unlink(self):
        for record in self:
            record.partner_id.unlink()
        return super(OeHealthPatient, self).unlink()

    @api.multi
    def write(self, value):
        ctx = self._context.copy()
        ctx.update({'oeh_res_model': self._name, 'oeh_res_id': self.id})
        return super(OeHealthPatient, self.with_context(ctx)).write(value)

    @api.model
    def create(self, value):
        ctx = self._context.copy()
        ctx.update({'oeh_res_model': self._name, 'oeh_res_id': self.id})
        return super(OeHealthPatient, self.with_context(ctx)).create(value)
