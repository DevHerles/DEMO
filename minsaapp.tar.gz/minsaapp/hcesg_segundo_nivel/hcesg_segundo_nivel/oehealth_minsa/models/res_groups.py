# -*- coding: utf-8 -*-

from odoo import api, fields, models


class ResGroups(models.Model):
    _inherit = 'res.groups'

    action_id = fields.Many2one(
        'ir.actions.actions', 'Accion Inicial',
        help="Acción Inicial para el grupo")

    @api.multi
    def write(self, values):
        res = super(ResGroups, self).write(values)
        for record in self:
            record.users.write({'record': record.action_id.id})
        return res
