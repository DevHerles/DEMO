from . import hr  # noqa
from . import res_partner  # noqa
from . import res_company  # noqa
from . import oeh_medical  # noqa
from . import res_users  # noqa
from . import res_groups  # noqa
