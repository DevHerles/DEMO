{
    'name': 'oeHealth Minsa',
    'version': '1.0',
    'author': "MINSA",
    'category': 'Generic Modules/Medical',
    'summary': 'Translate the complete oeHealth module in Spanish Language/MINSA',
    'depends': ['oehealth'],
    'description': """

oeHealth Spanish Traslation/Localizacion Minsa

""",
    "images": [],
    "website": "http://minsa.gob.pe",
    "data": [
        'data/oehealth_minsa.xml',
        'views/res_users_views.xml',
        'views/hr_views.xml',
        'views/res_groups_views.xml',
    ],
    "demo": [

    ],
    'test': [
    ],
    'css': [

    ],
    'js': [

    ],
    'qweb': [

    ],
    "active": False
}
