# -*- coding: utf-8 -*-


from odoo import fields, models


class OeHealthLabTests(models.Model):
    _inherit = 'oeh.medical.lab.test'

    appointment_id = fields.Many2one('oeh.medical.appointment', 'Cita')
    cpt_id = fields.Many2one('catalogominsa.cpt_procedimiento', u'Denominación', required=True)
    physician_id = fields.Many2one('oeh.medical.physician', 'Médico Solicitante')
    pathologist = fields.Many2one(
        'oeh.medical.physician', 'Pathologist', help="Pathologist",
        readonly=True, states={'Draft': [('readonly', False)]},
        required=False)
    test_type = fields.Many2one(
        'oeh.medical.labtest.types', 'Test Type',
        readonly=True, states={'Draft': [('readonly', False)]}, help='Lab test type',
        required=False)
    lab_1 = fields.Char('LAB 1', size=3)
    lab_2 = fields.Char('LAB 2', size=3)
