Modulo de Laboratorio - HCESG Segundo Nivel
=========================================

Extiende el modulo de laboratorio  ( oehealth )

# Dependencias Odoo

- oehealth
- catalogominsa_cpt