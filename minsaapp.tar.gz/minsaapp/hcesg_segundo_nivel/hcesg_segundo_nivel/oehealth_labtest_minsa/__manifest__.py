# -*- coding: utf-8 -*-

{
    'name': 'Gestion de Pruebas de laboratorio MINSA',
    'version': '1.0',
    'website': 'www.minsa.gob.pe',
    'category': 'oehealth',
    'author': 'MINSA',
    'depends': [
        'oehealth',
        'catalogominsa_cpt'
    ],
    'description': 'Hereando el modelo de examenes de laboratorio para el MINSA',
    'data': [
        'views/oeh_medical_lab_view.xml',
        'security/ir.model.access.csv',
    ],
    'installable': True
}
