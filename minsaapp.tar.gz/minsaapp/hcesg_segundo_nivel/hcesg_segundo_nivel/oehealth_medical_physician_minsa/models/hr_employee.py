# -*- coding: utf-8 -*-

from odoo import fields, models


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    def _default_identification_type(self):
        try:
            tipo_documento_dni = self.env.ref('.tipo_documento_dni')
        except Exception:
            tipo_documento_dni = False

        return tipo_documento_dni and tipo_documento_dni.id

    identification_type = fields.Many2one(
        'hr.catalogo', 'Tipo de Documento',
        default=_default_identification_type)
