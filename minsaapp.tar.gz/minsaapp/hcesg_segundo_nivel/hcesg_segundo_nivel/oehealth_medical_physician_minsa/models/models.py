# -*- coding: utf-8 -*-

from odoo import api, models


class OehMedicalPhysician(models.Model):
    _inherit = 'oeh.medical.physician'

    @api.onchange('identification_emisor_id', 'identification_type', 'identification_id')
    def _onchange_identification_id(self):
        values = self.env['hr.employee']._get_reniec(
            self.identification_emisor_id.code,
            self.identification_type.code,
            self.identification_id)
        return {'value': values}
