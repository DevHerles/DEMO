# -*- coding: utf-8 -*-

{
    'name': 'Extendiendo Médico',
    'version': '1.0',
    'author': 'MINSA',
    'website': 'www.minsa.gob.pe',
    'category': 'Medical',
    'depends': [
        'oehealth',
        'gestion_rrhh',
        'minsa_programming',
    ],
    'description': '',
    'data': [
        'views/oehealth_physician_views.xml',
        'security/ir.model.access.csv',
        'security/oehealth_security.xml',
    ],
    'active': False,
    'installable': True
}
