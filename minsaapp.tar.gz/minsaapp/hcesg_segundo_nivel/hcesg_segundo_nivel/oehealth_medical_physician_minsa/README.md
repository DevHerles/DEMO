# oehealth_medical_physician_minsa

- Modifica el formulario del Médico oehealt.medical.physician
- Agrega atributos como apellidos paterno, materno y nombres, tipo documento, documento, nacionalidad
- Permite buscar los datos del médico en MPI via el dni (identification_id)
- Establece por defecto como tipo de documento al DNI.


# Dependencias

- oehealth
- gestion_rrhh


