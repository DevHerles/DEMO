{
    'name': 'Ventanilla Unica',
    'version': '1.0',
    'author': "MINSA",
    'category': 'Generic Modules/Medical',
    'summary': 'Rol de ventanilla unica',
    'depends': ['oehealth', 'oehealth_extra_addons', 'hr'],
    'description': """

oeHealth Roles Ventanilla Unica

""",
    "images": [],
    "website": "http://minsa.gob.pe",
    "data": [
        'security/ir.model.access.csv',
        'security/oeh_security.xml',
        'views/oehealth_minsa.xml',
    ],
    "demo": [

    ],
    'test': [
    ],
    'css': [

    ],
    'js': [

    ],
    'qweb': [

    ],
    "active": False
}
