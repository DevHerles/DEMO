# -*- coding: utf-8 -*-

{
    'name': u'Módulo de emergencias',
    'version': '1.0.0',
    'author': 'MINSA',
    'website': 'www.minsa.gob.pe',
    'category': 'Medical',
    'description': u'MINSA - Módulo de emergencias',
    'depends': [
        'consultadatos',
        'oehealth',
        'oehealth_extra_addons',
        'oehealth_medical_patient_minsa',
        'oehealth_evaluation_minsa',
    ],
    'data': [
        'views/oeh_emergency_views.xml',
        'views/oeh_emergency_trees.xml',
        'views/oeh_emergency_actions.xml',
        'views/oeh_emergency_menus.xml',
        'security/ir.model.access.csv',
    ],
    'active': False,
    'installable': True
}
