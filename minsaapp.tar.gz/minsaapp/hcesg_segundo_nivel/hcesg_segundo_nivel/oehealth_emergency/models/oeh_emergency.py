# -*- coding: utf-8 -*-

from odoo import api, fields, models

ACTIVO = 'ACTIVO'

TYPE_DOCUMENTO = [
    ('DNI', 'DNI'),
    ('PASAPORTE', 'PASAPORTE'),
    ('CARNETEXT', 'CARNET EXTRANGERIA'),
    ('NOTIENE', 'NO TIENE'),
]

TYPE_PATIENT = [
    ('new_patient', 'Paciente nuevo'),
    ('continuing_patient', 'Paciente continuador'),
]

STABLE = 'estable'
ILL = 'ill'
SERIOUS = 'serious'

PATIENT_CONDITION = [
    (STABLE, 'Estable'),
    (ILL, 'Mal'),
    (SERIOUS, 'Grave')
]

IN_ADMISSION = 'admission'
TRIAD = 'triad'
IN_ATTENTION = 'in_attention'
ATTENDED = 'attended'

EMERGENCY_STATE = [
    (IN_ADMISSION, 'Ingreso'),
    (TRIAD, 'Triado'),
    (IN_ATTENTION, 'En atención'),
    (ATTENDED, 'Egreso')
]

EMERGENCY = 'emergency'
URGENCY = 'urgency'

URGENCY_LEVEL = [
    (EMERGENCY, 'Emergencia'),
    (URGENCY, 'Urgencia')
]

AIR = 'air'
RIVER = 'river'
MARINE = 'marine'
GROUND = 'ground'

TRANSPORT_TYPE = [
    (AIR, u'Aéreo'),
    (RIVER, 'Fluvial'),
    (MARINE, u'Marítimo'),
    (GROUND, 'Terrestre')
]

PATIENT_ORIGIN_HOME = 'home'
PATIENT_ORIGIN_SAMU = 'samu'
PATIENT_ORIGIN_REFERENCE = 'reference'

PATIENT_ORIGIN = [
    (PATIENT_ORIGIN_HOME, 'Su casa'),
    (PATIENT_ORIGIN_SAMU, 'SAMU'),
    (PATIENT_ORIGIN_REFERENCE, 'Referencia')
]


class OehMedicalEmergency(models.Model):
    _name = 'oeh.medical.emergency'

    name = fields.Char(u'Código de emergencia', size=64, readonly=True, required=True, default=lambda *a: '/')
    state = fields.Selection(EMERGENCY_STATE, 'Estado', readonly=True, default=lambda *e: IN_ADMISSION)
    emergency_date = fields.Datetime('Fecha y hora de ingreso')
    patient_id = fields.Many2one('oeh.medical.patient', string='Paciente')
    urgency_level = fields.Selection(URGENCY_LEVEL, 'Tipo de servicio')
    patient_origin = fields.Selection(PATIENT_ORIGIN, 'Origen')
    samu_physician = fields.Char(u'Médico de SAMU')
    reference_id = fields.Char('ID de referencia')
    reference_physician = fields.Char(u'Médico que solicita la referencia')
    reference_reason = fields.Char('Motivo de referencia')
    patient_condition = fields.Selection(PATIENT_CONDITION, u'Condición del paciente')
    ipress_origin = fields.Char('IPRESS origen')
    ipress_destination = fields.Char('IPRESS destino')
    transport_type = fields.Selection(TRANSPORT_TYPE, 'Tipo de transporte')
    triage_id = fields.Many2one('oeh.medical.evaluation.triage', string='Triaje')

    @api.model
    def create(self, vals):
        sequence = self.env['ir.sequence'].next_by_code('oeh.medical.emergency')
        vals['name'] = sequence
        return super(OehMedicalEmergency, self).create(vals)

    @api.multi
    def goto_triage_form(self):
        self.ensure_one()
        return {
            'string': 'Triaje de emergencia',
            'name': 'Triaje de emergencia',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': False,
            'res_model': 'oeh.medical.evaluation.triage',
            'domain': [],
            'context': {
                'default_patient_id': self.patient_id.id,
                'default_emergency_id': self.id,
                'default_is_emergency': True,
            },
            'target': 'online',
            'type': 'ir.actions.act_window',
            'res_id': self.triage_id.id
        }


class OehMedicalEmergencyTriage(models.Model):
    _name = 'oeh.medical.emergency.triage'
    _inherit = 'oeh.medical.evaluation.triage'

    name = fields.Char(u'Código de triaje de emergencia', size=64, readonly=True, required=True, default=lambda *a: '/')
    state = fields.Selection(EMERGENCY_STATE, 'Estado', readonly=True, default=lambda *e: IN_ADMISSION)
