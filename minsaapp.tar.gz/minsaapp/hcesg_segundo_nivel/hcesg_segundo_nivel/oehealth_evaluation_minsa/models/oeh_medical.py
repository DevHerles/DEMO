# -*- coding: utf-8 -*-

from odoo import api, fields, models, tools
from odoo.exceptions import ValidationError

from .constants import (ESTADO_DE_CONCIENCIA_CHOICES,
                        ESTADO_DE_HIDRATACION_CHOICES,
                        GRADO_DE_ESTUDIO_CHOICES,
                        TIPO_INSTITUCION_EDUCATIVA_CHOICES,
                        TIPO_TRABAJO_CHOICES)

SELECTION_FREQUENCY = [
    ('day', u'Día'),
    ('week', 'Semana'),
    ('fortnight', 'Quincenal'),
    ('monthly', 'Mensual'),
    ('year', u'Año'),
]

MUJER = 'Mujer'
HOMBRE = 'Hombre'

GENDER = [
    ('0', HOMBRE),
    ('1', MUJER)
]

MEDICINE = 'Medicine'
MEDICAMENT_TYPE = MEDICINE

RIESGO_DE_ENFEMERDAD_BAJO = 'BAJO'
RIESGO_DE_ENFEMERDAD_ALTO = 'ALTO'
RIESGO_DE_ENFEMERDAD_MUY_ALTO = 'MUY ALTO'

TALLA_BAJA_SEVERA = 'BAJA SEVERA'
TALLA_BAJA = 'BAJA'
TALLA_NORMAL = 'NORMAL'
TALLA_ALTA = 'ALTA'

IMC_OBESIDAD = 'OBESIDAD'
IMC_SOBREPESO = 'SOBREPESO'
IMC_NORMAL = 'NORMAL'
IMC_DELGADEZ = 'DELGADEZ'
IMC_DELGADEZ_SEVERA = 'DEGADEZ SEVERA'

FAMILY_RELATION = [
    ('Father', 'Padre'),
    ('Mother', 'Madre'),
    ('Brother', 'Hermano'),
    ('Sister', 'Hermana'),
    ('Wife', 'Esposa'),
    ('Husband', 'Esposo'),
    ('Grand Father', 'Abuelo'),
    ('Grand Mother', 'Abuela'),
    ('Aunt', 'Tío'),
    ('Uncle', 'Tía'),
    ('Nephew', 'Sobrino'),
    ('Niece', 'Sobrina'),
    ('Cousin', 'Primo'),
    ('Relative', 'Pariente'),
    ('Other', 'Otro'),
]

STATE_PENDING = 'pendiente'
STATE_TRIAD = 'triado'

STATES = [
    (STATE_PENDING, 'Pendiente'),
    (STATE_TRIAD, 'Triado'),
]


class OeHealthPatientEvaluation(models.Model):
    _inherit = 'oeh.medical.evaluation'

    SEX = [
        ('Male', 'Hombre'),
        ('Female', 'Mujer'),
    ]

    def _default_sex_history(self):
        sex_history_ids = self.env['sexual.history'].search([]).ids
        return [
            (0, 0, {'sex_history_id': sex_history_id})
            for sex_history_id in sex_history_ids
        ]

    def _default_contraceptive_method(self):
        contraceptive_method_ids = self.env['contraceptive.method'].search([]).ids
        return [
            (0, 0, {'contraceptive_method_id': contraceptive_method_id})
            for contraceptive_method_id in contraceptive_method_ids
        ]

    def _default_habits_harmful(self):
        habits_ids = self.env['habits'].search([('harmful', '=', True)]).ids
        return [
            (0, 0, {'habits_id': habits_id})
            for habits_id in habits_ids
        ]

    def _default_general_habits(self):
        habits_ids = self.env['habits'].search([('harmful', '=', False)]).ids
        return [
            (0, 0, {'habits_id': habits_id})
            for habits_id in habits_ids
        ]

    condition = fields.Boolean('Condicion')
    fever = fields.Boolean('Fiebre en los últimos 15 días')
    cough = fields.Boolean('Tos de más de 15 días')
    secretion = fields.Boolean('Secreción o lesiones genitales')
    type = fields.Char('#')
    period = fields.Selection(
        [
            ('hours', 'Horas'),
            ('days', 'Días'),
            ('weeks', 'Semanas'),
            ('months', 'Meses'),
            ('years', 'Años')
        ],
        'Tiempo',
    )
    evaluation_start_date = fields.Datetime('Evalution Date', required=False)
    observation = fields.Text()
    appetite = fields.Selection([('conserved', 'Conservado'), ('change', 'Alterado')])
    thirst = fields.Selection([('conserved', 'Conservado'), ('change', 'Alterado')])
    dream = fields.Selection([('conserved', 'Conservado'), ('change', 'Alterado')])
    urine = fields.Selection([('conserved', 'Conservado'), ('change', 'Alterado')])
    stools = fields.Selection([('conserved', 'Conservado'), ('change', 'Alterado')])
    state = fields.Selection([('conserved', 'Conservado'), ('change', 'Alterado')])
    observation_appetite = fields.Char()
    observation_thirst = fields.Char()
    observation_dream = fields.Char()
    observation_urine = fields.Char()
    observation_stools = fields.Char()
    observation_state = fields.Char()
    external_examination_izquierdo = fields.Char()
    visual_acuity_izquierdo = fields.Char()
    eye_pressure_izquierdo = fields.Char()
    eye_fund_izquierdo = fields.Char()
    external_examination_derecho = fields.Char()
    visual_acuity_derecho = fields.Char()
    eye_pressure_derecho = fields.Char()
    eye_fund_derecho = fields.Char()
    skin = fields.Selection(
        [('not', 'No Aplica'), ('conserved', 'Conservado'), ('pathological', 'Patologico')])
    head_and_neck = fields.Selection(
        [('not', 'No Aplica'), ('conserved', 'Conservado'), ('pathological', 'Patologico')])
    oral_cavity = fields.Selection(
        [('not', 'No Aplica'), ('conserved', 'Conservado'), ('pathological', 'Patologico')])
    respiratory_system_one = fields.Selection(
        [('not', 'No Aplica'), ('conserved', 'Conservado'), ('pathological', 'Patologico')])
    cardiovascular_apparatus = fields.Selection(
        [('not', 'No Aplica'), ('conserved', 'Conservado'), ('pathological', 'Patologico')])
    digestive_system = fields.Selection(
        [('not', 'No Aplica'), ('conserved', 'Conservado'), ('pathological', 'Patologico')])
    abdomen = fields.Selection(
        [('not', 'No Aplica'), ('conserved', 'Conservado'), ('pathological', 'Patologico')])
    genitourinary_device = fields.Selection(
        [('not', 'No Aplica'), ('conserved', 'Conservado'), ('pathological', 'Patologico')])
    prostate_examination = fields.Selection(
        [('not', 'No Aplica'), ('conserved', 'Conservado'), ('pathological', 'Patologico')])
    respiratory_system = fields.Selection(
        [('not', 'No Aplica'), ('conserved', 'Conservado'), ('pathological', 'Patologico')])
    pelvic_exam = fields.Selection(
        [('not', 'No Aplica'), ('conserved', 'Conservado'), ('pathological', 'Patologico')])
    cervix = fields.Selection(
        [('not', 'No Aplica'), ('conserved', 'Conservado'), ('pathological', 'Patologico')])
    locomotor_apparatus = fields.Selection(
        [('not', 'No Aplica'), ('conserved', 'Conservado'), ('pathological', 'Patologico')])
    observation_skin = fields.Char()
    observation_head_and_neck = fields.Char()
    observation_oral_cavity = fields.Char()
    observation_respiratory_system_one = fields.Char()
    observation_cardiovascular_apparatus = fields.Char()
    observation_digestive_system = fields.Char()
    observation_abdomen = fields.Char()
    observation_genitourinary_device = fields.Char()
    observation_prostate_examination = fields.Char()
    observation_respiratory_system = fields.Char()
    observation_pelvic_exam = fields.Char()
    observation_cervix = fields.Char()
    observation_locomotor_apparatus = fields.Char()
    diagnosis_ids = fields.One2many('minsa.evaluation.diagnosis', 'evaluation_id')
    prescription_ids = fields.One2many('oeh.medical.prescription', 'evaluation_id', string='Receta')
    laboratory_ids = fields.One2many('oeh.medical.lab.test', 'evaluation_id')
    process_ids = fields.One2many('oeh.medical.surgery', 'evaluation_id')
    images_ids = fields.One2many('oeh.medical.imaging', 'evaluation_id')
    derivation = fields.Text()
    observation_derivation = fields.Text()
    awareness_select = fields.Selection([
        ('lucy', 'Lucido'), ('obnu', 'Obnubilado'), ('confu', 'Confundido')
    ])
    awareness_description = fields.Char()
    orientation_type = fields.Selection([('orient', 'Orientado'), ('deso', 'Desorientado')])
    orientation_select = fields.Selection([('orient', 'Orientado'), ('deso', 'Desorientado')])
    orientation_description = fields.Char()
    attention_select = fields.Selection([('conser', 'Conservada'), ('disable', 'Distraibilidad')])
    attention_description = fields.Char()
    encouragement_select = fields.Selection(
        [('eutimico', 'Eutimico'), ('hipertimico', 'Hipertimico'), ('hipotimico', 'Hipotimico')])
    encouragement_description = fields.Char()
    language_select = fields.Selection(
        [('normal', 'Normal'), ('tartamudeo', 'Tartamudeo'), ('disartris', 'Disartrias'),
         ('dislalis', 'Dislalias')])
    language_description = fields.Char()
    thinking_type = fields.Selection([('curso', 'Curso'), ('forma', 'Forma'), ('contenido', 'Contenido')])
    thinking_type_course = fields.Boolean()
    thinking_type_form = fields.Boolean()
    thinking_type_conten = fields.Boolean()
    thinking_select = fields.Selection([('curso', 'Curso'), ('forma', 'Forma'), ('contenido', 'Contenido')])
    thinking_description = fields.Char()
    memory_cmb = fields.Selection(
        [('conservada', 'Conservada'), ('olvido', 'Olvidos Frecuentes'), ('amnesia', 'Amnesia')])
    memory_txt = fields.Char()
    sensory_perception_select = fields.Selection([('alucinaciones', 'Alucinaciones')])
    sensory_perception_description = fields.Char()
    reflection_self_criticism_comment = fields.Char()
    reflection_self_criticism_description = fields.Char()
    imc = fields.Float(compute='_compute_imc', size=(5, 2))
    bodily = fields.Selection([
        ('delgadez_i', 'Delgadez I'),
        ('delgadez_ii', 'Delgadez II'),
        ('delgadez_iii', 'Delgadez III'),
        ('peso_normal', 'Peso Normal'),
        ('sobrepeso', 'Sobrepeso'),
        ('obesidad_i', 'Obesidad I'),
        ('obesidad_ii', 'Obesidad II'),
        ('obesidad_iii', 'Obesidad III')
    ])
    date_ultimate = fields.Date(string='Ultima Menstruacion(FUM)')
    date_ultimate_catameal = fields.Char(string='Fecha Catameneal')
    temperature = fields.Float(string='Temperature (celsius)', digits=(5, 2))
    diastolic = fields.Integer(string='Diastolic Pressure')
    weight = fields.Float(string='Weight (kg)', digits=(5, 3))
    height = fields.Float(string='Height (cm)', digits=(5, 2))
    abdominal_circ = fields.Float(string='Abdominal Circumference', digits=(5, 1))
    state_evaluation = fields.Selection(selection=[('pending', 'Pendiente'), ('attended', 'Atendido')],
                                        default='pending')
    image = fields.Binary(related='patient.image')
    image_medium = fields.Binary(related='patient.image_medium')
    age_patient = fields.Char(related='patient.edad', readonly=True)
    sex_patient = fields.Selection(SEX, related='patient.sex', readonly=True, store=True)
    date_birth_patient = fields.Date(related='patient.dob', readonly=True, store=True)
    sis_tipo_seguro_descripcion = fields.Char(
        related='patient.sis_tipo_seguro_descripcion')
    sis_estado = fields.Char(related='patient.sis_estado', readonly=True, store=True)
    a_state_id = fields.Many2one(related='patient.a_state_id', readonly=True, store=True)
    a_province_id = fields.Many2one(related='patient.a_province_id', readonly=True, store=True)
    a_district_id = fields.Many2one(related='patient.a_district_id', readonly=True, store=True)
    personal_diagnosis_ids = fields.One2many(related='patient.personal_diagnosis_ids')
    family_diagnosis_ids = fields.One2many(related='patient.family_diagnosis_ids')
    allergie_medication_ids = fields.Many2many(
        'catalogominsa.medicamento', compute='_compute_catalogominsa_medicina',
        string=u'Alergias medicam.')
    cranial_perimeter = fields.Integer()
    thoracic_perimeter = fields.Integer()
    age_calculate = fields.Integer(compute='_compute_age_patient', store=True)
    condition_detalle = fields.Selection(
        selection=[('pregnant', 'Gestante'), ('puerperium', 'Puerperea')])
    height_centimeter = fields.Integer()
    gestational_age = fields.Integer()
    patient_family_id = fields.Many2one(related='patient.patient_family_id', readonly=True)
    sex_patient_family = fields.Selection(
        related='patient_family_id.name.sex', readonly=True)
    # Personales autorreportados
    reported_personal_ids = fields.One2many(
        'minsa.self.reported.personal', 'evaluation_id',
        string=u'Personales autoreportados')
    # Clinicos familiares autoreportados
    reported_family_ids = fields.One2many(
        'minsa.self.reported.family.clinics', 'evaluation_id',
        string=u'Clínicos familiares autoreportados')
    # Reaciones adversas a medicamentos
    adverse_drug_reaction_ids = fields.One2many(
        'adverse.drug.reactions', 'evaluation_id',
        string='Reaciones adversas a medicamentos')
    # Sexuales y reproductivo
    sex_history_ids = fields.One2many(
        'minsa.evaluation.sexual.history.line', 'evaluation_id',
        string='Antecedentes sexuales', default=_default_sex_history)
    contraceptive_method_ids = fields.One2many(
        'minsa.contraceptive.method.line', 'evaluation_id',
        string=u'Métodos anticonceptivos',
        default=_default_contraceptive_method)
    harmful_habits_ids = fields.One2many(
        'harmful.habits.line', 'evaluation_id', string=u'Hábitos nocivos',
        default=_default_habits_harmful)
    general_habits_ids = fields.One2many(
        'general.habits.line', 'evaluation_id', string=u'Hábitos generales',
        default=_default_general_habits)
    physical_activity = fields.Selection(
        selection=[('1', 'Moderada'), ('2', 'Intensa')], string='Actividad Física')
    frequency = fields.Integer(string='Frecuencia (min/semana)')
    number_of_servings = fields.Integer(string=u'N° de raciones de frutas al día')
    daily_water_consumption = fields.Integer(string=u'Consumo de agua al día (litros)')
    # Laborales
    work = fields.Boolean(string='Trabaja?')
    paid = fields.Boolean(string='Remunerado?')
    stable = fields.Boolean(string='Estable?')
    full_time = fields.Boolean(string='Tiempo completo?')
    age_start_work = fields.Integer(string='Edad inicio trabajo')
    type_work = fields.Selection(
        selection=TIPO_TRABAJO_CHOICES, string='Tipo trabajo')
    # Educación
    country_id = fields.Many2one(
        comodel_name='res.country', string=u'País',
        default=lambda self: self.env['ir.model.data'].xmlid_to_res_id('base.pe'))
    state_id = fields.Many2one(comodel_name='res.country.state', string=u'Región')
    province_id = fields.Many2one(comodel_name='res.country.state', string='Provincia')
    district_id = fields.Many2one(comodel_name='res.country.state', string='Distrito')
    name_institution = fields.Char(string='Nombre')
    type_institution = fields.Selection(
        selection=TIPO_INSTITUCION_EDUCATIVA_CHOICES, string='Tipo')
    study_grade = fields.Selection(
        selection=GRADO_DE_ESTUDIO_CHOICES, string='Grado de estudio (si es colegio)')
    age_school_end = fields.Integer(string='Edad en que culmina el colegio')
    according_to_age = fields.Boolean(string='¿De acuerdo a la edad?')
    low_performance = fields.Boolean(string='¿Bajo rendimiento?')
    desertion = fields.Boolean(string='¿Deserción?')
    repeat = fields.Boolean(string='¿Repitencia?')
    # Medicación Habitual
    usual_medication_ids = fields.One2many(
        'usual.medication', 'evaluation_id', string=u'Medicación habitual')

    @api.depends('adverse_drug_reaction_ids.medicament_id')
    def _compute_catalogominsa_medicina(self):
        for item in self:
            medicament_ids = [i.medicament_id.id for i in item.adverse_drug_reaction_ids]
            item.allergie_medication_ids = medicament_ids

    # #### Nuevo Formato
    # Motivo de Atencion(ma_)
    ma_descripcion = fields.Text('Motivo de Atención', required=True)
    ma_tiempoenfermedad = fields.Integer('Tiempo de Enfermedad')
    ma_unidad = fields.Selection([
        ('d', 'dias'),
        ('s', 'Semanas'),
        ('m', 'Meses'),
        ('a', 'Años')
    ], 'Unidad')
    ma_formainicio = fields.Selection([('insidioso', 'Insidioso'), ('abrupto', 'Abrupto')], 'Forma de Inicio')
    ma_cursoenfermedad = fields.Selection(
        [('sa', 'Sobre Agudo'), ('a', 'Agudo'), ('suba', 'Subagudo'), ('c', 'Crónico')], 'Cruso de Enfermedad')

    # Signos Vitales(sv) y Datos Antropometricos(da)
    sv_temperatura = fields.Float('Temperatura(C°)')
    sv_presionarterial = fields.Char('Presión Arterial')
    sv_freccardiaca = fields.Char('Forma Cardiaca', size=3)
    sv_frecrespiratoria = fields.Char('Frec. Respiratoria', size=3)
    sv_saturacion = fields.Char('Saturación', size=3)
    da_peso_g = fields.Float('Peso(Gramos)')
    da_talla_cm = fields.Float('Talla(Centímetros)')
    da_peso_kg = fields.Float('Peso(Kg)')
    da_talla_m = fields.Float('Talla(Metros)')
    da_perimetrocefalico = fields.Float(u'Perímetro cefálico')
    da_perimetroabdominal = fields.Float(u'Perímetro abdominal')
    da_imc = fields.Float('IMC(Kg/m2)', compute='_compute_imc_ac')
    da_estado_imc = fields.Char('Estado IMC)', size=30)
    da_riesgodeenfermedad = fields.Char('Riesgo de enfermedad', compute='_compute_da_riesgodeenfermedad', store=True)
    da_sc = fields.Float('Superfice corporal', compute='_compute_da_sc', store=True)
    da_imc = fields.Float(compute='_compute_da_imc', store=True)
    da_clasificacionimc = fields.Char(u'Clasificación IMC', compute='_compute_da_clasificacionimc', store=True)
    da_clasificaciontalla = fields.Char(u'Clasificación talla', compute='_compute_da_clasificaciontalla', store=True)
    age_string = fields.Char()
    patient_age_years_int = fields.Integer(related='patient.age_years_int', store=True)
    patient_age_months_int = fields.Integer(related='patient.age_months_int', store=True)

    # Signos y Sintomas
    sintomas_ids = fields.One2many(
        'minsa.evaluation.sintomas',
        'evaluation_id',
        string='Evaluacion'
    )

    # Funciones Biologicas(fb)
    SELECTION_CONSERVADO_ALTERADO = [
        ('1', 'Conservado'),
        ('2', 'Patológico'),
        ('3', 'No examinado'),
    ]
    fb_1 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Apetito')
    fb_2 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Sed')
    fb_3 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Sueño')
    fb_4 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Orina')
    fb_5 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Deposiciones')
    fb_6 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Estado de Ánimo')

    fb_1_obs = fields.Char('Func. Biologica 1/Observación')
    fb_2_obs = fields.Char('Func. Biologica 2/Observación')
    fb_3_obs = fields.Char('Func. Biologica 3/Observación')
    fb_4_obs = fields.Char('Func. Biologica 4/Observación')
    fb_5_obs = fields.Char('Func. Biologica 5/Observación')
    fb_6_obs = fields.Char('Func. Biologica 6/Observación')

    # Examen Físico(ef)
    # General
    DELGADEZ_I = 'delgadez_i'
    DELGADEZ_II = 'delgadez_ii'
    DELGADEZ_III = 'delgadez_iii'
    PESO_NORMAL = 'peso_normal'
    SOBREPESO = 'sobrepeso'
    OBESIDAD_I = 'obesidad_i'
    OBESIDAD_II = 'obesidad_ii'
    OBESIDAD_III = 'obesidad_iii'

    SELECTION_BODILY = [
        (DELGADEZ_I, 'Delgadez I'),
        (DELGADEZ_II, 'Delgadez II'),
        (DELGADEZ_III, 'Delgadez III'),
        (PESO_NORMAL, 'Peso Normal'),
        (SOBREPESO, 'Sobrepeso'),
        (OBESIDAD_I, 'Obesidad I'),
        (OBESIDAD_II, 'Obesidad II'),
        (OBESIDAD_III, 'Obesidad III')
    ]

    # efg_ = Examen físico general
    efg_1_st = fields.Selection(SELECTION_BODILY, 'Estado')
    efg_2_st = fields.Selection(ESTADO_DE_HIDRATACION_CHOICES, 'Estado')
    efg_3_st = fields.Selection(ESTADO_DE_CONCIENCIA_CHOICES, 'Estado')
    efg_1_obs = fields.Char('Observaciones')
    efg_2_obs = fields.Char('Observaciones')
    efg_3_obs = fields.Char('Observaciones')

    # Regional
    ef_1 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Piel', default=3)
    ef_2 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Cabeza y Cuello', default=3)
    ef_3 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Cavidad Oral', default=3)
    ef_4 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Mama', default=3)
    ef_5 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Aparato Respiratorio', default=3)
    ef_6 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Aparato Cardiovascular', default=3)
    ef_7 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Aparato Digestivo', default=3)
    ef_8 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Abdomen', default=3)
    ef_9 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Aparato Genitourinario', default=3)
    ef_10 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Examen de Prostata', default=3)
    ef_11 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Pélvico', default=3)
    ef_12 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Cuello uterino', default=3)
    ef_13 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Aparato Locomotor', default=3)
    ef_14 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Tejido celular subcutaneo', default=3)
    ef_15 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Tórax', default=3)
    ef_16 = fields.Selection(SELECTION_CONSERVADO_ALTERADO, 'Examen neurológico', default=3)

    ef_1_obs = fields.Char('Exam. Físico 1/Observación')
    ef_2_obs = fields.Char('Exam. Físico 2/Observación')
    ef_3_obs = fields.Char('Exam. Físico 3/Observación')
    ef_4_obs = fields.Char('Exam. Físico 4/Observación')
    ef_5_obs = fields.Char('Exam. Físico 5/Observación')
    ef_6_obs = fields.Char('Exam. Físico 6/Observación')
    ef_7_obs = fields.Char('Exam. Físico 7/Observación')
    ef_8_obs = fields.Char('Exam. Físico 8/Observación')
    ef_9_obs = fields.Char('Exam. Físico 9/Observación')
    ef_10_obs = fields.Char('Exam. Físico 10/Observación')
    ef_11_obs = fields.Char('Exam. Físico 11/Observación')
    ef_12_obs = fields.Char('Exam. Físico 12/Observación')
    ef_13_obs = fields.Char('Exam. Físico 13/Observación')
    ef_14_obs = fields.Char('Exam. Físico 14/Observación')
    ef_15_obs = fields.Char('Exam. Físico 15/Observación')
    ef_16_obs = fields.Char('Exam. Físico 16/Observación')

    # Diagnostico(diag)
    SELECTION_TIPO_DIAG = [
        ('1', 'Presuntivo'),
        ('0', 'Definitivo'),
    ]
    diag_tipo_1 = fields.Selection(SELECTION_TIPO_DIAG, 'Tipo Diagnostico 1')
    diag_tipo_2 = fields.Selection(SELECTION_TIPO_DIAG, 'Tipo Diagnostico 2')
    diag_tipo_3 = fields.Selection(SELECTION_TIPO_DIAG, 'Tipo Diagnostico 3')
    diag_antec_1 = fields.Boolean('Antecedentes 1')
    diag_antec_2 = fields.Boolean('Antecedentes 2')
    diag_antec_3 = fields.Boolean('Antecedentes 3')
    diag_obs_1 = fields.Char('Observación/Diagnostico 1')
    diag_obs_2 = fields.Char('Observación/Diagnostico 2')
    diag_obs_3 = fields.Char('Observación/Diagnostico 3')

    @api.constrains('sv_temperatura')
    def _check_sv_temperatura(self):
        for record in self:
            if record.sv_temperatura and record.sv_temperatura < 1:
                raise ValidationError('La temperatura debe ser mayor que cero (0)')

    @api.constrains('da_peso_g', 'da_peso_kg')
    def _check_da_peso_g(self):
        for record in self:
            if not record.da_peso_kg and record.da_peso_g < 1:
                raise ValidationError('El peso debe ser mayor que cero (0) gramos')

    @api.constrains('da_peso_kg', 'da_peso_g')
    def _check_da_pego_kg(self):
        for record in self:
            if not record.da_peso_g and record.da_peso_kg < 1:
                raise ValidationError('El peso debe ser mayor que cero (0) Kilogramos')

    @api.constrains('da_talla_cm', 'da_talla_m')
    def _check_da_talla_cm(self):
        for record in self:
            if not record.da_talla_m and record.da_talla_cm < 1:
                raise ValidationError(u'La talla debe ser mayor que cero (0) centímetros')

    @api.constrains('da_talla_m', 'da_talla_cm')
    def _check_da_talla_m(self):
        for record in self:
            if not record.da_talla_cm and record.da_talla_m and record.da_talla_m < 0.5:
                raise ValidationError('La talla debe ser mayor o igual que cero punto cinco (0.5) metros')

    @api.constrains('da_perimetroabdominal')
    def _check_da_perimetroabdominal(self):
        for record in self:
            if record.patient_age_years_int >= 12 and 30 > record.da_perimetroabdominal > 300:
                raise ValidationError('El perímetro abdominal debe ser entre 30 y 300 cm.')

    @api.constrains('da_perimetrocefalico', 'patient_age_years_int')
    def _check_perimetrocefalico(self):
        for record in self:
            if self.patient_age_years_int == 0 and record.da_perimetrocefalico < 1:
                raise ValidationError(u'El perimetro cefálico debe ser mayor que cero (0)')

    @api.depends('da_perimetroabdominal', 'sex_patient', 'patient_age_years_int')
    def _compute_da_riesgodeenfermedad(self):
        for record in self:
            if not record.da_perimetroabdominal:
                continue

            domain = [('age', '=', record.patient_age_years_int),
                      ('gender', '=', int(record.sex_patient))]
            edad = record.env['oeh.medical.evaluation.riesgoenfermedad1217'].search(domain, limit=1)

            if not edad:
                continue

            if record.da_perimetroabdominal < edad.rsm:
                riesgo = RIESGO_DE_ENFEMERDAD_BAJO
            elif edad.rsm <= record.da_perimetroabdominal < edad.rma:
                riesgo = RIESGO_DE_ENFEMERDAD_ALTO
            else:
                riesgo = RIESGO_DE_ENFEMERDAD_MUY_ALTO

            record.da_riesgodeenfermedad = riesgo

    @api.depends('da_imc', 'sex_patient', 'patient_age_months_int')
    def _compute_da_clasificacionimc(self):
        for record in self:
            if not record.da_imc:
                continue

            domain = [('month', '=', record.patient_age_months_int),
                      ('gender', '=', int(record.sex_patient))]
            month = record.env['oeh.medical.evaluation.imc517'].search(domain, limit=1)

            if not month:
                continue

            if record.da_imc < month.f__3:
                resultado = IMC_DELGADEZ_SEVERA
            elif month.f__3 <= record.da_imc < month.f__2:
                resultado = IMC_DELGADEZ
            elif month.f__2 <= record.da_imc < month.f_1:
                resultado = IMC_NORMAL
            elif month.f_1 <= record.da_imc < month.f_2:
                resultado = IMC_SOBREPESO
            else:
                resultado = IMC_OBESIDAD

            record.da_clasificacionimc = resultado

    @api.depends('da_talla_m', 'sex_patient', 'patient_age_months_int')
    def _compute_da_clasificaciontalla(self):
        for record in self:
            if not record.da_talla_m:
                continue

            domain = [('month', '=', record.patient_age_months_int),
                      ('gender', '=', int(record.sex_patient))]
            month = record.env['oeh.medical.evaluation.talla517'].search(domain, limit=1)
            talla_cm = record.da_talla_m * 100

            if not month:
                continue

            if talla_cm < month.f__3:
                resultado = TALLA_BAJA_SEVERA
            elif month.f__3 <= talla_cm < month.f__2:
                resultado = TALLA_BAJA
            elif month.f__2 <= talla_cm < month.f_2:
                resultado = TALLA_NORMAL
            else:
                resultado = TALLA_ALTA

            record.da_clasificaciontalla = resultado

    @api.depends('da_peso_kg', 'da_talla_m')
    def _compute_da_imc(self):
        for record in self:
            check = record.da_peso_kg and record.da_talla_m
            imc = check and record.da_peso_kg / (record.da_talla_m ** 2)
            record.da_imc = round(imc, 2)

    @api.constrains('da_peso_g', 'da_peso_kg')
    def _check_da_peso_g_kg(self):
        for record in self:
            if record.da_peso_g > 0 and record.da_peso_kg > 0:
                raise ValidationError('Ingrese solamente peso en kilos o gramos, no ingrese los dos.')

    @api.depends('da_peso_g', 'da_peso_kg')
    def _compute_da_sc(self):
        for record in self:
            peso = record.da_peso_g or record.da_peso_kg
            sc = (peso * 4 + 7) / (peso + 90)
            record.da_sc = round(sc, 2)

    @api.depends('da_peso_kg', 'da_talla_m')
    def _compute_imc_ac(self):
        for record in self:
            check = record.da_peso_kg and record.da_talla_m
            imc = check and record.da_peso_kg / (record.da_talla_m ** 2)
            record.da_imc = round(imc, 2)

    @api.onchange('imc')
    def _onchange_bodily(self):
        if self.imc:
            if 0 < self.imc <= 16.00:
                self.bodily = 'delgadez_iii'
            elif 16.00 < self.imc < 17.00:
                self.bodily = 'delgadez_ii'
            elif 17.00 <= self.imc < 18.50:
                self.bodily = 'delgadez_i'
            elif 18.50 <= self.imc < 25.00:
                self.bodily = 'peso_normal'
            elif 25.00 <= self.imc < 29.99:
                self.bodily = 'sobrepeso'
            elif 30.00 <= self.imc < 35.00:
                self.bodily = 'obesidad_i'
            elif 35.00 <= self.imc < 40.00:
                self.bodily = 'obesidad_ii'
            elif self.imc > 40.00:
                self.bodily = 'obesidad_iii'
            else:
                self.bodily = False

    @api.multi
    def load_consultation(self):
        form = self.env.ref('oehealth_evaluation_minsa.view_wizard_consultation_form', False)
        return {
            'type': 'ir.actions.act_window',
            'name': 'Interconsulta',
            'res_model': 'wizard.consultation',
            'views': [(form.id, 'form')],
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': form.id,
            'target': 'new',
        }

    @api.multi
    def load_reference(self):
        form = self.env.ref('oehealth_evaluation_minsa.view_wizard_reference_form', False)
        return {
            'type': 'ir.actions.act_window',
            'name': 'Referencias',
            'res_model': 'wizard.reference',
            'views': [(form.id, 'form')],
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': form.id,
            'target': 'new',
        }

    @api.one
    def set_attended(self):
        self.write({'state_evaluation': 'attended'})
        self.appointment.write({'state': 'Completed'})

    @api.multi
    def load_pathology(self):
        form = self.env.ref(
            'oehealth_evaluation_minsa.view_pathology_wizard_form', False
        )
        return {
            'type': 'ir.actions.act_window',
            'name': 'Cargar Enfermedades',
            'res_model': 'pathology.wizard',
            'views': [(form.id, 'form')],
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': form.id,
            'target': 'new'
        }


class OehMedicalImaging(models.Model):
    _inherit = 'oeh.medical.imaging'

    evaluation_id = fields.Many2one('oeh.medical.evaluation')


class OehMedicalLabTest(models.Model):
    _inherit = 'oeh.medical.lab.test'

    evaluation_id = fields.Many2one('oeh.medical.evaluation')


class OehMedicalSurgery(models.Model):
    _inherit = 'oeh.medical.surgery'

    evaluation_id = fields.Many2one('oeh.medical.evaluation')


class OehMedicalPrescription(models.Model):
    _inherit = 'oeh.medical.prescription'

    evaluation_id = fields.Many2one('oeh.medical.evaluation')


class OehMedicalPrescriptionLine(models.Model):
    _inherit = 'oeh.medical.prescription.line'

    evaluation_id = fields.Many2one('oeh.medical.evaluation')
    diagnosis_id = fields.Many2one('minsa.evaluation.diagnosis')
    indication = fields.Many2one('minsa.evaluation.diagnosis')
    patient_id = fields.Many2one('oeh.medical.patient')

    @api.model_cr
    def init(self):
        tools.drop_view_if_exists(self._cr, 'oeh_medical_prescription_line_indication')
        self._cr.execute('''
            CREATE OR REPLACE VIEW oeh_medical_prescription_line_indication AS (
                SELECT
                    oeh.id as indication
                FROM oeh_medical_evaluation oeh
                INNER JOIN minsa_evaluation_diagnosis min ON oeh.id = min.evaluation_id
            )''')

    # Autopopulate selected medicine values
    @api.multi
    def onchange_medicine_id(self, medicine_id=False):
        result = {}
        if medicine_id:
            medicines_model = self.env['product.template']
            medicine = medicines_model.search([('id', '=', medicine_id)], limit=1)
            if medicine:
                result = {
                    'composition': medicine.composition,
                    'concentracion': medicine.concentracion,
                    'presentacion': medicine.presentacion,
                    'forma_farmaceutica': medicine.forma_farmaceutica.name,
                }
        return {'value': result}


class MinsaSelfReportedPersonal(models.Model):
    _name = 'minsa.self.reported.personal'
    _description = u'MINSA personales autoreportados'
    _rec_name = 'pathology_id'

    evaluation_id = fields.Many2one('oeh.medical.evaluation')
    pathology_id = fields.Many2one('oeh.medical.pathology', u'Diagnóstico Definitivo')
    diagnostic_date = fields.Date(u'Fecha diagnosticó')
    description = fields.Text(u'Descripción')


class MinsaSelfReportedFamilyClinics(models.Model):
    _name = 'minsa.self.reported.family.clinics'
    _description = u'MINSA clínicos familiares autoreportados'
    _rec_name = 'pathology_id'

    evaluation_id = fields.Many2one('oeh.medical.evaluation')
    relation = fields.Selection(FAMILY_RELATION, 'Parentesco')
    pathology_id = fields.Many2one('oeh.medical.pathology', u'Diagnóstico Definitivo')
    diagnostic_date = fields.Date(u'Fecha diagnosticó')
    observation = fields.Text(u'Observación')


class AdverseDrugReactions(models.Model):
    _name = 'adverse.drug.reactions'

    evaluation_id = fields.Many2one('oeh.medical.evaluation')
    name = fields.Many2one(
        'catalogominsa.medicina.familia', 'Familia de medicamento',
        required=True)
    code = fields.Char(related='name.code')
    medicament_id = fields.Many2one(
        'catalogominsa.medicamento', u'Medicamento',
        required=True)
    diagnostic_year = fields.Integer(u'Año diagnostico')
    year_last_occurrence = fields.Integer(u'Año ult. ocurrencia')
    observation = fields.Text(u'Observaciones')


class OehMedicalPathology(models.Model):
    _inherit = 'oeh.medical.pathology'

    @api.multi
    def name_get(self):
        names = []
        for record in self:
            name = u'{} - {}'.format(record.code or '', record.name or '')
            names.append((record.id, name.upper()))

        return names

    @api.model
    def name_search(self, name, args=[], operator='ilike', limit=80):
        args = args or []
        recs = self.browse()
        if name:
            domain = [('code', operator, 'R'), '|', ('code', operator, name), ('name', operator, name)]
            recs = self.search(domain, limit=10)
        if not recs:
            recs = self.search([('name', operator, name)] + args, limit=limit)
        return recs.name_get()


class MinsaEvaluationSintomas(models.Model):
    _name = 'minsa.evaluation.sintomas'

    evaluation_id = fields.Many2one('oeh.medical.evaluation')
    pathology_id = fields.Many2one('oeh.medical.pathology', string='Catálogo CIE 10')


class MinsaEvaluationDiagnosis(models.Model):
    _name = 'minsa.evaluation.diagnosis'
    _rec_name = 'pathology_id'

    SELECTION_TYPE_DIAGNOSIS = [
        ('Presuntivo', 'Presuntivo'),
        ('Repetitivo', 'Repetitivo'),
        ('Definitivo', 'Definitivo'),
    ]

    evaluation_id = fields.Many2one('oeh.medical.evaluation')
    pathology_id = fields.Many2one(
        'oeh.medical.pathology', 'Código nomenclatura CIE 10',
        required=True)
    date = fields.Datetime()
    description = fields.Char('Observaciones')
    type_diagnosis = fields.Selection(SELECTION_TYPE_DIAGNOSIS, 'Tipo de diagnóstico')
    register_antec = fields.Boolean(string='¿Registrar como antecedentes personales?')
    lab_1 = fields.Char('LAB 1', size=3)
    lab_2 = fields.Char('LAB 2', size=3)

    @api.onchange('lab_1')
    def onchange_lab_1(self):
        if self.lab_1:
            self.lab_1 = self.lab_1.upper()

    @api.onchange('lab_2')
    def onchange_lab_2(self):
        if self.lab_2:
            self.lab_2 = self.lab_2.upper()


class MinsaEvaluationSexualHistoryLine(models.Model):
    _name = 'minsa.evaluation.sexual.history.line'

    SELECTION_UNITS = [
        ('year', u'Años'),
        ('couple', 'Pareja'),
    ]

    evaluation_id = fields.Many2one('oeh.medical.evaluation')
    sex_history_id = fields.Many2one('sexual.history', 'Antecedentes')
    state = fields.Boolean('Estado')
    figure = fields.Integer('Cifra')
    units = fields.Selection(SELECTION_UNITS, 'Unidades')
    observation = fields.Text('Observaciones')


class SexualHistory(models.Model):
    _name = 'sexual.history'

    name = fields.Char(string='Nombre')


class MinsaContraceptiveMethodLine(models.Model):
    _name = 'minsa.contraceptive.method.line'

    evaluation_id = fields.Many2one('oeh.medical.evaluation')
    contraceptive_method_id = fields.Many2one(
        'contraceptive.method', u'Métodos anticonceptivo')
    state = fields.Boolean('Estado')
    start_date = fields.Date('Fecha de inicio')
    end_date = fields.Date('Fecha final')
    observation = fields.Text('Observaciones')


class ContraceptiveMethod(models.Model):
    _name = 'contraceptive.method'
    name = fields.Char(string='Nombre')


class UsualMedication(models.Model):
    _name = 'usual.medication'

    SELECTION_MEDICAMENT_TYPE = [
        ('Medicine', 'Medicine'),
        ('Vaccine', 'Vaccine'),
    ]

    evaluation_id = fields.Many2one('oeh.medical.evaluation')
    medicament_id = fields.Many2one('product.template', 'Medicamentos')
    category_id = fields.Many2one(
        'product.category', 'Familia de medicamento', required=True,
        domain=lambda self: self.filter_categories())
    medicament_type = fields.Selection(SELECTION_MEDICAMENT_TYPE, 'Familia de medicamentos')
    dose = fields.Integer('Dosis')
    frequency = fields.Integer('Frecuencia (hrs)')
    date_init = fields.Date('Fecha de inicio')
    family_id = fields.Integer('Family Id')

    def filter_categories(self):
        med_category_id = self.env['ir.config_parameter'].get_param('medicament_category_id')
        try:
            med_category_id = int(med_category_id)
        except Exception:
            raise ValidationError('Error en el parámetor del sistema "medicament_category_id"')

        med_all_id = self.env['ir.config_parameter'].get_param('medicament_all_id')
        try:
            med_all_id = int(med_all_id)
        except Exception:
            raise ValidationError('Error en el parámetor del sistema "medicament_all_id"')

        domain = [
            '|',
            ('parent_id', '=', med_category_id),
            ('id', 'in', (med_all_id, med_category_id))]
        return domain

    @api.multi
    def onchange_medicament_id(self, medicament_id=False):
        result = {}
        if medicament_id:
            model_product_template = self.env['product.template']
            product_template = model_product_template.search([('id', '=', medicament_id)], limit=1)
            if product_template:
                result = {'category_id': product_template.categ_id.id}
        return {'value': result}

    @api.multi
    def onchange_category_id(self, category_id=False):
        """
        Calcula un dominio.

        return: {'domain': {...}}

        """
        tuple_domain_medicacion_habitual = ('es_medicacion_habitual', '=', True)
        tuple_domain_category = ('categ_id', '=', category_id)
        tuple_domain_type = ('medicament_type', '=', MEDICAMENT_TYPE)
        domain = [tuple_domain_medicacion_habitual, tuple_domain_type]
        if category_id:
            product_template_model = self.env['product.template']
            product_template = product_template_model.search([tuple_domain_category], limit=1)
            domain = [tuple_domain_medicacion_habitual, tuple_domain_category, tuple_domain_type]
            if product_template and product_template.categ_id.name and product_template.categ_id.name.upper() == 'TODOS':
                domain = [tuple_domain_medicacion_habitual, tuple_domain_type]
        return {'domain': {'medicament_id': domain}}


class HarmfulHabitsLine(models.Model):
    _name = 'harmful.habits.line'

    evaluation_id = fields.Many2one('oeh.medical.evaluation')
    habits_id = fields.Many2one(
        'habits', u'Hábitos',
        domain=[('harmful', '=', True)])
    state = fields.Boolean('Estado')
    qty = fields.Integer('Cantidad')
    frequency = fields.Selection(SELECTION_FREQUENCY, 'Frecuencia (veces a la)')
    age_consumption = fields.Integer('Edad inicio consumo')


class GeneralHabitsLine(models.Model):
    _name = 'general.habits.line'

    evaluation_id = fields.Many2one('oeh.medical.evaluation')
    habits_id = fields.Many2one(
        'habits', u'Hábitos',
        domain=[('harmful', '=', True)])
    state = fields.Boolean('Estado')
    qty = fields.Integer('Cantidad (hrs)')
    frequency = fields.Selection(SELECTION_FREQUENCY, 'Frecuencia (veces a la)')
    observation = fields.Text('Observaciones')


class Habits(models.Model):
    _name = 'habits'
    name = fields.Char(string='Nombre')
    harmful = fields.Boolean(string='Es nocivo?')


class OehealthRefcon(models.Model):
    _name = 'oehealth.refcon'

    code = fields.Char()
    sync = fields.Boolean()
    code_patient = fields.Selection(
        selection=[('stable', 'Estable'), ('wrong', 'Mal Estado'), ('serius', 'Grave')])
    institution_origin = fields.Many2one('oeh.medical.health.center')
    institution_destination = fields.Many2one('oeh.medical.health.center')
    service_origin = fields.Many2one('product.category')
    service_destination = fields.Many2one('product.category')
    specialty = fields.Many2one('oeh.medical.speciality')
    person = fields.Char()
    type_transport = fields.Selection(
        selection=[('none', 'Ninguno'),
                   ('air', 'Aereo'),
                   ('fluvial', 'Fluvial'),
                   ('maritime', 'Maritimo'),
                   ('terra', 'Terrestre')])
    motive_reference = fields.Selection(
        selection=[('none', 'No Capacidad resolutiva (por el nivel del EESS)'),
                   ('specialty', 'No capacidad resolutiva por carecer de determinado especialista'),
                   ('insumo', 'No capacidad resolutiva por carecer de determinado insumo'),
                   ('operative', 'No capacidad resolutiva por no contar con determinado servicio operativo'),
                   ('reparation', 'No capacidad resolutiva por servicio en reparación'),
                   ('saturated', 'No capacidad resolutiva por servicio saturado'),
                   ('essalud', 'Por ser titular de ESSALUD'),
                   ('team', 'No capacidad resolutiva por carecer de determinado equipo'),
                   ('infraestructure', 'No capacidad resolutiva por carecer de determinada infraestructura')])
    observacion_reference = fields.Char()


class OeHealthAppointment(models.Model):
    _inherit = 'oeh.medical.appointment'

    evaluation_ids = fields.One2many('oeh.medical.evaluation', 'appointment', string='Evaluation', readonly=True,
                                     states={'Invoiced': [('readonly', False)]})


class OeHealthPatientEvaluationTriage(models.Model):
    _name = 'oeh.medical.evaluation.triage'
    _rec_name = 'patient_id'

    PRIORITY_I = 'i'
    PRIORITY_II = 'ii'
    PRIORITY_III = 'iii'
    PRIORITY_IV = 'iv'

    PRIORITIES = [
        (PRIORITY_I, 'I'),
        (PRIORITY_II, 'II'),
        (PRIORITY_III, 'III'),
        (PRIORITY_IV, 'IV'),
    ]

    # Datos del paciente
    patient_id = fields.Many2one(
        'oeh.medical.patient', string='Paciente')
    patient_age_years_int = fields.Integer(related='patient_id.age_years_int', readonly=True)
    patient_age_months_int = fields.Integer(related='patient_id.age_months_int', readonly=True)
    image = fields.Binary(related='patient_id.image')
    image_medium = fields.Binary(related='patient_id.image_medium')
    age_patient = fields.Char(related='patient_id.age', readonly=True)
    sex_patient = fields.Selection(related='patient_id.sex', readonly=True)
    date_birth_patient = fields.Date(related='patient_id.dob', readonly=True)
    sis_tipo_seguro_descripcion = fields.Char(
        related='patient_id.sis_tipo_seguro_descripcion')
    sis_estado = fields.Char(related='patient_id.sis_estado', readonly=True)
    a_state_id = fields.Many2one(related='patient_id.a_state_id', readonly=True)
    a_province_id = fields.Many2one(related='patient_id.a_province_id', readonly=True)
    a_district_id = fields.Many2one(related='patient_id.a_district_id', readonly=True)
    patient_family_id = fields.Many2one(related='patient_id.patient_family_id', readonly=True)
    sex_patient_family = fields.Selection(
        related='patient_family_id.name.sex', readonly=True)
    date_triage = fields.Date(string='Fecha triaje', default=fields.Date.context_today)

    # Signos Vitales(sv) y Datos Antropometricos(da)
    sv_temperatura = fields.Float('Temperatura(C°)')
    sv_presionarterial = fields.Char('Presión Arterial')
    sv_freccardiaca = fields.Char('Forma Cardiaca', size=3)
    sv_frecrespiratoria = fields.Char('Frec. Respiratoria', size=3)
    sv_saturacion = fields.Char('Saturación', size=3)
    da_peso_g = fields.Float('Peso(Gramos)')
    da_talla_cm = fields.Float('Talla(Centímetros)')
    da_peso_kg = fields.Float('Peso(Kg)')
    da_talla_m = fields.Float('Talla(Metros)')
    da_perimetrocefalico = fields.Float(u'Perímetro cefálico')
    da_perimetroabdominal = fields.Float(u'Perímetro abdominal')
    da_imc = fields.Float('IMC(Kg/m2)', compute='_compute_imc_ac')
    da_estado_imc = fields.Char('Estado IMC)', size=30)
    da_riesgodeenfermedad = fields.Char('Riesgo de enfermedad', compute='_compute_da_riesgodeenfermedad', store=True)
    da_sc = fields.Float('Superfice corporal', compute='_compute_da_sc', store=True)
    da_imc = fields.Float(compute='_compute_da_imc', store=True)
    da_clasificacionimc = fields.Char(u'Clasificación IMC', compute='_compute_da_clasificacionimc', store=True)
    da_clasificaciontalla = fields.Char(u'Clasificación talla', compute='_compute_da_clasificaciontalla', store=True)
    state = fields.Selection(STATES, 'Estado', readonly=True, default=lambda *e: 'pendiente')

    # Cita
    appointment_id = fields.Many2one('oeh.medical.appointment', string='Cita')

    is_emergency = fields.Boolean('¿Es triaje de emergencia?')
    priority = fields.Selection(PRIORITIES, 'Prioridad')
    service_destination_id = fields.Many2one('product.category', string='Servicio destino')
    emergency_id = fields.Integer('ID Emergencia')
    name = fields.Char(u'Código de triaje', size=64, readonly=True, required=True, default=lambda *a: '/')

    @api.multi
    def go_to_admission_form(self):
        self.ensure_one()
        return {
            'string': u'Admisión de emergencia',
            'name': u'Admisión de emergencia',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': False,
            'res_model': 'oeh.medical.emergency',
            'domain': [],
            'context': {
                'default_patient_id': self.patient_id.id,
                'default_triage_id': self.id,
                'default_is_emergency': True,
            },
            'target': 'online',
            'type': 'ir.actions.act_window',
            'res_id': self.emergency_id,
        }

    @api.one
    def set_to_triad(self):
        self.state = STATE_TRIAD
        vals = {'patient_id': self.patient_id.id,
                'state': STATE_TRIAD,
                'triage_id': self.id,
                }
        res = self.env['oeh.medical.emergency'].create(vals)
        self.emergency_id = res.id
        if not self.is_emergency:
            res.appointment_id.write({'triage_id': res.id, 'state': STATE_TRIAD})
        return res

    @api.constrains('sv_temperatura')
    def _check_sv_temperatura(self):
        for record in self:
            if record.sv_temperatura and record.sv_temperatura < 1:
                raise ValidationError('La temperatura debe ser mayor que cero (0)')

    @api.constrains('da_peso_g', 'da_peso_kg')
    def _check_da_peso_g(self):
        for record in self:
            if not record.da_peso_kg and record.da_peso_g < 1:
                raise ValidationError('El peso debe ser mayor que cero (0) gramos')

    @api.constrains('da_peso_kg', 'da_peso_g')
    def _check_da_pego_kg(self):
        for record in self:
            if not record.da_peso_g and record.da_peso_kg < 1:
                raise ValidationError('El peso debe ser mayor que cero (0) Kilogramos')

    @api.constrains('da_talla_cm', 'da_talla_m')
    def _check_da_talla_cm(self):
        for record in self:
            if not record.da_talla_m and record.da_talla_cm < 1:
                raise ValidationError(u'La talla debe ser mayor que cero (0) centímetros')

    @api.constrains('da_talla_m', 'da_talla_cm')
    def _check_da_talla_m(self):
        for record in self:
            if not record.da_talla_cm and record.da_talla_m and record.da_talla_m < 0.5:
                raise ValidationError('La talla debe ser mayor o igual que cero punto cinco (0.5) metros')

    @api.constrains('da_perimetroabdominal')
    def _check_da_perimetroabdominal(self):
        for record in self:
            if record.patient_age_years_int >= 12 and 30 > record.da_perimetroabdominal > 300:
                raise ValidationError('El perímetro abdominal debe ser entre 30 y 300 cm.')

    @api.constrains('da_perimetrocefalico', 'patient_age_years_int')
    def _check_perimetrocefalico(self):
        for record in self:
            if self.patient_age_years_int == 0 and record.da_perimetrocefalico < 1:
                raise ValidationError(u'El perimetro cefálico debe ser mayor que cero (0)')

    @api.depends('da_perimetroabdominal', 'sex_patient', 'patient_age_years_int')
    def _compute_da_riesgodeenfermedad(self):
        for record in self:
            if not record.da_perimetroabdominal:
                continue

            domain = [('age', '=', record.patient_age_years_int),
                      ('gender', '=', int(record.sex_patient))]
            edad = record.env['oeh.medical.evaluation.riesgoenfermedad1217'].search(domain, limit=1)

            if not edad:
                continue

            if record.da_perimetroabdominal < edad.rsm:
                riesgo = RIESGO_DE_ENFEMERDAD_BAJO
            elif edad.rsm <= record.da_perimetroabdominal < edad.rma:
                riesgo = RIESGO_DE_ENFEMERDAD_ALTO
            else:
                riesgo = RIESGO_DE_ENFEMERDAD_MUY_ALTO

            record.da_riesgodeenfermedad = riesgo

    @api.depends('da_imc', 'sex_patient', 'patient_age_months_int')
    def _compute_da_clasificacionimc(self):
        for record in self:
            if not record.da_imc:
                continue

            domain = [('month', '=', record.patient_age_months_int),
                      ('gender', '=', int(record.sex_patient))]
            month = record.env['oeh.medical.evaluation.imc517'].search(domain, limit=1)

            if not month:
                continue

            if record.da_imc < month.f__3:
                resultado = IMC_DELGADEZ_SEVERA
            elif month.f__3 <= record.da_imc < month.f__2:
                resultado = IMC_DELGADEZ
            elif month.f__2 <= record.da_imc < month.f_1:
                resultado = IMC_NORMAL
            elif month.f_1 <= record.da_imc < month.f_2:
                resultado = IMC_SOBREPESO
            else:
                resultado = IMC_OBESIDAD

            record.da_clasificacionimc = resultado

    @api.depends('da_talla_m', 'sex_patient', 'patient_age_months_int')
    def _compute_da_clasificaciontalla(self):
        for record in self:
            if not record.da_talla_m:
                continue

            domain = [('month', '=', record.patient_age_months_int),
                      ('gender', '=', int(record.sex_patient))]
            month = record.env['oeh.medical.evaluation.talla517'].search(domain, limit=1)
            talla_cm = record.da_talla_m * 100

            if not month:
                continue

            if talla_cm < month.f__3:
                resultado = TALLA_BAJA_SEVERA
            elif month.f__3 <= talla_cm < month.f__2:
                resultado = TALLA_BAJA
            elif month.f__2 <= talla_cm < month.f_2:
                resultado = TALLA_NORMAL
            else:
                resultado = TALLA_ALTA

            record.da_clasificaciontalla = resultado

    @api.depends('da_peso_kg', 'da_talla_m')
    def _compute_da_imc(self):
        for record in self:
            check = record.da_peso_kg and record.da_talla_m
            imc = check and record.da_peso_kg / (record.da_talla_m ** 2)
            record.da_imc = round(imc, 2)

    @api.depends('da_peso_g', 'da_peso_kg')
    def _compute_da_sc(self):
        for record in self:
            if record.da_peso_g:
                sc = (record.da_peso_g * 4 + 7) / (record.da_peso_g + 90)
                record.da_sc = round(sc, 2)
            if record.da_peso_kg:
                sc = (record.da_peso_kg * 4 + 7) / (record.da_peso_kg + 90)
                record.da_sc = round(sc, 2)

    @api.model
    def create(self, vals):
        sequence = self.env['ir.sequence'].next_by_code('oeh.medical.evaluation.triage')
        vals['name'] = sequence
        res = super(OeHealthPatientEvaluationTriage, self).create(vals)
        if not self.is_emergency:
            res.appointment_id.write({'triage_id': res.id, 'state': 'Triaded'})
        return res

    @api.depends('da_peso_kg', 'da_talla_m')
    def _compute_imc_ac(self):
        for record in self:
            check = record.da_peso_kg and record.da_talla_m
            imc = check and record.da_peso_kg / (record.da_talla_m ** 2)
            record.da_imc = round(imc, 2)


class Imc517(models.Model):
    _name = 'oeh.medical.evaluation.imc517'
    _description = u'IMC hombre - mujer de 5 a 17 años'

    month = fields.Integer('Month')
    f__3 = fields.Float('-3')
    f__2 = fields.Float('-2')
    f_1 = fields.Float('1')
    f_2 = fields.Float('2')
    gender = fields.Selection(GENDER, 'Sexo')


class Talla517(models.Model):
    _name = 'oeh.medical.evaluation.talla517'
    _description = u'Talla hombre - mujer de 5 a 17 años'

    month = fields.Integer('Month')
    f__3 = fields.Float('-3')
    f__2 = fields.Float('-2')
    f_2 = fields.Float('2')
    gender = fields.Selection(GENDER, 'Sexo')


class Riesgoenfermedad1217(models.Model):
    _name = 'oeh.medical.evaluation.riesgoenfermedad1217'
    _description = u'Riesgo de enfermedad hombre - mujer de 12 a 17 años'

    age = fields.Integer('Edad')
    rsm = fields.Float('RSM')
    rsa = fields.Float('RSA')
    rma = fields.Float('RMA')
    gender = fields.Selection(GENDER, 'Sexo')
