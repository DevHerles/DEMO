# coding=utf-8
"""
Constantes para proyecto HCEXEV.

Copyright (C) 2017 MINSA.

Authors:
    Carlos Joel Delgado Pizarro <cdelgado@minsa.gob.pe>
"""
NINGUNA_NOAPLICA = '0'
TIPO_DOCUMENTO_DNI = '01'
TDOC_CHOICES = (
    ('00', 'NO SE CONOCE'),
    ('01', 'DNI/LE'),
    ('02', 'LM/BO'),
    ('03', 'CARNET DE EXTRAJERIA'),
    ('04', 'ACTA DE NACIMIENTO'),
    ('06', 'PASAPORTE'),
    ('07', 'DI DEL EXTRANJERO'),
)

SEXO_CHOICES = (
    ('1', 'Masculino'),
    ('2', 'Femenino'),
)

CONSULTA_ESTADO_PENDIENTE = '1'
CONSULTA_ESTADO_ATENDIENDO = '2'
CONSULTA_ESTADO_ATENDIDO = '3'
CONSULTA_ESTADO_CHOICES = (
    (CONSULTA_ESTADO_PENDIENTE, 'Pendiente'),
    (CONSULTA_ESTADO_ATENDIENDO, 'Atendiendo'),
    (CONSULTA_ESTADO_ATENDIDO, 'Atendido'),
)

TIEMPO_ENFERMEDAD_CHOICES = (
    ('1', 'Horas'),
    ('2', 'Días'),
    ('3', 'Semanas'),
    ('4', 'Meses'),
    ('5', 'Años'),
)

GESTANTE = '1'
PUERPERA = '2'
GESTANTE_PUERPERA_CHOICES = (
    (GESTANTE, 'Gestante'),
    (PUERPERA, 'Puerpera'),
)

TANNER_MAMA_CHOICES = (
    ('1', 'Tanner I - Sin tejido glandular; la areola sigue los contornos de la piel del tórax. '
          'Edad normalmente de 10 años o menor.'),
    ('2', 'Tanner II - Botón mamario, con una pequeña zona de tejido circundante glandular; la areola comienza a '
          'ensancharse. Edad entre 10 y 11,5 años.'),
    ('3', 'Tanner III - La mama comienza a elevarse, y se extiende más allá de los límites de la areola, '
          'que continua aumentando, pero permanece dentro del contorno mamario. Edad entre 11,5 y 13 años.'),
    ('4', 'Tanner IV - Elevación y aumento de tamaño de los senos; '
          'areola y pezón forman un montículo secundario que sobresale del reborde de la mama. '
          'Edad entre 13 y 15 años.'),
    ('5', 'Tanner V - La mama alcanza su tamaño definitivo de adulto; la areola vuelve al nivel de la '
          'superficie mamaria, pero el pezón sigue haciendo prominencia. Edad 15 años o mayor.'),
)

TANNER_VELLO_PUBICO_CHOICES = (
    ('1', 'Tanner I - Sin vello púbico. Edad de 10 años o menor.'),
    ('2', 'Tanner II - Pequeña cantidad de vello largo y aterciopelado con una ligera pigmentación en la base del pene'
          ' y el escroto (hombres) o en los labios mayores (mujeres). Edad entre 10 y 11,5 años.'),
    ('3', 'Tanner III - El vello se vuelve más grueso y rizado, y comienza a extenderse lateralmente. '
          'Edad entre 11,5 y 13 años.'),
    ('4', 'Tanner IV - Las características del vello son similares a las del adulto; '
          'se extiende a través del pubis pero no alcanza los muslos. Edad entre los 13 y los 15 años.'),
    ('5', 'Tanner V - El vello se extiende por la superficie medial de los muslos. Edad 15 años o mayor.'),
)

TANNER_GENITALES_CHOICES = (
    ('1', 'Tanner I - Volumen testicular menor de 1,5 ml. Pene pequeño, de 3 cm o menos.'),
    ('2', 'Tanner II - Volumen testicular entre 1,6 y 6 ml. La piel del escroto se adelgaza, se enrojece y se agranda.'
          ' La longitud del pene sin cambios.'),
    ('3', 'Tanner III - Volumen testicular entre 6 y 12 ml. El escroto se agranda aún más. '
          'El pene comienza a alargarse hasta aproximadamente los 6 cm.'),
    ('4', 'Tanner IV - Volumen testicular de entre 12 y 20 ml. El escroto se agranda más y se oscurece. '
          'El pene incrementa su longitud hasta los 10 cm, y hay diferenciación del glande.'),
    ('5', 'Tanner V - Volumen testicular mayor de 20 ml. Escroto y pene de adulto, de unos 15 cm de longitud.'),
)

EXAMEN_REGIONAL_CHOICES = (
    ('1', 'Conservado'),
    ('2', 'Patológico'),
)

EXAMEN_MENTAL_CONCIENCIA_CHOICES = (
    ('1', 'Lúcido'),
    ('2', 'Obnubilado'),
    ('3', 'Confundido'),
)

HIDRATADO = 'hidratado'
DESHIDRATADO = 'deshidratado'
SOBREHIDRATADO = 'sobrehidratado'

ESTADO_DE_HIDRATACION_CHOICES = (
    (HIDRATADO, 'Hidratado'),
    (DESHIDRATADO, 'Deshidratado'),
    (SOBREHIDRATADO, 'Sobrehidratado'),
)

LUCIDO = 'lucido'
OBNUBILADO = 'obnulado'
CONFUNDIDO = 'confundido'
SOMNOLIENTO = 'somnoliento'

ESTADO_DE_CONCIENCIA_CHOICES = (
    (LUCIDO, 'Lúcido'),
    (OBNUBILADO, 'Obnubilado'),
    (CONFUNDIDO, 'Confundido'),
    (SOMNOLIENTO, 'Somnoliento'),
)

EXAMEN_MENTAL_ORIENTACION_PERSONA = '1'
EXAMEN_MENTAL_ORIENTACION_ESPACIO = '2'
EXAMEN_MENTAL_ORIENTACION_TIEMPO = '3'
EXAMEN_MENTAL_ORIENTACION_CHOICES = (
    (EXAMEN_MENTAL_ORIENTACION_PERSONA, 'Persona'),
    (EXAMEN_MENTAL_ORIENTACION_ESPACIO, 'Espacio'),
    (EXAMEN_MENTAL_ORIENTACION_TIEMPO, 'Tiempo'),
)

EXAMEN_MENTAL_ATENCION_CHOICES = (
    ('1', 'Conservada'),
    ('2', 'Distraibilidad'),
)

EXAMEN_MENTAL_ANIMO_CHOICES = (
    ('1', 'Eutímico'),
    ('2', 'Hipertímico'),
    ('3', 'Hipotímico'),
)

EXAMEN_MENTAL_LENGUAJE_CHOICES = (
    ('1', 'Normal'),
    ('2', 'Tartamudeo'),
    ('3', 'Disartrias'),
    ('4', 'Dislalias'),
)

EXAMEN_MENTAL_PENSAMIENTO_CURSO = '1'
EXAMEN_MENTAL_PENSAMIENTO_FORMA = '2'
EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO = '3'
EXAMEN_MENTAL_PENSAMIENTO_1_CHOICES = (
    (EXAMEN_MENTAL_PENSAMIENTO_CURSO, 'Curso'),
    (EXAMEN_MENTAL_PENSAMIENTO_FORMA, 'Forma'),
    (EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO, 'Contenido'),
)

EXAMEN_MENTAL_PENSAMIENTO_CURSO_NORMAL = '1'
EXAMEN_MENTAL_PENSAMIENTO_CURSO_RAPIDO = '2'
EXAMEN_MENTAL_PENSAMIENTO_CURSO_LENTO = '3'
EXAMEN_MENTAL_PENSAMIENTO_CURSO_CHOICES = (
    (EXAMEN_MENTAL_PENSAMIENTO_CURSO_NORMAL, 'Normal'),
    (EXAMEN_MENTAL_PENSAMIENTO_CURSO_RAPIDO, 'Rápido'),
    (EXAMEN_MENTAL_PENSAMIENTO_CURSO_LENTO, 'Lento'),
)

EXAMEN_MENTAL_PENSAMIENTO_FORMA_ENTENDIBLE = '1'
EXAMEN_MENTAL_PENSAMIENTO_FORMA_NOENTENDIBLE = '2'
EXAMEN_MENTAL_PENSAMIENTO_FORMA_CHOICES = (
    (EXAMEN_MENTAL_PENSAMIENTO_FORMA_ENTENDIBLE, 'Entendible'),
    (EXAMEN_MENTAL_PENSAMIENTO_FORMA_NOENTENDIBLE, 'No entendible'),
)

EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_IDEAS_CULPA = '1'
EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_DESESPERANZA = '2'
EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_IDEAS_MINUSVALIA = '3'
EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_IDEAS_DELIRANTES = '4'
EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_IDEAS_SUICIDAS = '5'
EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_IDEAS_SOBREVALORADAS = '6'
EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_OBSECIONES = '7'
EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_COMPULSIONES = '8'
EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_FOBIAS = '9'
EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_CHOICES = (
    (EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_IDEAS_CULPA, 'Ideas de culpa'),
    (EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_DESESPERANZA, 'Desesperanza'),
    (EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_IDEAS_MINUSVALIA, 'Ideas de minusvalía'),
    (EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_IDEAS_DELIRANTES, 'Ideas delirantes'),
    (EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_IDEAS_SUICIDAS, 'Ideas suicidas'),
    (EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_IDEAS_SOBREVALORADAS, 'Ideas sobrevaloradas'),
    (EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_OBSECIONES, 'Obsesiones'),
    (EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_COMPULSIONES, 'Compulsiones'),
    (EXAMEN_MENTAL_PENSAMIENTO_CONTENIDO_FOBIAS, 'Fobias'),
)

EXAMEN_MENTAL_MEMORIA_CHOICES = (
    ('1', 'Conservada'),
    ('2', 'Olvidos frecuentes'),
    ('3', 'Amnesia'),
)

EXAMEN_MENTAL_SENSOPERCEPCION_CHOICES = (
    ('1', 'Alucinaciones'),
)

DIAGNOSTICO_CHOICES = (
    ('P', 'Presuntivo'),
    ('D', 'Definitivo'),
    ('R', 'Repetido'),
)

CONDICION_PACIENTE_CHOICES = (
    ('E', 'Estable'),
    ('M', 'Mal estado'),
    ('G', 'Grave'),
)

TIPO_TRANSPORTE_CHOICES = (
    ('A', 'Aereo'),
    ('F', 'Fluvial'),
    ('M', 'Marítimo'),
    ('T', 'Terrestre'),
)

MOTIVO_REFERENCIA_CHOICES = (
    ('1', 'No capacidad resolutiva (por el nivel del EESS)'),
    ('2', 'No capacidad resolutiva por carecer de determinado especialista'),
    ('3', 'No capacidad resolutiva por carecer de determinado insumo'),
    ('4', 'No capacidad resolutiva por no contar con determinado servicio operativo'),
    ('5', 'No capacidad resolutiva por servicio en reparación'),
    ('6', 'No capacidad resolutiva por servicio saturado'),
    ('7', 'Por ser titular ESSALUD'),
    ('8', 'No capacidad resolutiva por carecer de determinado equipo'),
    ('9', 'No capacidad resolutiva por carecer de determinado infraestructura'),
)

TIPO_PLAN_CONSULTAEXTERNA_LABORATORIO = 'L'
TIPO_PLAN_CONSULTAEXTERNA_IMAGENES = 'I'
TIPO_PLAN_CONSULTAEXTERNA_PROCEDIMIENTO = 'P'
TIPO_PLAN_CONSULTAEXTERNA_CHOICES = (
    (TIPO_PLAN_CONSULTAEXTERNA_IMAGENES, 'Imagenes'),
    (TIPO_PLAN_CONSULTAEXTERNA_LABORATORIO, 'Laboratorio'),
    (TIPO_PLAN_CONSULTAEXTERNA_PROCEDIMIENTO, 'Procedimiento'),
)

ESTADO_EXAMEN_AUXILIAR_PENDIENTE = '0'
ESTADO_EXAMEN_AUXILIAR_RESULTADO = '1'
ESTADO_EXAMEN_AUXILIAR_CHOICES = (
    (ESTADO_EXAMEN_AUXILIAR_PENDIENTE, 'Pendiente'),
    (ESTADO_EXAMEN_AUXILIAR_RESULTADO, 'Con resultado'),
)

ID_FINANCIADOR_USUARIO = '1'  # Codigo de seguro autofinanciado por usuario, para envio a REFCON

ID_FINANCIADOR_SIS = '2'  # Código del financiador tipo SIS

CPT_TIPO_LABORATORIO = 'Laboratorio'  # Valor para realizar consulta a modelo de Odoo

CPT_TIPO_IMAGENES = 'Imagenes'  # Valor para realizar consulta a modelo de Odoo

CPT_TIPO_PROCEDIMIENTO = 'CPT'  # Valor para realizar consulta a modelo de Odoo

TAMIZAJE_CHOICES = (
    ('2', 'Normal'),
    ('1', 'Patológico'),
)

VIA_ADMINISTRACION_ORAL = '1'
VIA_ADMINISTRACION_TOPICA = '2'
VIA_ADMINISTRACION_INTRAMUSCULAR = '3'
VIA_ADMINISTRACION_ENDOVENOSO = '4'
VIA_ADMINISTRACION_SUBCUTANEO = '5'
VIA_ADMINISTRACION_SUBLINGUAL = '6'
VIA_ADMINISTRACION_TRANSDERMICA = '7'
VIA_ADMINISTRACION_OFTALMICA = '8'
VIA_ADMINISTRACION_OTICA = '9'
VIA_ADMINISTRACION_INTRANASAL = '10'
VIA_ADMINISTRACION_INHALATORIA = '11'
VIA_ADMINISTRACION_RECTAL = '12'
VIA_ADMINISTRACION_VAGINAL = '13'
VIA_ADMINISTRACION_OTRAS = '14'
VIA_ADMINISTRACION_CHOICES = (
    (VIA_ADMINISTRACION_ORAL, 'Oral'),
    (VIA_ADMINISTRACION_TOPICA, 'Tópica'),
    (VIA_ADMINISTRACION_INTRAMUSCULAR, 'Intramuscular (IM)'),
    (VIA_ADMINISTRACION_ENDOVENOSO, 'Endovenoso (EV)'),
    (VIA_ADMINISTRACION_SUBCUTANEO, 'Subcutáneo (SC)'),
    (VIA_ADMINISTRACION_SUBLINGUAL, 'Sublingual'),
    (VIA_ADMINISTRACION_TRANSDERMICA, 'Transdermica'),
    (VIA_ADMINISTRACION_OFTALMICA, 'Oftálmica'),
    (VIA_ADMINISTRACION_OTICA, 'Ótica'),
    (VIA_ADMINISTRACION_INTRANASAL, 'Intranasal'),
    (VIA_ADMINISTRACION_INHALATORIA, 'Inhalatoria'),
    (VIA_ADMINISTRACION_RECTAL, 'Rectal'),
    (VIA_ADMINISTRACION_VAGINAL, 'Vaginal'),
    (VIA_ADMINISTRACION_OTRAS, 'Otras vias parenterales'),
)

GRUPO_ANTECEDENTES_PERSONALES = '1'
GRUPO_ANTECEDENTES_FAMILIARES = '2'
GRUPO_ANTECEDENTES_CHOICES = (
    (GRUPO_ANTECEDENTES_PERSONALES, 'Antecedentes personales'),
    (GRUPO_ANTECEDENTES_FAMILIARES, 'Antecedentes familiares')
)

SUBGRUPO_ANTECEDENTES_PATOLOGICOS = '1'
SUBGRUPO_ANTECEDENTES_LESIONES = '2'
SUBGRUPO_ANTECEDENTES_CANCER = '3'
SUBGRUPO_ANTECEDENTES_MENTAL = '4'
SUBGRUPO_ANTECEDENTES_CHOICES = (
    (SUBGRUPO_ANTECEDENTES_PATOLOGICOS, 'Patológicos'),
    (SUBGRUPO_ANTECEDENTES_LESIONES, 'Lesiones premalignas'),
    (SUBGRUPO_ANTECEDENTES_CANCER, 'Cáncer'),
    (SUBGRUPO_ANTECEDENTES_MENTAL, 'Salud mental'),
)

SI_NO_NOSABE_NO = '0'
SI_NO_NOSABE_SI = '1'
SI_NO_NOSABE_NOSABE = '2'
SI_NO_NOSABE_CHOICES = (
    (SI_NO_NOSABE_SI, 'Sí'),
    (SI_NO_NOSABE_NO, 'No'),
    (SI_NO_NOSABE_NOSABE, 'No sabe'),
)

ANTECEDENTES_PARENTESCO_PADRE = '1'
ANTECEDENTES_PARENTESCO_MADRE = '2'
ANTECEDENTES_PARENTESCO_HERMANOS = '3'
ANTECEDENTES_PARENTESCO_OTROS = '4'
ANTECEDENTES_PARENTESCO_CHOICES = (
    (ANTECEDENTES_PARENTESCO_PADRE, 'Padre'),
    (ANTECEDENTES_PARENTESCO_MADRE, 'Madre'),
    (ANTECEDENTES_PARENTESCO_HERMANOS, 'Hermanos'),
    (ANTECEDENTES_PARENTESCO_OTROS, 'Otros'),
)

FRECUENCIA_HABITO_DIA = '1'
FRECUENCIA_HABITO_SEMANA = '2'
FRECUENCIA_HABITO_MES = '3'
FRECUENCIA_HABITO_ANIO = '4'
FRECUENCIA_HABITO_CHOICES = (
    (FRECUENCIA_HABITO_DIA, 'Día'),
    (FRECUENCIA_HABITO_SEMANA, 'Semana'),
    (FRECUENCIA_HABITO_MES, 'Mes'),
    (FRECUENCIA_HABITO_ANIO, 'Año'),
)

ACTIVIDAD_FISICA_MODERADA = '1'
ACTIVIDAD_FISICA_INTENSA = '2'
ACTIVIDAD_FISICA_INTENSIDAD_CHOICES = (
    (ACTIVIDAD_FISICA_INTENSA, 'Intensa'),
    (ACTIVIDAD_FISICA_MODERADA, 'Moderada'),
)

COMPOSICION_FAMILIAR_PADRE = '1'
COMPOSICION_FAMILIAR_MADRE = '2'
COMPOSICION_FAMILIAR_HIJOS = '3'
COMPOSICION_FAMILIAR_ABUELOS = '4'
COMPOSICION_FAMILIAR_PAREJA = '5'
COMPOSICION_FAMILIAR_CHOICES = (
    (COMPOSICION_FAMILIAR_PADRE, 'Padre'),
    (COMPOSICION_FAMILIAR_MADRE, 'Madre'),
    (COMPOSICION_FAMILIAR_HIJOS, 'Hijos'),
    (COMPOSICION_FAMILIAR_ABUELOS, 'Abuelos'),
    (COMPOSICION_FAMILIAR_PAREJA, 'Pareja'),
)

COMPOSICION_FAMILIAR_CHOICES_DICT = {
    COMPOSICION_FAMILIAR_PADRE: 'Padre',
    COMPOSICION_FAMILIAR_MADRE: 'Madre',
    COMPOSICION_FAMILIAR_HIJOS: 'Hijos',
    COMPOSICION_FAMILIAR_ABUELOS: 'Abuelos',
    COMPOSICION_FAMILIAR_PAREJA: 'Pareja',
}

PERCEPCION_ESTRES_BAJO = '1'
PERCEPCION_ESTRES_MEDIO = '2'
PERCEPCION_ESTRES_ALTO = '3'
PERCEPCION_ESTRES_CHOICES = (
    (PERCEPCION_ESTRES_BAJO, 'Bajo'),
    (PERCEPCION_ESTRES_MEDIO, 'Medio'),
    (PERCEPCION_ESTRES_ALTO, 'Alto'),
)

VIOLENCIA_SEXUAL = '1'
VIOLENCIA_FISICA = '2'
VIOLENCIA_PSICOLOGICA = '3'
VIOLENCIA_NEGLIGENCIA = '4'
VIOLENCIA_ECONOMICA = '5'

VIOLENCIA_CHOICES = (
    (VIOLENCIA_SEXUAL, 'Sexual'),
    (VIOLENCIA_FISICA, 'Física'),
    (VIOLENCIA_PSICOLOGICA, 'Psicológica'),
)
VIOLENCIA_CHOICES_DICT = {
    VIOLENCIA_SEXUAL: 'Sexual',
    VIOLENCIA_FISICA: 'Física',
    VIOLENCIA_PSICOLOGICA: 'Psicológica',
}

VIOLENCIA_FAMILIAR_CHOICES = (
    (VIOLENCIA_SEXUAL, 'Sexual'),
    (VIOLENCIA_FISICA, 'Física'),
    (VIOLENCIA_PSICOLOGICA, 'Psicológica'),
    (VIOLENCIA_NEGLIGENCIA, 'Negligencia'),
    (VIOLENCIA_ECONOMICA, 'Económica'),
)

VIOLENCIA_FAMILIAR_CHOICES_DICT = {
    VIOLENCIA_SEXUAL: 'Sexual',
    VIOLENCIA_FISICA: 'Física',
    VIOLENCIA_PSICOLOGICA: 'Psicológica',
    VIOLENCIA_NEGLIGENCIA: 'Negligencia',
    VIOLENCIA_ECONOMICA: 'Económica',
}

GRADO_DE_ESTUDIO_SIN_INSTRUCCION = '1'
GRADO_DE_ESTUDIO_INICIAL = '2'
GRADO_DE_ESTUDIO_ESPECIAL_INCOMPLETA = '3'
GRADO_DE_ESTUDIO_ESPECIAL_COMPLETA = '4'
GRADO_DE_ESTUDIO_PRIMARIA_INCOMPLETA = '5'
GRADO_DE_ESTUDIO_PRIMARIA_COMPLETA = '6'
GRADO_DE_ESTUDIO_SECUNDARIA_INCOMPLETA = '7'
GRADO_DE_ESTUDIO_SECUNDARIA_COMPLETA = '8'
GRADO_DE_ESTUDIO_SUPERIOR_TECNICA_INCOMPLETA = '9'
GRADO_DE_ESTUDIO_SUPERIOR_TECNICA_COMPLETA = '10'
GRADO_DE_ESTUDIO_SUPERIOR_INSTITUTO_INCOMPLETA = '11'
GRADO_DE_ESTUDIO_SUPERIOR_INSTITUTO_COMPLETA = '12'
GRADO_DE_ESTUDIO_SUPERIOR_UNIVERSITARIA_INCOMPLETA = '13'
GRADO_DE_ESTUDIO_SUPERIOR_UNIVERSITARIA_COMPLETA = '14'
GRADO_DE_ESTUDIO_SUPERIOR_UNIVERSITARIA_EGRESADO = '15'
GRADO_DE_ESTUDIO_BACHILLER = '16'
GRADO_DE_ESTUDIO_TITULADO = '17'
GRADO_DE_ESTUDIO_MAESTRIA_INCOMPLETA = '18'
GRADO_DE_ESTUDIO_MAESTRIA_COMPLETA = '19'
GRADO_DE_ESTUDIO_MAESTRIA_GRADO = '20'
GRADO_DE_ESTUDIO_DOCTORADO_INCOMPLETO = '21'
GRADO_DE_ESTUDIO_DOCTORADO_COMPLETO = '22'
GRADO_DE_ESTUDIO_DOCTORADO_GRADO = '23'
GRADO_DE_ESTUDIO_CHOICES = (
    (GRADO_DE_ESTUDIO_SIN_INSTRUCCION, 'Sin Instrucción'),
    (GRADO_DE_ESTUDIO_INICIAL, 'Inicial'),
    (GRADO_DE_ESTUDIO_ESPECIAL_INCOMPLETA, 'Especial Incompleta'),
    (GRADO_DE_ESTUDIO_ESPECIAL_COMPLETA, 'Especial Completa'),
    (GRADO_DE_ESTUDIO_PRIMARIA_INCOMPLETA, 'Primaria Incompleta'),
    (GRADO_DE_ESTUDIO_PRIMARIA_COMPLETA, 'Primaria Completa'),
    (GRADO_DE_ESTUDIO_SECUNDARIA_INCOMPLETA, 'Secundaria Incompleta'),
    (GRADO_DE_ESTUDIO_SECUNDARIA_COMPLETA, 'Secundaria Completa'),
    (GRADO_DE_ESTUDIO_SUPERIOR_TECNICA_INCOMPLETA, 'Superior Técnica Incompleta'),
    (GRADO_DE_ESTUDIO_SUPERIOR_TECNICA_COMPLETA, 'Superior Técnica Completa'),
    (GRADO_DE_ESTUDIO_SUPERIOR_INSTITUTO_INCOMPLETA, 'Superior (Instituto Superior,etc) Incompleta'),
    (GRADO_DE_ESTUDIO_SUPERIOR_INSTITUTO_COMPLETA, 'Superior (Instituto Superior,etc) Completa'),
    (GRADO_DE_ESTUDIO_SUPERIOR_UNIVERSITARIA_INCOMPLETA, 'Superior Universitaria Incompleta'),
    (GRADO_DE_ESTUDIO_SUPERIOR_UNIVERSITARIA_COMPLETA, 'Superior Universitaria Completa'),
    (GRADO_DE_ESTUDIO_SUPERIOR_UNIVERSITARIA_EGRESADO, 'Superior Universitaria Egresado'),
    (GRADO_DE_ESTUDIO_BACHILLER, 'Grado de Bachller'),
    (GRADO_DE_ESTUDIO_TITULADO, 'Titulado'),
    (GRADO_DE_ESTUDIO_MAESTRIA_INCOMPLETA, 'Maestría Incompleta'),
    (GRADO_DE_ESTUDIO_MAESTRIA_COMPLETA, 'Maestria Completa'),
    (GRADO_DE_ESTUDIO_MAESTRIA_GRADO, 'Grado de Maestría'),
    (GRADO_DE_ESTUDIO_DOCTORADO_INCOMPLETO, 'Doctorado Incompleto'),
    (GRADO_DE_ESTUDIO_DOCTORADO_COMPLETO, 'Doctorado Completo'),
    (GRADO_DE_ESTUDIO_DOCTORADO_GRADO, 'Grado de Doctorado'),
)

FRECUENCIA_CONSUMO_DIA = '1'
FRECUENCIA_CONSUMO_SEMANA = '2'
FRECUENCIA_CONSUMO_QUINCENA = '3'
FRECUENCIA_CONSUMO_MES = '4'
FRECUENCIA_CONSUMO_ANIO = '5'
FRECUENCIA_CONSUMO_CHOICES = (
    (FRECUENCIA_CONSUMO_DIA, 'Día'),
    (FRECUENCIA_CONSUMO_SEMANA, 'Semana'),
    (FRECUENCIA_CONSUMO_QUINCENA, 'Quincena'),
    (FRECUENCIA_CONSUMO_MES, 'Mes'),
    (FRECUENCIA_CONSUMO_ANIO, 'Año'),
)

PERCEPCION_LIBIDO_AUMENTADO = '1'
PERCEPCION_LIBIDO_DISMINUIDO = '2'
PERCEPCION_LIBIDO_CHOICES = (
    (PERCEPCION_LIBIDO_AUMENTADO, 'Aumentado'),
    (PERCEPCION_LIBIDO_DISMINUIDO, 'Disminuido'),
)

TIPO_INSTITUCION_EDUCATIVA_PUBLICA = '1'
TIPO_INSTITUCION_EDUCATIVA_PRIVADA = '2'
TIPO_INSTITUCION_EDUCATIVA_CHOICES = (
    (TIPO_INSTITUCION_EDUCATIVA_PUBLICA, 'Pública'),
    (TIPO_INSTITUCION_EDUCATIVA_PRIVADA, 'Privada'),
)

TIPO_TRABAJO_AGRICULTURA = '01'
TIPO_TRABAJO_EXPLOTACION_MINAS = '02'
TIPO_TRABAJO_INDUSTRIAS_MANUFACTURERAS = '03'
TIPO_TRABAJO_ELECTRICIDAD_GAS_AIRE = '04'
TIPO_TRABAJO_AGUA_EVACUACION_DESECHOS = '05'
TIPO_TRABAJO_CONSTRUCCION = '06'
TIPO_TRABAJO_COMERCIO = '07'
TIPO_TRABAJO_TRANSPORTE_ALMACENAMIENTO = '08'
TIPO_TRABAJO_TRANSPORTE_ALOJAMIENTO_COMIDAS = '09'
TIPO_TRABAJO_INFORMACION_COMUNICACIONES = '10'
TIPO_TRABAJO_FINANCIERAS_SEGUROS = '11'
TIPO_TRABAJO_INMOBILIARIAS = '12'
TIPO_TRABAJO_PROFESIONALES_CIENTIFICAS_TECNICAS = '13'
TIPO_TRABAJO_SERVICIOS_ADMINISTRATIVOS_APOYO = '14'
TIPO_TRABAJO_ADMINISTRACION_PUBLICA = '15'
TIPO_TRABAJO_ENSENANZA = '16'
TIPO_TRABAJO_SALUD_HUMANA_ASISTENCIA_SOCIAL = '17'
TIPO_TRABAJO_ARTISTICAS_ENTRETENIMIENTO = '18'
TIPO_TRABAJO_OTRAS_ACTIVIDADES_SERVICIOS = '18'
TIPO_TRABAJO_ACTIVIDADES_HOGAR = '18'
TIPO_TRABAJO_CHOICES = (
    (TIPO_TRABAJO_AGRICULTURA, 'Agricultura, Ganadería, Silvicultura y Pesca'),
    (TIPO_TRABAJO_EXPLOTACION_MINAS, 'Explotación de Minas y Canteras'),
    (TIPO_TRABAJO_INDUSTRIAS_MANUFACTURERAS, 'Industrias Manufactureras'),
    (TIPO_TRABAJO_ELECTRICIDAD_GAS_AIRE, 'Electricidad, Gas, Vapor y aire Acondicionado'),
    (TIPO_TRABAJO_AGUA_EVACUACION_DESECHOS, 'Agua, evacuación de aguas residuales, desechos y descontaminación'),
    (TIPO_TRABAJO_CONSTRUCCION, 'Construcción'),
    (TIPO_TRABAJO_COMERCIO, 'Comercio'),
    (TIPO_TRABAJO_TRANSPORTE_ALMACENAMIENTO, 'Transporte y Almacenamiento'),
    (TIPO_TRABAJO_TRANSPORTE_ALOJAMIENTO_COMIDAS, 'Actividades de Alojamiento y Servicios de Comidas'),
    (TIPO_TRABAJO_INFORMACION_COMUNICACIONES, 'Información y Comunicaciones'),
    (TIPO_TRABAJO_FINANCIERAS_SEGUROS, 'Actividades Financieras y Seguros'),
    (TIPO_TRABAJO_INMOBILIARIAS, 'Actividades Inmobiliarias'),
    (TIPO_TRABAJO_PROFESIONALES_CIENTIFICAS_TECNICAS, 'Actividades Profesionales, Científicas y Técnicas'),
    (TIPO_TRABAJO_SERVICIOS_ADMINISTRATIVOS_APOYO, 'Actividades de servicios administrativos y de apoyo'),
    (TIPO_TRABAJO_ADMINISTRACION_PUBLICA, 'Administración Pública'),
    (TIPO_TRABAJO_ENSENANZA, 'Enseñanza'),
    (TIPO_TRABAJO_SALUD_HUMANA_ASISTENCIA_SOCIAL, 'Salud Humana y de Asistencia Social'),
    (TIPO_TRABAJO_ARTISTICAS_ENTRETENIMIENTO, 'Actividades Artísticas, de Entretenimiento y Recreativas'),
    (TIPO_TRABAJO_OTRAS_ACTIVIDADES_SERVICIOS, 'Otras Actividades de Servicios'),
    (TIPO_TRABAJO_ACTIVIDADES_HOGAR, 'Actividades de hogares'),
)
# Códigos Para vincular a tipo de Antecedente de Cncer
CIEX_CUELLO_UTERINO = 'ciex02'
CIEX_COLON = 'ciex04'
CIEX_PROSTATA = 'C61X'

# ↓↓ Constantes con valores de WAWARED para mantener compatibilidad ↓↓
TIPO_GESTACION_UNICO = 'unico'
TIPO_GESTACION_MULTIPLE = 'multiple'
TIPO_GESTACION_CHOICES = (
    (TIPO_GESTACION_UNICO, 'Único'),
    (TIPO_GESTACION_MULTIPLE, 'Múltiple'),
)

TERMINACION_NO_APLICA = 'no aplica'
TERMINACION_VAGINAL = 'vaginal'
TERMINACION_CESAREA = 'cesarea'
TERMINACION_ABORTO = 'aborto'
TERMINACION_ABORTO_MOLAR = 'aborto molar'
TERMINACION_OBITO = 'obito'
TERMINACION_ECTOPICO = 'ectopico'
TERMINACION_CHOICES = (
    (TERMINACION_VAGINAL, 'Parto Vaginal'),
    (TERMINACION_CESAREA, 'Cesarea'),
    (TERMINACION_ABORTO, 'Aborto'),
    (TERMINACION_ABORTO_MOLAR, 'Aborto Molar'),
    (TERMINACION_OBITO, 'Óbito'),
    (TERMINACION_ECTOPICO, 'Ectópico'),
    (TERMINACION_NO_APLICA, 'No aplica')
)

ABORTO_COMPLETO = 'completo'
ABORTO_INCOMPLETO = 'incompleto'
ABORTO_SEPTICO = 'septico'
ABORTO_FRUSTO_RETENIDO = 'frusto retenido'
ABORTO_NO_APLICA = 'no aplica'
ABORTO_CHOICES = (
    (ABORTO_NO_APLICA, 'No aplica'),
    (ABORTO_COMPLETO, 'Completo'),
    (ABORTO_INCOMPLETO, 'Incompleto'),
    (ABORTO_SEPTICO, 'Séptico'),
    (ABORTO_FRUSTO_RETENIDO, 'Frusto retenido')
)

LUGAR_HOSPITALARIO = 'hospitalario'
LUGAR_DOMICILIARIO = 'domiciliario'
LUGAR_CHOICES = (
    (LUGAR_HOSPITALARIO, 'Hospitalario'),
    (LUGAR_DOMICILIARIO, 'Domiciliario')
)

MUERTE_NACIO_MUERTO = 'nacio muerto'
MUERTE_MENOR_PRIMERA_SEMANA = 'menor primera semana'
MUERTE_MAYOR_PRIMERA_SEMANA = 'mayor primera semana'
MUERTE_NO_APLICA = 'no aplica'
MUERTE_CHOICES = (
    (MUERTE_NO_APLICA, 'No aplica'),
    (MUERTE_NACIO_MUERTO, 'Nacio muerto'),
    (MUERTE_MENOR_PRIMERA_SEMANA, '< 1ra semana'),
    (MUERTE_MAYOR_PRIMERA_SEMANA, '> 1ra semana')
)

SEXO_WAWARED_MASCULINO = 'M'
SEXO_WAWARED_FEMENINO = 'F'
SEXO_WAWARED_NONE = ''
SEXO_CHOICES_WAWARED = (
    (SEXO_WAWARED_MASCULINO, 'Masculino'),
    (SEXO_WAWARED_FEMENINO, 'Femenino'),
    (SEXO_WAWARED_NONE, '--')
)

LACTANCIA_NO_APLICA = 'no aplica'
LACTANCIA_NO_HUBO = 'no hubo'
LACTANCIA_MENOS_6_MESES = 'menos 6 meses'
LACTANCIA_MAS_6_MESES = 'mas 6 meses'
LACTANCIA_CHOICES = (
    (LACTANCIA_NO_HUBO, 'No hubo'),
    (LACTANCIA_MENOS_6_MESES, 'Menos de 6 meses'),
    (LACTANCIA_MAS_6_MESES, '6 meses a más'),
    (LACTANCIA_NO_APLICA, 'No aplica'),
)
# ↑↑ Fin de constantes con valores de WAWARED para mantener compatibilidad ↑↑

FETO_ESTADO_ACTUAL_VIVO = '1'
FETO_ESTADO_ACTUAL_MUERTO_PRIMERA_SEMANA = '2'
FETO_ESTADO_ACTUAL_MUERTO_DESPUES_PRIMERA_SEMANA = '3'
FETO_ESTADO_ACTUAL_CHOICES = (
    (FETO_ESTADO_ACTUAL_VIVO, 'Vivo'),
    (FETO_ESTADO_ACTUAL_MUERTO_PRIMERA_SEMANA, 'Muetro en la 1ra semana'),
    (FETO_ESTADO_ACTUAL_MUERTO_DESPUES_PRIMERA_SEMANA, 'Muestro después de la 1ra semana'),
)

FETO_ESTADO_NACIMIENTO_VIVO = '1'
FETO_ESTADO_NACIMIENTO_MUERTO = '0'
FETO_ESTADO_NACIMIENTO_CHOICES = (
    (FETO_ESTADO_NACIMIENTO_VIVO, 'Nació vivo'),
    (FETO_ESTADO_NACIMIENTO_MUERTO, 'Nació muerto')
)
