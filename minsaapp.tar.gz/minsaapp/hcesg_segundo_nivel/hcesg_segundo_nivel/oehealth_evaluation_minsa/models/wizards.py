# -*- coding: utf-8 -*-

from odoo import api, fields, models


class WizardConsultation(models.TransientModel):

    _name = 'wizard.consultation'

    date = fields.Date()
    institution = fields.Many2one('oeh.medical.health.center')


class WizardReference(models.TransientModel):

    _name = 'wizard.reference'

    code_patient = fields.Selection(
        [('stable', 'Estable'), ('wrong', 'Mal Estado'), ('serius', 'Grave')])
    institution_origin = fields.Many2one('oeh.medical.health.center',
                                         default=lambda self: self.env.user.company_id.id)
    institution_destination = fields.Many2one('oeh.medical.health.center')
    service_origin = fields.Many2one('product.category',
                                     default=lambda self: self._default_tipo_service())
    service_destination = fields.Many2one('product.category')
    specialty = fields.Many2one('oeh.medical.speciality')
    person = fields.Char()
    type_transport = fields.Selection(
        [('none', 'Ninguno'),
         ('air', 'Aereo'),
         ('fluvial', 'Fluvial'),
         ('maritime', 'Maritimo'),
         ('terra', 'Terrestre')])
    motive_reference = fields.Selection(
        [('none', 'No Capacidad resolutiva (por el nivel del EESS)'),
         ('specialty', 'No capacidad resolutiva por carecer de determinado especialista'),
         ('insumo', 'No capacidad resolutiva por carecer de determinado insumo'),
         ('operative', 'No capacidad resolutiva por no contar con determinado servicio operativo'),
         ('reparation', 'No capacidad resolutiva por servicio en reparación'),
         ('saturated', 'No capacidad resolutiva por servicio saturado'),
         ('essalud', 'Por ser titular de ESSALUD'),
         ('team', 'No capacidad resolutiva por carecer de determinado equipo'),
         ('infraestructure', 'No capacidad resolutiva por carecer de determinada infraestructura')])
    observacion_reference = fields.Char()

    @api.model
    def _default_tipo_service(self):
        service = self.env['product.category'].search([
            ('name', '=', 'CONSULTA EXTERNA')])
        return service.id

    @api.multi
    def load_reference(self):
        for record in self:
            vals = {
                'code_patient': record.code_patient,
                'institution_origin': record.institution_origin.id,
                'institution_destination': record.institution_destination.id,
                'service_origin': record.service_origin.id,
                'service_destination': record.service_destination.id,
                'specialty': record.specialty.id,
                'person': record.person,
                'type_transport': record.type_transport,
                'motive_reference': record.motive_reference,
                'observacion_reference': record.observacion_reference,
            }
            self.env['oehealth.refcon'].create(vals)


class PathologyWizard(models.TransientModel):

    _name = 'pathology.wizard'

    pathology_ids = fields.Many2many(
        'oeh.medical.pathology',
        u'Enfermedades'
    )

    @api.multi
    def employe_lost(self):
        active_id = self.env.context.get('active_id', False)
        if not active_id:
            return True
        evaluation = self.env['oeh.medical.evaluation'].browse(active_id)
        diagnosis_ids = [{'pathology_id': pathology.id} for pathology in self.pathology_ids]
        evaluation.update({'diagnosis_ids': diagnosis_ids})
