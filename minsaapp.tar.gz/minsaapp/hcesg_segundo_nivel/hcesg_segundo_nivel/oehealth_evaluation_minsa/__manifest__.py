{
    'name': 'Consulta Externa y Evaluacion General ',
    'version': '1.0',
    'author': "MINSA",
    'category': 'Generic Modules/Medical',
    'summary': '',
    'depends': [
        'oehealth',
        'oehealth_extra_addons',
        'oehealth_medical_patient_minsa',
        'oehealth_surgery_minsa',
        'catalogominsa_medicamentos'
    ],
    'description': """""",
    "images": [],
    "website": "http://minsa.gob.pe",
    "data": [
        'data/report_paperformat.xml',
        'data/data.xml',
        'views/oeh_medical_evaluation.xml',
        'views/wizards.xml',
        'data/sexual.history.csv',
        'data/contraceptive.method.csv',
        'data/habits.csv',
        'report/evaluation_report.xml',
        'report/evaluation_report_templates.xml',
        'security/ir.model.access.csv'
    ],
    "demo": [

    ],
    'test': [
    ],
    'css': [

    ],
    'js': [

    ],
    'qweb': [

    ],
    "active": False
}
