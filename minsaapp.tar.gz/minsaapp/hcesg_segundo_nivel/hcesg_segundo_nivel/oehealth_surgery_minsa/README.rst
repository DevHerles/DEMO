Modulo de Cirugía - HCESG Segundo Nivel
=========================================

Extiende el modulo de Cirugía  ( oehealth )

# Requerimientos Odoo

oehealth_all_in_one_10/oehealth
