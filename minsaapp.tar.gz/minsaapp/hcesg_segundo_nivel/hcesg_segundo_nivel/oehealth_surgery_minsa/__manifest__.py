# -*- coding: utf-8 -*-

{
    'name': 'Gestión de Cirugías MINSA',
    'version': '1.0',
    'website': 'www.minsa.gob.pe',
    'category': 'oehealth',
    'author': 'MINSA',
    'depends': ['oehealth', 'catalogominsa_cpt'],
    'description': 'Hereda el modelo de examenes de cirugía para el MINSA',
    'data': [
        'views/oeh_medical_surgery_view.xml',
        'security/ir.model.access.csv',
    ],
    'active': False,
    'installable': True
}
