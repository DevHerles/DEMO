# -*- coding: utf-8 -*-


from odoo import api, fields, models


class OeHealthMedicalSurgery(models.Model):
    _inherit = 'oeh.medical.surgery'

    MALE = 1
    FEMALE = 2
    FEMALE_TO_MALE = 3
    MALE_TO_FEMALE = 4

    SELECTION_GENDER = [
        (MALE, 'Male'),
        (FEMALE, 'Female'),
        (FEMALE_TO_MALE, 'Female -> Male'),
        (MALE_TO_FEMALE, 'Male -> Female'),
    ]

    evaluation_id = fields.Many2one('oeh.medical.evaluation')
    appointment_id = fields.Many2one('oeh.medical.appointment', string='Cita')
    cpt_id = fields.Many2one('catalogominsa.cpt_procedimiento', string=u'Denominación', required=True)
    sessions_number = fields.Integer('Número de sesiones', default=1)
    physician_id = fields.Many2one('oeh.medical.physician', string="Médico Solicitante")
    test_type = fields.Many2one(
        'oeh.medical.labtest.types', 'Test Type',
        readonly=True, states={'Draft': [('readonly', False)]}, help="Lab test type")
    operating_room = fields.Many2one(
        'oeh.medical.health.center.ot', 'Operation Theater',
        readonly=True, states={'Draft': [('readonly', False)]})
    gender = fields.Selection(
        SELECTION_GENDER,
        string='Sexo',
        related='patient.sex', store=True,
        readonly=True, states={'Draft': [('readonly', False)]})
    anesthetist = fields.Many2one(
        'oeh.medical.physician', 'Anestesista', help="Anesthetist in charge",
        domain=[('is_pharmacist', '=', False)],
        readonly=True, states={'Draft': [('readonly', False)]}, required=False)
    surgeon = fields.Many2one(
        'oeh.medical.physician', 'Surgeon', help='Surgeon who did the procedure',
        domain=[('is_pharmacist', '=', False)],
        readonly=True, states={'Draft': [('readonly', False)]}, required=False)
    institution = fields.Many2one(
        'oeh.medical.health.center', 'Health Center', help="Health Center",
        readonly=True, states={'Draft': [('readonly', False)]},
        required=False,
    )
    building = fields.Many2one(
        'oeh.medical.health.center.building', 'Building',
        help='Building of the selected Health Center',
        readonly=True, states={'Draft': [('readonly', False)]}, required=False)
    pathology = fields.Many2one(
        'minsa.evaluation.diagnosis', u'Diagnóstico',
        required=True, help="Base Condition / Reason",
        readonly=True, states={'Draft': [('readonly', False)]})
    lab_1 = fields.Char('LAB 1', size=3)
    lab_2 = fields.Char('LAB 2', size=3)

    @api.onchange('lab_1')
    def onchange_lab_1(self):
        if self.lab_1:
            self.lab_1 = self.lab_1.upper()

    @api.onchange('lab_2')
    def onchange_lab_2(self):
        if self.lab_2:
            self.lab_2 = self.lab_2.upper()
