import oeh_medical_surgery_minsa  # noqa
