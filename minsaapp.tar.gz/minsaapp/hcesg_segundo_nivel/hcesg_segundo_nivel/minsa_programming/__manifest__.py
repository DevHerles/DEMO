# -*- coding: utf-8 -*-

{
    'name': 'Modulo para la programacion de personal/profesional de salud',
    'version': '1.0',
    'author': 'MINSA',
    'website': 'www.minsa.gob.pe',
    'category': 'HR',
    'depends': [
        'web',
        'oehealth_healthcenter',
    ],
    'description': 'Modulo que permite realizar '
                   'programaciones de trabajo de los profesionales de salud',
    'data': [
        'views/trees.xml',
        'views/forms.xml',
        'views/wizard.xml',
        'views/actions.xml',
        'views/menus.xml',
        'views/theme.xml',
        'security/ir.model.access.csv',
    ],
    'qweb': [
        'static/src/xml/programming.xml',
    ],
    'installable': True
}
