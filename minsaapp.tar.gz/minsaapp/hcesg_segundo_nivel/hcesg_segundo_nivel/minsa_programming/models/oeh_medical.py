# -*- coding: utf-8 -*-


from odoo import api, fields, models
from odoo.exceptions import ValidationError


class MinsaHealthAppointment(models.Model):
    _inherit = 'oeh.medical.appointment'

    WALKIN_STATUS = [
        ('Free', 'Libre'),
        ('Scheduled', 'Programado'),
        ('Invoiced', 'Pagado'),
        ('Completed', 'Atendido'),
        ('Cancel', 'Cancelado'),
    ]

    NORMAL = 'normal'
    ADICIONAL = 'adicional'
    TIPO_DE_CUPO = [
        (NORMAL, 'Normal'),
        (ADICIONAL, 'Adicional')
    ]

    patient = fields.Many2one(
        'oeh.medical.patient', 'Patient',
        help='Patient Name', required=False,
        readonly=True, states={'Scheduled': [('readonly', False)]})
    state = fields.Selection(
        WALKIN_STATUS, string='State',
        readonly=True, states={'Scheduled': [('readonly', False)]},
        default=lambda *a: 'Scheduled')
    quote = fields.Integer('Número Cupo')
    programmind_bed_id = fields.Many2one(
        'minsa.programming.bed', 'Programacion Generada',
        readonly=True, states={'Scheduled': [('readonly', False)]})

    tipo_de_cupo = fields.Selection(TIPO_DE_CUPO, 'Tipo de cupo')

    @api.multi
    def check_physician_availability(self, doctor, appointment_date):
        return True


class CenterBeds(models.Model):
    _inherit = 'oeh.medical.health.center.beds'

    programming_quotas_id = fields.Many2one(
        'minsa.programming.quotas', u'Programación cupos',
        compute='_compute_programming_quotas_id')

    @api.one
    def _compute_programming_quotas_id(self):
        domain = [('bed_id', '=', self.id)]
        return self.env['minsa.programming.quotas'].search(domain, limit=1).id

    @api.model
    def create(self, values):
        res = super(CenterBeds, self).create(values)

        quotas_model = self.env['minsa.programming.quotas']
        bed_ids = self.search([]).ids
        quotas_bed_ids = [i.bed_id.id for i in quotas_model.search([])]
        for bed_id in set(bed_ids) - set(quotas_bed_ids):
            quotas_model.create({'bed_id': bed_id})
        return res

    @api.multi
    def unlink(self):
        for rec in self:
            rec.programming_quotas_id.unlink()
        return super(CenterBeds, self).unlink()


class MinsaProgramingDraftAppointment(models.Model):
    _name = 'minsa.programming.draft.appointment'

    STATE_DRAFT = 'draft'
    STATE_CONFIRMED = 'confirmed'
    SELECTION_STATE = [(STATE_DRAFT, 'Borrador'), (STATE_CONFIRMED, 'Confirmado')]

    document_number = fields.Char('Documento del paciente')
    full_name = fields.Char('Appellidos y nombres')
    physician_id = fields.Many2one('oeh.medical.physician', 'Profesional')
    programming_bed_id = fields.Many2one('minsa.programming.bed', 'Programar cama')
    appointment_date = fields.Date('Fecha de cita adicional')
    state = fields.Selection(SELECTION_STATE, 'Estado del la cita adicional')
    appointment_id = fields.Many2one('oeh.medical.appointment', 'Cita confirmada')
    total_quotas = fields.Integer('Total de cupos', compute='_compute_total_quotas')

    @api.multi
    def _compute_total_quotas(self):
        for record in self:
            record.total_quotas = record.programming_bed_id.quotas + record.programming_bed_id.quotas_additional

    def goto_appointment(self):
        self.ensure_one()
        return {
            'string': 'Cita adicional',
            'name': 'Cita adicional',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': False,
            'res_model': 'oeh.medical.appointment',
            'domain': [],
            'context': {},
            'target': 'online',
            'type': 'ir.actions.act_window',
            'res_id': self.appointment_id.id
        }

    def confirm_appointment(self):
        domain = [('document_number', '=', self.document_number)]
        patient = self.env['oeh.medical.patient'].search(domain, limit=1)

        self.programming_bed_id.write({'quotas_additional': self.programming_bed_id.quotas_additional + 1})
        if patient:
            domain = [
                ('doc_date', '=', self.programming_bed_id.date_day),
                ('programmind_bed_id', '=', self.programming_bed_id.id)
            ]

            if not self.env['oeh.medical.appointment'].search(domain, limit=1):
                raise ValidationError(u"No existen cupos para esta programación. \n\nNo se puede confirmar la cita.")

            appointment = self.programming_bed_id.action_click_checked(patient.id)
            if appointment:
                is_additional = True
                appointment.set_to_reserved(is_additional)
                self.write({'appointment_id': appointment.id,
                            'state': 'confirmed'})

                return {
                    'name': u"Appointments",
                    'type': 'ir.actions.act_window',
                    'view_mode': 'form',
                    'res_model': 'oeh.medical.appointment',
                    'view_id': self.env.ref('oehealth.oeh_medical_appointment_view').id,
                    'context': {},
                    'res_id': appointment.id
                }
            else:
                raise ValidationError(u'No existen citas programadas')
        else:
            raise ValidationError(u'Paciente no cuenta con historia clínica')
