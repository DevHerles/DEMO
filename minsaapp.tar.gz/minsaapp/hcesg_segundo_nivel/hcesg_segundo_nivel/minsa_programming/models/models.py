# -*- coding: utf-8 -*-

import datetime
import pytz

from dateutil.rrule import DAILY, MINUTELY, rrule

from odoo import api, fields, models
from odoo.exceptions import ValidationError

COLORS = [
    ('0', '#FFA233'),
    ('1', '#DAF7A6'),
    ('2', '#FFC300'),
    ('3', '#FF5733'),
    ('4', '#33FFF3'),
]

TYPE = [
    ('CE', 'Consultorio'),
    ('EM', 'Emergencia'),
    ('QX', 'Cirugía'),
    ('HO', 'Hospitalización'),
    ('OT', 'Other'),
]

CATEGORY = [
    ('support', 'Apoyo'),
    ('main', 'Encargado'),
    ('other', 'Otro'),
]


class Util(object):

    @property
    def offset(self):
        tz = self.env.user.tz and pytz.timezone(self.env.user.tz) or pytz.timezone('America/Lima')
        offset = datetime.datetime.now(tz)
        offset = offset.utcoffset().total_seconds() / 3600
        return offset


class Programming(models.Model):
    _name = 'minsa.programming'

    @api.multi
    def name_get(self):
        return [(obj.id, u'{} | {} al {}'.format(
            obj.department_id.name, obj.date_start, obj.date_end
        )
        ) for obj in self]

    medicalcenter_id = fields.Many2one(
        'oeh.medical.health.center',
        string="Centro Medico",
        required=True,
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},

    )
    department_id = fields.Many2one(
        'hr.department',
        string="Departamento",
        domain=[('is_programming', '=', True)],
        required=True,
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )
    employee_id = fields.Many2one(
        'hr.employee',
        string="Jefe Departamento",
        related='department_id.manager_id',
        store=True,
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )
    date_start = fields.Date(
        string='Fecha inicio',
        required=True,
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )
    date_end = fields.Date(
        string='Fecha final',
        required=True,
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )
    bed_ids = fields.One2many(
        'minsa.programming.bed',
        'programming_id',
        string='Programacion Profesionales',
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )
    professional_ids = fields.One2many(
        'minsa.programming.professional',
        'programming_id',
        string='Lineas',
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )
    days = fields.Integer(
        string='Dias',
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )
    SELECTION_STATE = [
        ('draft', 'Borrador'),
        ('done', 'Cerrado'),
        ('cancel', 'Cancelado'),
    ]
    state = fields.Selection(SELECTION_STATE, string='Estado', default='draft')

    tiempo_atencion = fields.Integer(u'Tiempo de atención')

    @api.one
    def action_click_checked(self):
        if self.bed_ids:
            for bed in self.bed_ids:
                bed.action_click_checked()
            self.write({'state': 'done'})

    @api.multi
    def open_programming(self):
        self.ensure_one()
        data = self.read(self)
        return {
            'string': 'Consolidado Programacion',
            'name': 'Consolidado Programacion',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': False,
            'res_model': 'minsa.programming.wizard',
            'domain': [],
            'target': 'online',
            'type': 'ir.actions.act_window',
            'datas': data,
        }

    def _filter_load_room(self, beds_objs, dates, turn_objs, programming_id, ttype):
        res = []
        if (beds_objs == '' or dates == '' or turn_objs == '' or programming_id == '' or ttype == ''):
            raise ValidationError(u'Los datos estan incompletos')
        for bed in beds_objs:
            reg_dates = []
            for date in dates:
                reg_turn = []
                for turn in turn_objs:
                    # Verificando registros en BD
                    # Obteniendo lista de CE  a programar
                    person = {}
                    domain = [
                        ('programming_id', '=', programming_id),
                        ('bed_id', '=', bed.id),
                        ('turn_id', '=', turn.id),
                        ('date_day', '=', date),
                        ('type', '=', ttype),
                    ]
                    programming_bed = self.env['minsa.programming.bed'].search(domain, limit=1)
                    if programming_bed:
                        person = {
                            'type': ttype,
                            'programmingdeb_id': programming_bed.id,
                            'person_name': programming_bed.employee_id.name,
                            'person_id': programming_bed.employee_id.id,
                        }
                    vals_turn = {
                        'person': person,
                        'turn_id': turn.id,
                        'turn_name': '{} - {}'.format(turn.hour_begin, turn.hour_end),
                        'tiempo_atencion': bed.tiempo_atencion,
                    }
                    reg_turn.append(vals_turn)
                vals_date = {
                    'date': date,
                    'turns': reg_turn
                }
                reg_dates.append(vals_date)
            vals = {
                'bed_id': bed.id,
                'bed_name': bed.name,
                'dates': reg_dates
            }
            res.append(vals)
        return res

    @api.model
    def load_matrix(self, values):
        if 'programming_id' in values:
            domain = [('id', '=', values['programming_id'])]
            model_programming = self.search(domain, limit=1)
            # Generando lista de fechas
            date_start = fields.Date.from_string(model_programming.date_start)
            date_end = fields.Date.from_string(model_programming.date_end)
            dates = [fields.Datetime.to_string(item)
                     for item in rrule(freq=DAILY, dtstart=date_start, until=date_end)]

            model_beds = self.env['oeh.medical.health.center.beds']

            domain = [
                ('institution', '=', model_programming.medicalcenter_id.id),
                ('department_id', '=', model_programming.department_id.id),
                ('is_assistence', '=', True),
                ('type_room', '=', 'CE'),
            ]
            # Obteniendo lista de CE  a programar
            beds_ce_objs = model_beds.search(domain + [('type_room', '=', 'CE')])

            # Obteniendo lista de EM a programar
            beds_em_objs = model_beds.search(domain + [('type_room', '=', 'EM')])

            # Obteniendo lista de HO a programar
            beds_ho_objs = model_beds.search(domain + [('type_room', '=', 'HO')])

            # Obteniendo lista de QX a programar
            beds_qx_objs = model_beds.search(domain + [('type_room', '=', 'QX')])

            # Obteniendo personal a programar
            domain = [
                ('department_id', '=', model_programming.department_id.id),
            ]
            list_person = self.env['oeh.medical.physician'].search(domain)
            list_person = [dict(person_id=person.id, person_name=person.name)
                           for person in list_person]

            # Obteniendo turnos
            model_turn = self.env['minsa.company.turn'].search([
                ('medicalcenter_id', '=', model_programming.medicalcenter_id.id),
            ])

            vars_ce = self._filter_load_room(beds_ce_objs, dates, model_turn, values['programming_id'], 'CE')
            vars_em = self._filter_load_room(beds_em_objs, dates, model_turn, values['programming_id'], 'EM')
            vars_ho = self._filter_load_room(beds_ho_objs, dates, model_turn, values['programming_id'], 'HO')
            vars_qx = self._filter_load_room(beds_qx_objs, dates, model_turn, values['programming_id'], 'QX')
            res = {
                'days': dates,
                'ce': vars_ce,
                'ho': vars_ho,
                'em': vars_em,
                'qx': vars_qx,
                'persons': list_person,
            }
            return res

    @api.model
    def create_register(self, values):
        tz = pytz.timezone(self.env.user.tz) if self.env.user.tz else pytz.utc
        enddate = fields.Datetime.from_string(values['day'])
        enddate = tz.localize(enddate)
        enddate = enddate.astimezone(pytz.utc)
        day = fields.Datetime.to_string(enddate)

        if 'programming_id' in values:
            domain = [
                ('programming_id', '=', values['programming_id']),
                ('bed_id', '=', values['bed_id']),
                ('employee_id', '=', values['medical_id']),
                ('turn_id', '=', values['turn_id']),
                ('date_day', '=', day),
                ('type', '=', values['type_id']),
            ]
            model_programming = self.env['minsa.programming.bed']
            if not model_programming.search(domain, limit=1):
                domain = [('id', '=', values['bed_id'])]
                bed = self.env['oeh.medical.health.center.beds'].search(domain, limit=1)
                if bed:
                    if bed.tiempo_atencion == 0:
                        raise ValidationError(u'{}: El tiempo de atención por paciente no está asignado. \n\n No se '
                                              u'ha generado la programación.'.format(bed.name))
                    vals = {
                        'programming_id': values['programming_id'],
                        'bed_id': values['bed_id'],
                        'employee_id': values['medical_id'],
                        'turn_id': values['turn_id'],
                        'date_day': day,
                        'quotas': bed.quotas,
                        'quotas_additional': bed.quotas_additional,
                        'tiempo_atencion': bed.tiempo_atencion,
                        'type': values['type_id'],
                    }
                    model_programming.create(vals)
        return True


class ProgrammingBed(models.Model, Util):
    _name = 'minsa.programming.bed'
    _order = 'date_day,turn_id'

    programming_id = fields.Many2one('minsa.programming', string='Programacion')
    bed_id = fields.Many2one('oeh.medical.health.center.beds', string='Consultorio/Cama')
    service_id = fields.Many2one(
        'product.category',
        related='bed_id.categ_id',
        string="Servicio/Departamento",
        store=True
    )
    employee_id = fields.Many2one(
        'oeh.medical.physician',
        string="Profesional Salud",
        required=True,
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )
    turn_id = fields.Many2one(
        'minsa.company.turn',
        string='Turno',
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )
    quotas = fields.Integer(
        'Cupos',
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
        default=20
    )
    quotas_additional = fields.Integer(
        'Adicionales',
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
        default=2
    )
    date_day = fields.Date(
        string='Fecha ',
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )
    date_start = fields.Datetime(
        string='Hora inicio',
        compute='_compute_date_day',
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )
    date_end = fields.Datetime(
        string='Hora termino',
        compute='_compute_date_day',
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )
    type = fields.Selection(
        TYPE,
        string='Tipo',
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )
    category_person = fields.Selection(
        CATEGORY,
        string='Categoria',
        default='support',
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )
    SELECTION_STATE = [
        ('draft', 'Borrador'),
        ('done', 'Aceptado'),
        ('cancel', 'Cancelado'),
    ]
    state = fields.Selection(
        SELECTION_STATE,
        string='Estado',
        default='draft',
    )
    appointment_ids = fields.One2many(
        'oeh.medical.appointment',
        'programmind_bed_id',
        string="Cupos ",
    )

    quotas_enable = fields.Integer(
        'Cupos Disponibles',
        compute='_compute_quotas_enable',
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
    )

    tiempo_atencion = fields.Integer(u'Tiempo de atención (minutos)')

    _sql_constraints = [
        ('field_unique_minsa_programming_bed',
         'unique(programming_id,employee_id,turn_id,date_day,bed_id)',
         'Ya se encuentra programado ese horario.!')
    ]

    @api.multi
    def name_get(self):
        res = []
        for record in self:
            res.append((record.id, u'{} | {}'.format(record.date_day, record.bed_id.name)))
        return res

    def float_time_convert(self, float_val):
        return map(lambda x: int(x), '{0:.2f}'.format(abs(float_val)).split('.'))

    @api.multi
    def _compute_date_day(self):
        for record in self:
            turno_inicio = self.float_time_convert(record.turn_id.hour_begin)
            dt_date_start = map(lambda x: int(x), record.date_day.split('-') + turno_inicio)
            dt_date_start = datetime.datetime(*dt_date_start) + datetime.timedelta(hours=-self.offset)
            record.date_start = fields.Datetime.to_string(dt_date_start)

            flag = record.turn_id.hour_begin > record.turn_id.hour_end
            turno_fin = self.float_time_convert(record.turn_id.hour_end)

            dt_date_end = map(lambda x: int(x), record.date_day.split('-') + turno_fin)
            dt_date_end = datetime.datetime(*dt_date_end) + datetime.timedelta(hours=-self.offset) + datetime.timedelta(days=flag)
            record.date_end = fields.Datetime.to_string(dt_date_end)

    @api.multi
    def _compute_quotas_enable(self):
        for record in self:
            free = record.quotas + record.quotas_additional
            for app in record.appointment_ids:
                if app.state != 'Scheduled':
                    free -= 1
            record.quotas_enable = free

    @api.model
    def unlink_register(self, values):
        if 'programmingdeb_id' in values:
            domain = [('id', '=', values['programmingdeb_id'])]
            self.search(domain, limit=1).unlink()

    @api.one
    def action_click_checked(self, patient_id=False):
        model_appointment = self.env['oeh.medical.appointment']

        # Tiempo (minutos)/nuevo
        x = list(rrule(
            freq=MINUTELY,
            count=int(self.quotas + self.quotas_additional),
            interval=self.tiempo_atencion,
            dtstart=fields.Datetime.from_string(self.date_start))
        )
        count = 0
        appointment = False
        for reg in x:
            count = count + 1
            hour = datetime.datetime.strftime(reg, "%Y-%m-%d %H:%M:%S")
            domain = [
                ('programmind_bed_id', '=', self.id),
                ('doctor', '=', self.employee_id.id),
                ('appointment_date', '=', hour),
                ('institution', '=', self.programming_id.medicalcenter_id.id),
            ]
            if not self.env['oeh.medical.appointment'].search(domain, limit=1):
                vals = {
                    'programmind_bed_id': self.id,
                    'doctor': self.employee_id.id,
                    'appointment_date': hour,
                    'doc_date': reg.date(),
                    'quote': count,
                    'duration': 1,
                    'institution': self.programming_id.medicalcenter_id.id,
                    'tipo_de_cupo': 'normal' if count <= self.quotas else 'adicional',
                }
                if patient_id:
                    vals.update({'patient': patient_id})

                appointment = model_appointment.create(vals)
        self.write({'state': 'done'})
        return appointment

    @api.model
    def get_cupo(self, values):
        tip_doc = values['tip_doc']
        nro_doc = values['nro_doc']
        ref_cod_eess_origen = values['ref_cod_eess_origen']
        ref_service_destino = values['ref_service_destino']
        ref_service_origin = values['ref_service_origin']
        ref_date_atention = values['ref_date_atention']
        ref_ubigeo_referencia = values['ref_ubigeo_referencia']
        ref_direccion_actual_paciente = values['ref_direccion_actual_paciente']
        ref_id = values['ref_id']

        domain = [
            ('type_number', '=', tip_doc),
            ('document_number', '=', nro_doc)
        ]
        patient_model = self.env['oeh.medical.patient']
        paciente = patient_model.search(domain, limit=1) or \
            patient_model._create_from_mpi_document_number(tip_doc, nro_doc)

        paciente.validate_sis()

        domain = [
            ('programmind_bed_id.service_id', '=', ref_service_destino),
            ('programmind_bed_id.date_day', '>', fields.Date.today()),
            ('state', '=', 'Scheduled'),
        ]
        appointment = self.env['oeh.medical.appointment'].search(domain, limit=1)
        if appointment:
            bed = appointment.programmind_bed_id

        if appointment and not self.search_patiente_with_appointment(paciente, ref_service_destino, bed.date_day):
            appointment.write({
                'patient': paciente.id,
                'state': 'Completed',
                'ref_cod_eess_origen': ref_cod_eess_origen,
                'ref_service_origin': ref_service_origin,
                'ref_date_atention': ref_date_atention,
                'ref_ubigeo_referencia': ref_ubigeo_referencia,
                'ref_direccion_actual_paciente': ref_direccion_actual_paciente,
                'ref_id': ref_id
            })

            vals = {
                'cita': 'success',
                'codigo': appointment.name,
                'fecha': appointment.appointment_date.split(' ')[0],
                'hora': appointment.appointment_date.split(' ')[1],
                'consultorio': bed.bed_id.ward.name,
                'servicio': bed.service_id.name,
                'turno': bed.turn_id.display_name,
                'nom_paciente': appointment.patient.name,
                'tip_doc_paciente': appointment.patient.partner_id.type_number,
                'nro_doc_paciente': appointment.patient.partner_id.document_number,
                'nom_medico': appointment.doctor.employee_id.name,
                'nro_doc_medico': appointment.doctor.employee_id.identification_id
            }
        else:
            vals = {
                'cita': 'Ya existe una cita para este paciente.'
            }
        return vals

    @api.model
    def search_patiente_with_appointment(self, patient, service_id, date):
        domain = [
            ('patient', '=', patient.id),
            ('programmind_bed_id.date_day', '=', date),
            ('programmind_bed_id.service_id', '=', service_id),
        ]
        appointment = self.env['oeh.medical.appointment'].search(domain, limit=1)
        return bool(appointment.id)


class ProgrammingProfessional(models.Model):
    _name = 'minsa.programming.professional'

    programming_id = fields.Many2one(
        'minsa.programming', 'Programacion',
        required=True
    )
    employee_id = fields.Many2one(
        'oeh.medical.physician', 'Profesional Salud',
        required=True
    )
    total_number_hours = fields.Integer(
        string='Horas Totales'
    )


class MinsaProgrammingQuotas(models.Model):
    _name = 'minsa.programming.quotas'

    bed_id = fields.Many2one(
        'oeh.medical.health.center.beds', string='consultorio/Cama', required=True)
    department_id = fields.Many2one(
        'hr.department', related='bed_id.department_id', store=True)
    new_internal_order = fields.Integer('N. orden interna', help='Nuevo y reingresante/Orden interna')
    new_external_order = fields.Integer('N. orden externa', help='Nuevo y reingresante/Orden externa')
    new_additional = fields.Integer('N. adicional', help='Nuevo y reingresante/Adicional')

    continuator_internal_order = fields.Integer('C. orden interna', help='Continuador/Orden interna')
    continuator_external_order = fields.Integer('C. orden externa', help='Continuador/Orden externa')
    continuator_additional = fields.Integer('C. adicional', help='Continuador/Adicional')
    total_quotas = fields.Integer('Total citas', compute='_compute_total_quotas', store=True)
    new_min = fields.Integer('T. nuevo', help='Tiempo (minutos)/nuevo')
    continuator_min = fields.Integer('T. continuador', help='Tiempo (minutos)/continuador')
    total_min = fields.Integer('Total minutos', compute='_compute_total_quotas', store=True)

    _sql_constraints = [
        ('unique_bed_id',
         'unique(bed_id)',
         u'Un único consultorio por registro!')
    ]

    @api.one
    @api.depends('new_internal_order', 'new_external_order', 'new_additional',
                 'continuator_internal_order', 'continuator_external_order',
                 'continuator_additional', 'new_min', 'continuator_min')
    def _compute_total_quotas(self):
        new_re_entering = self.new_internal_order + self.new_external_order + self.new_additional
        # continuator (c)
        c = self.continuator_internal_order + self.continuator_external_order + self.continuator_additional
        self.total_quotas = new_re_entering + c
        self.total_min = self.new_min * new_re_entering + self.continuator_min * c

    @api.multi
    def write(self, values):
        res = super(MinsaProgrammingQuotas, self).write(values)
        for rec in self:
            rec.bed_id.write({'quotas': rec.total_quotas})
        return res
