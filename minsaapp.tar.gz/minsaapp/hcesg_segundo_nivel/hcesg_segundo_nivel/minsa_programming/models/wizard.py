# -*- coding: utf-8 -*-

from odoo import fields, models
from odoo.exceptions import ValidationError


class ProgrammingWizard(models.TransientModel):
    _name = 'minsa.programming.wizard'

    programming_id = fields.Many2one('minsa.programming')

    medicalcenter_id = fields.Many2one(
        'oeh.medical.health.center',
        string="Centro Médico",
        required=True
    )
    department_id = fields.Many2one(
        'hr.department',
        string="Departamento",
        required=True
    )
    date_start = fields.Date(string='Fecha inicio', required=True)
    date_end = fields.Date(string='Fecha final', required=True)
    days = fields.Integer(string='Dias')


class ProgrammingDatesWizard(models.TransientModel):
    _name = 'minsa.programming.wizard.dates'

    programingwizard_id = fields.Many2one('minsa.programming.wizard')
    day = fields.Date()


class MinsaProgrammingAdditionalQuotaWizard(models.TransientModel):
    _name = 'minsa.programming.additional.quota'
    _description = 'Additional Quotas Wizard'
    _rec_name = "search_field"

    search_field = fields.Char()
    quotas = fields.One2many(
        'minsa.programming.additional.quota.line',
        'additional_quota_id',
        'Mis programaciones')
    type_number = fields.Char('Tipo de documento')
    document_number = fields.Char('Número de documento', readonly=True)
    full_name = fields.Char('Apellidos y nombres', readonly=True)
    physician_id = fields.Many2one(
        'oeh.medical.physician', u'Médico',
        default=lambda self: self._default_physician_id(),
        required=True)

    is_physician = fields.Boolean('Is Pysician', default=lambda self: self._is_physician())

    def _is_physician(self):
        return self.env.user.has_group('oehealth.group_oeh_medical_physician')

    def _default_physician_id(self):
        if self._is_physician():
            domain = [('oeh_user_id', '=', self.env.user.id)]
            return self.physician_id.search(domain, limit=1).id
        return False

    def search_patients(self):
        self.quotas.unlink()
        self.document_number = False
        self.full_name = False

        patient = self.env['oeh.medical.patient'].search([('document_number', '=', self.search_field)], limit=1)

        if patient:
            self.document_number = patient.document_number
            self.full_name = u'{} {} {}'.format(patient.first_name or patient.name, patient.last_name or '',
                                                patient.last_name_2 or '')
        else:
            if len(self.search_field) == 8 and self.search_field.isdigit():
                res = self.env['consultadatos.mpi'].ver(self.search_field, '01')
                if 'errors' in res:
                    errors = res['errors']
                    msg = 'Error Desconocido, comuníquese con el administrador del sistema'
                    msg = errors and res['errors'][0].get('detail', msg)
                    raise ValidationError(msg)

                self.document_number = res.get('numero_documento')
                self.full_name = u'{} {} {}'.format(res.get('nombres'), res.get('apellido_paterno'), res.get('apellido_materno'))

        self._compute_programming_id()

    def _compute_programming_id(self):
        for rec in self:
            domain = [('date_day', '>=', fields.Date.today())]
            if not self._is_physician() and self.physician_id:
                domain = [('date_day', '>=', fields.Date.today()),
                          ('employee_id.oeh_user_id', '=', self.env.user.id)]

            beds = self.env['minsa.programming.bed'].search(domain)
            rec.quotas = [
                [0, False, {
                    'type': bed.type,
                    'turn': bed.turn_id.display_name,
                    'bed': bed.bed_id.display_name,
                    'employee': bed.employee_id.display_name,
                    'date_day': bed.date_day,
                    'date_start': bed.date_start,
                    'programming_id': bed.id,
                }] for bed in beds

            ]


class MinsaProgrammingAdditionalQuotaLine(models.TransientModel):
    _name = 'minsa.programming.additional.quota.line'
    _rec_name = 'additional_quota_id'

    additional_quota_id = fields.Many2one('minsa.programming.additional.quota')
    type_number = fields.Char('Tipo de documento')
    document_number = fields.Char(u'Número de documento', related='additional_quota_id.document_number')
    full_name = fields.Char('Apellidos y nombres', related='additional_quota_id.full_name')

    turn = fields.Char('Turno')
    bed = fields.Char('Tipo')
    employee = fields.Char(u'Médico')
    date_day = fields.Date('Fecha')
    date_start = fields.Date('Hora de inicio')
    programming_id = fields.Many2one('minsa.programming.bed', u'Programación')

    def create_draft_appointment(self):

        domain = [
            ('document_number', '=', self.document_number),
            ('appointment_date', '=', self.date_day),
            ('programming_bed_id', '=', self.programming_id.id)
        ]
        draft = self.env['minsa.programming.draft.appointment'].search(domain, limit=1)
        if not draft:
            vals = {'document_number': self.document_number,
                    'full_name': self.full_name,
                    'appointment_date': self.date_day,
                    'programming_bed_id': self.programming_id.id,
                    'state': 'draft'}
            self.env['minsa.programming.draft.appointment'].create(vals)

            return {
                'name': 'Información',
                'type': 'ir.actions.act_window',
                'res_model': 'info_view.view',
                'view_mode': 'info',
                'view_type': 'info',
                'target': 'new',
                'context': {'message': 'La solicitud de cita adicional ha sido generado correctamente.'}
            }

        else:
            raise ValidationError(
                'Paciente ya cuenta con una solicitud de cita adicional para la programación {}'.
                format(self.programming_id.display_name))
