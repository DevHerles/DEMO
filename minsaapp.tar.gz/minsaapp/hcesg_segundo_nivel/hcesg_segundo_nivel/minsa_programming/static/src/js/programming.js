openerp.minsa_programming = function (instance,local) {
    var qWeb = instance.web.qweb;
    var _t = instance.web._t;
    instance.programming = {};
    /*Funcion que es usada en la programacion mensual del colaborador*/
    instance.programming.programmingConsolidate = instance.web.form.FormWidget.extend({
        events: {
            "click i.turnSelected": "_checkAllTurns",
            "click i#medicalregister": "_unlinkBed",
            "click td.turnSelectedOne": "_checkOne",
            "click input#save_register": "_saveData",
        },

        init: function () {
            this._super.apply(this, arguments);
            this.days = 0;
            this.programming_id = '';
            this.medicalcenter_id = '';
            this.department_id = '';
            this.date_start = '';
            this.date_end = '';
            this.items = [];
            this.items_em = [];
            this.items_ho = [];
            this.items_em = [];
            this.persons = [];
            this.days = [];
            this.promises = [];
            this.ProgrammingModel = new instance.web.Model('minsa.programming');
            this.ProgrammingBedModel = new instance.web.Model('minsa.programming.bed');
        },

        start: function () {
            this.programming_id = this.view.datarecord.programming_id;
            this.medicalcenter_id = this.view.datarecord.medicalcenter_id;
            this.department_id = this.view.datarecord.department_id;
            this.date_start = this.view.datarecord.date_start;
            this.date_end = this.view.datarecord.date_end;
            this.days = this.view.datarecord.days;
            this.items = [];
            this.items_em = [];
            this.items_ho = [];
            this.items_qx = [];
            this.persons = [];
            this.days = [];
            var self = this;
            self._fetchData();
            $.when.apply($, this.promises).then(function () {
                self._render();
                self._loadData();
            });
        },
        _render: function () {
            this.$el.html(qWeb.render('programming.programmingConsolidate', {widget: this}));
        },
        _loadData: function () {
            var self = this;
            var $static_thead = $('table.static_thead');
            $static_thead.floatThead({
                zIndex: 1,
                scrollContainer: function($table){
                    return $table.closest('.wrapper');
                }
            });
        },
        _saveData: function(event){
            var self = this;
            var index;
            var item = self.$(event.target);
            var list_reg = $(".fa-check-register");
            var medical_id = $('#medical_name').val();
            if (medical_id==''){
              alert("No seleccionó el médico");
              return;
            }
            for (index = 0; index < list_reg.length; ++index) {
              var register = list_reg[index];
              var vars = {
                  programming_id: self.programming_id,
                  turn_id: $(register).data("turn-id"),
                  day: $(register).data("day-id"),
                  bed_id: $(register).data("bed-id"),
                  medical_id: medical_id,
                  type_id: $(register).data("type"),
                  action: 'create',
              }
              self.ProgrammingModel.call('create_register', [
                vars
              ]).then(function (response) {
                $(item).attr("disabled","true");
                $(".msg_save").html("<b>Se estan guardando los datos</b>");
              });
            }
            self.start();
        },
        _unlinkBed: function(event){
            var self = this;
            var item = self.$(event.target);
            var r = confirm("Esta seguro que desea quitar!");
            if (!r) {
                return;
            }
            var programmingdeb_id = item.data('programmingdeb-id');
            if (programmingdeb_id==''){
              alert("No selecciono el Medico");
              return;
            }
            self.ProgrammingBedModel.call('unlink_register', [
                {
                  programmingdeb_id: programmingdeb_id,
                }
              ]).then(function (response) {
                  self.start();
              });
        },
        _checkOne: function(event){
            var self = this;
            var item = self.$(event.target);
            var medical_id = $('#medical_name').val();
            var turn_id = item.data('turn-id');
            var bed_id = item.data('bed-id');
            var type_id = item.data('type');
            var day = item.data('day-id');
            var valor = item.data('valor');
            var str_select = "td i[data-turn-id="+turn_id+"][data-bed-id="+bed_id+"][data-day-id='"+day+"'] ";
            if (valor){
                $(str_select).addClass("fa fa-check fa-2x fa-check-register");
            }else{
                $(str_select).removeClass("fa fa-user-md fa-2x");
            }
        },
        _checkAllTurns: function(event){
            var self = this;
            var item = self.$(event.target);
            var turn_id = item.data('turn1-id');
            var bed_id = item.data('bed1-id');
            var type_id = item.data('type');
            var valor = item.data('valor');
            var str_select = "tr[data-bed-id="+bed_id+"] i[data-turn-id="+turn_id+"]";
            if (valor==true){
                $(str_select).addClass("fa fa-check fa-2x fa-check-register");
            }else{
                $(str_select).removeClass("fa fa-user-md fa-2x");
            }
        },
        _fetchData: function() {
          var self = this;
          self.promises.push(
            self.ProgrammingModel.call('load_matrix', [
                  {
                      programming_id: self.programming_id,
                  }
              ]).then(function (response) {
                self.items = response.ce;
                self.items_em = response.em;
                self.items_ho = response.ho;
                self.items_qx = response.qx;
                self.persons = response.persons;
                self.days = response.days;
            })
          );

        },
    });
    instance.web.form.custom_widgets.add('programming_consolidate', 'instance.programming.programmingConsolidate');
};
