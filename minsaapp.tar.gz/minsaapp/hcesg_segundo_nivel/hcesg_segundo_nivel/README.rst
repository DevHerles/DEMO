HCESG Segundo Nivel
===================

Sistema de gestion de segundo nivel


# Requerimientos Odoo

oehealth_all_in_one_10/oehealth
oehealth_all_in_one_10/oehealth_extra_addons
https://git.minsa.gob.pe/oidt/oehealth_all_in_one_10

minsadev/odoo_share
https://git.minsa.gob.pe/oidt/odoo-share

minsadev/gestion_rrhh
https://git.minsa.gob.pe/oidt/gestion_rrhh

odoo-catalogos
https://git.minsa.gob.pe/oidt/odoo_catalogos

hcesg_segundo_nivel
https://git.minsa.gob.pe/oidt/hcesg_segundo_nivel


# Instalacion

- oehealth
- oehealth_minsa
- gestion_rrhh


# addons_path:


```
addons_path=..,../oehealth_all_in_one_10,../minsadev/odoo_share,../minsadev
```


# Depencias python

```bash
pip install -U git+ssh://git@git.minsa.gob.pe/oidt/mpi-client.git@develop#egg=mpi_client
```


# Dependencia impresion FUA

postgresql-plpython-9.5

Clonar y cargar el siguiente repositorio

https://github.com/Comunitea/jasperserver

La detalles de la configuración que se hace en Odoo

[configuración de reportes de Odoo](/../../wikis/configuracion-de-reportes)

