# -*- coding: utf-8 -*-

{
    'name': 'Exgendiendo Medicamentos - MINSA',
    'version': '1.0',
    'website': 'www.minsa.gob.pe',
    'category': 'oehealth',
    'author': 'MINSA',
    'depends': ['oehealth_extra_addons'],
    'description': 'Hereando el modelo de medicinas para el MINSA',
    'data': [
        'views/oeh_medical_procedure_view.xml',
        'security/ir.model.access.csv',
    ],
    'active': False,
    'installable': True,
}
