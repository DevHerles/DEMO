# -*- coding: utf-8 -*-

from odoo import api, fields, models


class OehMedicalProcedureType(models.Model):
    _name = 'oeh.medical.procedure.type'

    name = fields.Char(string='Nombre', size=200)
    code = fields.Char(string='Codigo', size=5)

    @api.multi
    def name_get(self):
        names = []
        for record in self:
            name = u'[{}] {}'.format(
                record.code,
                record.name,
            )
            names.append((record.id, name))
        return names


class OehMedicalProcedure(models.Model):
    _inherit = 'oeh.medical.procedure'

    type_procedure = fields.Many2one('oeh.medical.procedure.type', string='Tipo')

    @api.multi
    def name_get(self):
        names = []
        for record in self:
            name = u'{} - {}'.format(
                record.name,
                record.description,
            )
            names.append((record.id, name))
        return names

    @api.model
    def name_search(self, name, args=[], operator='ilike', limit=80):
        args = args or []
        recs = self.browse()
        if name:
            recs = self.search([('description', '=', name)] + args, limit=limit)
        if not recs:
            recs = self.search([('description', operator, name)] + args, limit=limit)
        return recs.name_get()
